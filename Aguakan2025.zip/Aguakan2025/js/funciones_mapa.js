function inicializa(id) {
    construccionLista();
    var zoomI = 5;
    var latI = 23.84;
    var lngI = -102.18;
    var myOptions = {
        center: new google.maps.LatLng(latI, lngI), zoom: zoomI
    };
    for (var i = 0; i < geeServerDefs.layers.length; i++) {
        geeServerDefs.layers[i].initialState = false;
    }
    gmap = new GFusionMap(id, geeServerDefs, myOptions);

}

var codHtml = '';
function construccionLista() {
    codHtml = '';
    $("#divLista").empty();
    codHtml += '<table>';
    crearListado(listadoCapas, 0);
    codHtml += '</table>';
    document.getElementById('divLista').innerHTML = codHtml;
}

function crearListado(lista, num) {
    var tot = 0
    tot += num;
    var isfolder = false;
	var viewIdLayer = '';
    for (var i = 0; i < lista.layers.length; i++) {
        var btn = '<input type="checkBox" onclick="enciendeApagaCapa(\'' + lista.layers[i].id + '\');">';
        if (lista.layers[i].isFolder) {
            btn= '';
            isfolder = true;
        }
		else 
		{
			viewIdLayer = ' ('+lista.layers[i].id+')';
		}
        codHtml += '<tr><td class="' + lista.layers[i].id + '" style="padding-left:' + tot + 'px;">' + btn + lista.layers[i].label + viewIdLayer + '</td></tr>'
        if (isfolder) {
            crearListado(lista.layers[i], tot + 15, lista.layers[i].id);
        }
    }
}

function enciendeApagaCapa(layerId) {
	layerId= '0-'+layerId;
    if (gmap.isFusionLayerVisible(layerId)) {
        gmap.hideFusionLayer(layerId);
    }
    else {
        gmap.showFusionLayer(layerId);
    }
}

var listadoCapas = {
	// A continuación se crean las filas de capas que se visualizarán en la lista para activar o desactivar del mapa. 
	// Como ejemplo se agregan tres de ellas.
	// Agrega todas las capas que necesites.
    "version": "03s12i20u14l",
    "layers": [
	
      {
          "id": "02",
          "label": "División territorial",
          "isFolder": true,
          "state": false,
          "layers": [
            {
				  "id": 1162,
				  "initialState": true,
				  "label": "Estatal",
				  "lookAt": "none",
				  "opacity": 1,
				  "requestType": "VectorMapsRaster",
				  "version": 29
			  },
			  {
				  "id": 1163,
				  "initialState": true,
				  "label": "Municipal",
				  "lookAt": "none",
				  "opacity": 1,
				  "requestType": "VectorMapsRaster",
				  "version": 28
			  },
			  {
					"icon": "icons/ico_manzanasU_l.png",
					"id": 1166,
					"initialState": false,
					"isPng": true,
					"label": "Colonias",
					"lookAt": "none",
					"opacity": 1,
					"requestType": "VectorMapsRaster",
					"version": 26
			  }
          ]
      },
    ]
}