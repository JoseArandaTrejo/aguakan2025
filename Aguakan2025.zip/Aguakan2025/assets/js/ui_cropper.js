$(function () {
  $("[data-toggle=\"cropper-example-tooltip\"]").tooltip({ container: "body" });
  
  var URL = window.URL || window.webkitURL;
    var $image = $("#cropper-example-image");

    var options = {
      dragMode:'move',
      toggleDragModeOnDblclick:false,
      autoCrop:false,
      cropBoxMovable:false,
      cropBoxRezisable:false,
      aspectRatio: NaN,
      preview: ".cropper-example-preview"
  };
  //EDIT PARA SOPORTAR IMAGENES TIPO TIFF
  if(imgMime.toLowerCase() == "image/tiff")
    loadTiff(_base64ToArrayBuffer(imgBase64));

  var originalImageURL = $image.attr("src");
  $image.cropper(options);

  // IE10 fix
  if (typeof document.documentMode === "number" && document.documentMode < 11) {
      options = $.extend({}, options, {zoomOnWheel: false});
      setTimeout(function() {
        $image.cropper("destroy").cropper(options);
      }, 1000);
  }

  // Buttons
  if (!$.isFunction(document.createElement('canvas').getContext)) {
    $('button[data-method="getCroppedCanvas"]').prop('disabled', true);
  }
  if (typeof document.createElement('cropper').style.transition === 'undefined') {
    $('button[data-method="rotate"]').prop('disabled', true);
    $('button[data-method="scale"]').prop('disabled', true);
  }

    // Methods
  $('.cropper-example-buttons').on('click', '[data-method]', function () {
    var $this = $(this);
    var data = $this.data();
    var result;

    if ($this.prop('disabled') || $this.hasClass('disabled')) {
      return;
    }

    if ($image.data('cropper') && data.method) {
      data = $.extend({}, data); // Clone a new one

      if (data.method === 'rotate') {
        $image.cropper('clear');
      }

      result = $image.cropper(data.method, data.option, data.secondOption);

    }
  });
});