<?php 
header("Location: ../cliente.php");
?>