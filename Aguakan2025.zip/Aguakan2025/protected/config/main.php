<?php

// uncomment the following to define a path alias
Yii::setPathOfAlias('RestfullYii', __DIR__ . '/../extensions/starship/RestfullYii');

// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.
return array(
	//'id'=>'kT9[dh_&NY98sg{H',
	'basePath' => dirname(__FILE__) . DIRECTORY_SEPARATOR . '..',
	'name' => 'CLICKDATA',
	'theme' => 'bootstrap',
	'defaultController' => 'empresas',
	'language' => 'es',
	'sourceLanguage' => 'en',
	'charset' => 'UTF-8',
	// preloading 'log' component
	'preload' => array(
		'bootstrap',
		'log',
	),

	// autoloading model and component classes
	'import' => array(
		'application.models.*',
		'application.components.*',
		'application.modules.user.models.*',
		'application.modules.user.components.*',
		'application.components.TreeWalker',
	),

	'modules' => array(

		// uncomment the following to enable the Gii tool

		'gii' => array(
			'class' => 'system.gii.GiiModule',
			'password' => 'xxx',
			// If removed, Gii defaults to localhost only. Edit carefully to taste.
			'ipFilters' => array('127.0.0.1', '::1'),
			'generatorPaths' => array('bootstrap.gii'),
		),
		'user' => array(
			# encrypting method (php hash function)
			'hash' => 'md5',

			# send activation email
			'sendActivationMail' => false,

			# allow access for non-activated users
			'loginNotActiv' => false,

			# activate user on registration (only sendActivationMail = false)
			'activeAfterRegister' => true,

			# automatically login from registration
			'autoLogin' => false,

			# login form path
			'loginUrl' => null,


		),
	),

	// application components
	'components' => array(
		'bootstrap' => array(
			'class' => 'ext.bootstrap.components.Bootstrap',
			'responsiveCss' => false,
		),
		'user' => array(
			// enable cookie-based authentication
			'allowAutoLogin' => true,
			'loginUrl' => array('/user/login'),
			'class' => 'WebUser',
		),


		// uncomment the following to enable URLs in path-format

		'urlManager' => array(
			'urlFormat' => 'path',
			'showScriptName' => false,
			'rules' => require(dirname(__FILE__) . '/../extensions/starship/RestfullYii/config/routes.php'),
		),

		'curl' => array(
			'class' => 'ext.curl.Curl',
			'options' => array(),
		),


		// database settings are configured in database.php
		'db' => require(dirname(__FILE__) . '/database.php'),

		'errorHandler' => array(
			// use 'site/error' action to display errors
			'errorAction' => 'site/error',
		),
		'authManager' => array(

			'class' => 'CDbAuthManager',

			'connectionID' => 'db',

		),

		'log' => array(
			'class' => 'CLogRouter',
			'routes' => array(

				// uncomment the following to show log messages on web pages
				/*
				array(
					'class'=>'CWebLogRoute',
				),*/),
		),

		'eavCache' => array(
			'class' => 'system.caching.CDummyCache'
		),
		'zip' => array(
			'class' => 'application.extensions.zip.EZip',
		),
		//'behaviors'=>array(),

	),

	// application-level parameters that can be accessed
	'params' => require(dirname(__FILE__) . '/params.php')
);
