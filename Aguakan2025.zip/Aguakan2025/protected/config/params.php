<?php

return array(
	'primaryColor' => 'color_15',
	'buttonClass' => 'dark',
	'sessionTimeoutSeconds' => '{{SESSION_TIMEOUT_SECONDS}}',
	'showWaterMark' => boolval('{{SHOW_WATERMARK}}'),
	'showOnlyCenter' => boolval('{{SHOW_ONLY_CENTER}}'),
	'waterMarkText' => '{{WATERMARK_TEXT}}',
	'showEveryPx' => '{{SHOW_EVERY_PX}}',
	'max_empresas' => '{{MAX_EMP}}',
	'max_areas' => '{{MAX_AREAS}}',
	'max_expedientes' => '{{MAX_EXP}}',
	'max_users' => '{{MAX_USERS}}',
	'primer' => '{{FIRST_NAME}}',
	'segundo' => '{{SECOND_NAME}}',
	'tercero' => '{{THIRD_NAME}}',
	'cuarto' => '{{FOURTH_NAME}}',
	'MAX_CHAR' => intval('{{MAX_CHAR}}'),
	'FILES_FOLDER_PATH' => '{{FILES_PATH}}',
	'HTTP_SERVER_PATH' => '{{HTTP_FILES_PATH}}',
	'show_file_path' => boolval('{{SHOW_FILE_PATH}}'),
	'show_file_base64' => boolval('{{SHOW_FILE_BASE64}}'),
	'logo' => 'logo.jpg',
	'logoSideReport' => '{{LOGO_SIDE}}',
	'accessLogs' => array('index', 'pdf', 'excel'),
	'dangerActions' => array('REST.DELETE', 'REST.DELETE.RECORDS'),
	'successActions' => array('REST.POST', 'REST.POST.RECORDS'),
	'warningActions' => array('REST.PUT', 'REST.PUT.RECORDS'),
	'csvExtensions' => array(
		'text/comma-separated-values',
		'text/csv',
		'text/plain',
		'text/anytext',
		'application/csv',
		'application/excel',
		'application/vnd.ms-excel',
		'application/vnd.msexcel',
		'application/octet-stream',
		'application/txt',
	),
	'isEncrypted' => boolval('{{IS_ENCRYPTED}}'),
	'key' => 'DjQypjtBvQSrUGcLTcJUK6xuMhwAt62jxJcQWt5EJVQGsbWTWRVcaLGc2S5BZUzH8D8kZ36yyGpyEUKq5N9JZchbqAW8Bp2neuwUMdaw8qhDJbtPuSLnQ4HyZnGMaLhkHGdtZzB42A5ZxUtaWq2D7ud7KRV8UqErF3VknHLeEtcXsAVXpSFmyVKEMLeBud2ZSuekWrm8NCHJtqMQd633QP2d5RYBkMnzhjzpqCThZPZztHfpHgSTjPABTFaxydbK',
	'gmapsApiKey' => '{{GMAPS}}',
	'gmapsDefaultCoordinates' => '16.7553504,-93.1233622',
	'useFEA' => boolval('{{USE_FEA}}'),
	'createExtraFields' => boolval('{{EXTRA_FIELDS}}'),
	'showStatus' => boolval('{{SHOW_STATUS}}'),
	'extraFields' => array(
		array("nombre" => "nooficio", "label" => "no. oficio", "tipo" => "TEXTO", "requerido" => true),
		array("nombre" => "dependenciadeorigen", "label" => "dependencia de origen", "tipo" => "TEXTO", "requerido" => true),
		array("nombre" => "asuntodocto", "label" => "asunto docto.", "tipo" => "TEXTO", "requerido" => true),
		array("nombre" => "tipodocto_list", "label" => "tipo docto.", "tipo" => "LISTA", "id_lista" => 1, "requerido" => true),
		array("nombre" => "nombreemisor", "label" => "nombre emisor", "tipo" => "TEXTO", "requerido" => true),
		array("nombre" => "cargoemisor", "label" => "cargo emisor", "tipo" => "TEXTO", "requerido" => true),
		array("nombre" => "dependenciaemisor", "label" => "dependencia emisor", "tipo" => "TEXTO", "requerido" => true),
		array("nombre" => "curpemisor", "label" => "CURP emisor", "tipo" => "TEXTO", "requerido" => true),
		array("nombre" => "nombrereceptor_opt", "label" => "nombre receptor", "tipo" => "TEXTO", "requerido" => false),
		array("nombre" => "cargoreceptor_opt", "label" => "cargo receptor", "tipo" => "TEXTO", "requerido" => false),
		array("nombre" => "dependenciareceptor_opt", "label" => "dependencia receptor", "tipo" => "TEXTO", "requerido" => false),
		array("nombre" => "tiporeceptor_list", "label" => "tipo receptor", "tipo" => "LISTA", "id_lista" => 2, "requerido" => true),
		array("nombre" => "tipofirmante_list", "label" => "tipo firmante", "tipo" => "LISTA", "id_lista" => 3, "requerido" => true),
		//array("nombre"=>"noseriefirmante","label"=>"no. serie firmante","tipo"=>"TEXTO","requerido"=>true),
		//array("nombre"=>"firmafirmante","label"=>"firma firmante","tipo"=>"TEXTO","requerido"=>true)
	),
	'allowImportCSV' => boolval('{{IMPORT_CSV}}'),
	'usingHeaderCSV' => boolval('{{USING_HEADER_CSV}}'),
	'delimiterCsv' => '{{DELIMITER_CSV}}',
	'randomDataGen' => array(
		'files' => array('archivo.pdf', 'curp.pdf', 'imagen.png', 'ine.pdf', 'contrato.pdf'),
		'mapa' => array('20.684284,-88.567780', '48.856890,2.350850', '27.380583,33.631839', '33.747252,-112.633853', '20.9672259,-89.6250672'),
		'texto' => array('Labore cupidatat non.', 'Lorem ipsum incididunt velit consequat laborum.', 'Dolore deserunt magna dolor.', 'Dolore nostrud.', 'Est deserunt veniam.'),
		'texto_largo' => array(
			'<b>Qui ut consectetur dolore</b> amet dolor minim consequat minim dolor in fugiat commodo pariatur excepteur ut </i>consectetur</i> minim ad tempor sit dolore consequat veniam pariatur <u>reprehenderit eiusmod in aliqua</u> cupidatat esse minim cillum et aute elit dolore pariatur.',
			'<h5>Cillum fugiat ullamco veniam quis ea labore</h5> do ut est dolore <b>consectetur labore minim eiusmod</b> sint in esse magna aliquip duis nulla adipisicing et laboris velit fugiat pariatur cillum in eu exercitation nostrud.',
			'<p>Cupidatat dolor mollit ad reprehenderit qui commodo incididunt deserunt laborum pariatur cupidatat duis cupidatat in ex aute sit <u>eu culpa in nulla laboris</u> ad qui reprehenderit in voluptate eiusmod dolor eu excepteur occaecat culpa non.</p>',
			'<small>Incididunt amet in non sed anim incididunt culpa in aliquip culpa nulla nisi ut mollit aliquip sint dolor voluptate dolore proident aliquip occaecat anim id dolore velit tempor.</small>',
			'<ul><li>Dolor eu officia sed exercitation</li><li>elit ullamco est in exercitation</li><li>esse officia non elit</li><li>mollit ad dolore eu enim consequat.</li></ul>'
		)
	),
	'dummyXml' => function ($certData, $data, $curp, $files) {
		$documentoChisHeader = array(
			"version" 			 		 => Yii::app()->params['signAttributes']['headerVersion'],
			//"fecha_creacion" 		 => date(DateTime::ISO8601),
			"fecha_creacion" 		 => date('Y-m-d\TH:i:s'),
			"no_oficio" 				 => $data['nooficio'],
			"dependencia_origen"  => $data['dependenciadeorigen'],
			"asunto_docto" 			 => $data['asuntodocto'],
			"tipo_docto" 				 => $data['tipodocto_list'],
			"xmlns" 						 => Yii::app()->params['signAttributes']['headerXmlns']
		);

		$emisor = array(
			"nombre_emisor" 		 => $data['nombreemisor'],
			"cargo_emisor" 			 => $data['cargoemisor'],
			"dependencia_emisor" => $data['dependenciaemisor'],
			"curp_emisor" => $data['curpemisor']
		);

		$receptores = array(
			array(
				"nombre_receptor" 		 => $data['nombrereceptor_opt'],
				"cargo_receptor" 			 => $data['cargoreceptor_opt'],
				"dependencia_receptor" => $data['dependenciareceptor_opt'],
				"tipo_receptor" 			 => $data['tiporeceptor_list']
			)
		);

		$archivo = array(
			"nombre_archivo"   => null,
			"checksum_archivo" => null
		);

		$anexos = array();

		//POR CADA ARCHIVO SACAMOS LOS CHECKSUM
		foreach ($files as $index => $file)
			$index == 0 ? $archivo = array("nombre_archivo" => $file['filename'], "checksum_archivo" => $file['hash']) : array_push($anexos, array("nombre_anexo" => $file['filename'], "checksum_anexo" => $file['hash']));

		$firmantes = array(
			array(
				"curp_firmante" 	=> $curp,
				"nombre_firmante" => $certData['emisor']['emisor_name'],
				"email_firmante" 	=> $certData['emisor']['emisor_email'],
				"tipo_firmante" 	=> $data['tipofirmante_list'],
				"fecha_firmado_firmante" => date("Y-m-d\TH:i:s"),
				"no_serie_firmante" => $certData['emisor']['serialNumber'],
				"firma_firmante" => $certData['emisor']['emisor_hash']
			)
		);

		return array(
			"DocumentoChis" => $documentoChisHeader,
			"emisor" => $emisor,
			"receptores" => $receptores,
			"archivo" => $archivo,
			"anexos" => $anexos,
			"firmantes" => $firmantes,
			"certificado" => $certData['cert'],
			"pkey" => $certData['pkey']
		);
	},
	'signAttributes' => array(
		'headerVersion' => "1.0",
		'version' => "1.0",
		'headerXmlns' => "http://firmaelectronica.chiapas.gob.mx/GCD/DoctoGCD",
	),
	'normalize' => function ($size) {
		if (preg_match('/^([\d\.]+)([KMG])$/i', $size, $match)) {
			$pos = array_search($match[2], array("K", "M", "G"));
			if ($pos !== false) {
				$size = $match[1] * pow(1024, $pos + 1);
			}
		}
		return $size;
	},
	'humanFileSize' => function ($size, $unit = "", $removePostfix = false) {
		if ((!$unit && $size >= 1 << 30) || $unit == "GB")
			return $removePostfix ? $size / (1 << 30) : number_format($size / (1 << 30), 2) . "GB";
		if ((!$unit && $size >= 1 << 20) || $unit == "MB")
			return $removePostfix ? $size / (1 << 20) : number_format($size / (1 << 20), 2) . "MB";
		if ((!$unit && $size >= 1 << 10) || $unit == "KB")
			return $removePostfix ? $size / (1 << 10) : number_format($size / (1 << 10), 2) . "KB";
		return $removePostfix ? $size : number_format($size) . " bytes";
	},
	'max_size_file' => function ($unit = "", $removePostfix = false) {
		$max_upload = Yii::app()->params['humanFileSize'](Yii::app()->params['normalize'](ini_get('upload_max_filesize')), $unit, $removePostfix);
		$max_post = Yii::app()->params['humanFileSize'](Yii::app()->params['normalize'](ini_get('post_max_size')), $unit, $removePostfix);
		$memory_limit = Yii::app()->params['humanFileSize'](Yii::app()->params['normalize'](ini_get('memory_limit')), $unit, $removePostfix);
		$maxFileSize = min($max_upload, $max_post);
		//$maxFileSize = min($max_upload, $max_post, $memory_limit);
		return $maxFileSize;
	},
	'RestfullYii' => [
		'req.auth.ajax.user' => function () {
			if (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) && preg_match('/Basic\s+(.*)$/i', $_SERVER['REDIRECT_HTTP_AUTHORIZATION'], $matches)) {
				list($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']) = explode(':', base64_decode(substr($_SERVER['REDIRECT_HTTP_AUTHORIZATION'], 6)));
			}

			if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
				return false;
			}
			$user = Users::model()->findByAttributes(array('email' => $_SERVER['PHP_AUTH_USER'], 'password' => $_SERVER['PHP_AUTH_PW']));
			if ($user->email != $_SERVER['PHP_AUTH_USER']) {
				return false;
			}
			if ($user->password != $_SERVER['PHP_AUTH_PW']) {
				return false;
			}
			return true;
		},
		'req.cors.access.control.allow.origin' => function () {
			return [Yii::app()->baseUrl];
		},
		'req.cors.access.control.allow.methods' => function () {
			return ['GET', 'POST', 'PUT', 'DELETE'];
		},
		'req.auth.https.only' => function () {
			return false;
		},
		'model.lazy.load.relations' => function () {
			return false;
		},
		'model.limit' => function () {
			return isset($_GET['limit']) ? $_GET['limit'] : 100000;
		},
	],
);
