<?php
class CCompare extends CActiveRecordBehavior
{
  public function compare($other) {
    if(!is_object($other))
      return false;

    // does the objects have the same type?
    if(get_class($this->owner) !== get_class($other))
      return false;

    $differences = array();

    foreach($this->owner->attributes as $key => $value) {
      if($this->owner->$key != $other->$key)
        $differences[$key] = $other->$key;
    }

    return $differences;
  }
}