<?php

/**
 * UserIdentity represents the data needed to identity a user.
 * It contains the authentication method that checks if the provided
 * data can identity the user.
 */
class UserIdentity extends CUserIdentity
{
	private $_id;
	const ERROR_EMAIL_INVALID=3;
	const ERROR_STATUS_NOTACTIV=4;
	const ERROR_STATUS_BAN=5;
	/**
	 * Authenticates a user.
	 * The example implementation makes sure if the username and password
	 * are both 'demo'.
	 * In practical applications, this should be changed to authenticate
	 * against some persistent user identity storage (e.g. database).
	 * @return boolean whether authentication succeeds.
	 */
	public function authenticate()
	{
		
		$user=User::model()->notsafe()->findByAttributes(array('email'=>$this->username));
		
		if($user===null)
			if (strpos($this->username,"@")) {
				$this->errorCode=self::ERROR_EMAIL_INVALID;
			} else {
				$this->errorCode=self::ERROR_USERNAME_INVALID;
			}
		else if(Yii::app()->getModule('user')->encrypting($this->password)!==$user->password)
			$this->errorCode=self::ERROR_PASSWORD_INVALID;
		else if($user->status=='inactivo'&&Yii::app()->getModule('user')->loginNotActiv==false)
			$this->errorCode=self::ERROR_STATUS_NOTACTIV;
		else if($user->status==-1)
			$this->errorCode=self::ERROR_STATUS_BAN;
		else {
			$this->saveLog("Inicio de Sesión",array($this->getAuditUserInfo(true)),array($this->getAuditUserInfo()),Yii::app()->controller->id,$user->id_usuario);
			Yii::app()->user->setState('userSessionTimeout',time()+Yii::app()->params['sessionTimeoutSeconds'] );
			$user->serial = md5(time());
			$user->save();
			Yii::app()->user->setState('userSerial',$user->serial);
			$this->_id=$user->id_usuario;
			$this->username=$user->apellido_p." ".$user->apellido_m." ".$user->nombre;
			$this->errorCode=self::ERROR_NONE;
		}
		return !$this->errorCode;
	}
    
    /**
    * @return integer the ID of the user record
    */
	public function getId()
	{
		return $this->_id;
	}


	private function saveLog($accion,$antes,$despues,$modulo,$idUser,$uuid=null,$stringOriginal=null){
		try{
			$log = new Logs;
			$log->accion=$accion;
			$log->idUser=$idUser;
			$log->fecha_modificacion= date("Y-m-d H:i:s");
			$log->modulo=$modulo;
			$log->uuid=$uuid;
			$log->stringOriginal = $stringOriginal;
			if($antes && $despues){
				$antesFinal;
				if(is_array($antes) && count($antes)>0){
					$antesFinal = new stdClass();
			        $antesFinal->attributes=array();
					foreach ($antes as $a) {
				        array_push($antesFinal->attributes, $a);
					}
				}
				else
					$antesFinal=$antes;

				$despuesFinal;
				if(is_array($despues) && count($despues)>0){
					$despuesFinal = new stdClass();
			        $despuesFinal->attributes=array();
					foreach ($despues as $a) {
				        array_push($despuesFinal->attributes, $a);
					}
				}
				else
					$despuesFinal=$despues;

				$log->antes=CJSON::encode(get_class($antesFinal)=="stdClass"?$antesFinal->attributes:$antesFinal);
				$log->despues=CJSON::encode(get_class($despuesFinal)=="stdClass"?$despuesFinal->attributes:$despuesFinal);
				$differences = CJSON::encode(get_class($despuesFinal)=="stdClass"?$this->CompareStdClass($antesFinal,$despuesFinal):$antesFinal->compare($despuesFinal));
				$log->diferencias=$differences;
			}
			$log->save();

		}catch(Exception $e){
			
		}

	}

	private function CompareStdClass($antes,$despues){
		if(!is_object($antes) || !is_object($despues))
	      return false;

	    // does the objects have the same type?
	    if(get_class($antes) !== get_class($despues))
	      return false;

	    $differences = array();

	    foreach($antes->attributes as $key => $value) {
	    	$aux = array();
            foreach($value as $keyModel => $valueModel) {
            	if(isset($despues->attributes[$key][$keyModel]) && $valueModel != $despues->attributes[$key][$keyModel])
            		$aux[$keyModel]=$despues->attributes[$key][$keyModel];
                	//$differences[$keyModel] = $despues->attributes[$key][$keyModel];
            }
            array_push($differences,$aux);
        }

	    return $differences;
	}

	private function createStdObject($json){
		$stdObj = new stdClass();
		$stdObj->attributes=array();

		foreach (is_array($json)?$json:CJSON::decode($json) as $key => $value)
			$stdObj->attributes[$key] = $value;

		return $stdObj;
	}

	private function getAuditUserInfo($empty=false){
		$result = array("HOST_ADDRESS"=>null,/*"HOST_NAME"=>null,*/"MAC_ADDRESS"=>null,"HTTP_USER_AGENT"=>null);
		if($empty)
			return $result;

		try{
			$result["HTTP_USER_AGENT"] =  Yii::app()->request->getUserAgent();
			$result["HOST_ADDRESS"] =  Yii::app()->request->getUserHostAddress();
			//$result["HOST_NAME"] =  gethostname();

		}catch (Exception $e){

		}

		try{
			$ipAddress=Yii::app()->request->getUserHostAddress();
			/*$macAddr;

			$arp=`arp -a $ipAddress`;
			$lines=explode("\n", $arp);

			foreach($lines as $line)
			{
			   $cols=preg_split('/\s+/', trim($line));
			   if ($cols[0]==$ipAddress)
			   {
			       $macAddr=$cols[1];
			   }
			}

			$result["MAC_ADDRESS"] = $macAddr;*/

		}catch (Exception $e){

		}

		return $result;
	}
}