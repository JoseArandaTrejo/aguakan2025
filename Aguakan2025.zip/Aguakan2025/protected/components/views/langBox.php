<?php echo CHtml::form(); ?>
    <div id="langdrop">
    	<select id="lang_switcher" name="_lang">
            <option value="<?=$currentLang?>" selected></option>
        </select>
    </div>
<?php echo CHtml::endForm(); ?>