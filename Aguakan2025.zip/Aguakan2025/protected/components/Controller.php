<?php

/**
 * Controller is the customized base controller class.
 * All controller classes for this application should extend from this base class.
 */
class Controller extends CController
{
	/**
	 * @var string the default layout for the controller view. Defaults to '//layouts/column1',
	 * meaning using a single column layout. See 'protected/views/layouts/column1.php'.
	 */
	public $layout = '//layouts/column1';
	/**
	 * @var array context menu items. This property will be assigned to {@link CMenu::items}.
	 */
	public $menu = array();
	/**
	 * @var array the breadcrumbs of the current page. The value of this property will
	 * be assigned to {@link CBreadcrumbs::links}. Please refer to {@link CBreadcrumbs::links}
	 * for more details on how to specify this property.
	 */
	public $breadcrumbs = array();

	protected function beforeAction($action)
	{
		//OCULTAR SOLO WARNING
		//error_reporting(E_ALL ^ ~E_WARNING);

		if (!Yii::app()->user->isGuest) {
			if (Yii::app()->user->getState('userSessionTimeout') < time()) {
				$this->saveLog("Cierre de Sesión por Inactividad", array($this->getAuditUserInfo(true)), array($this->getAuditUserInfo()), Yii::app()->controller->id, Yii::app()->user->id);
				Yii::app()->user->logout();
				Yii::app()->session->open();
				Yii::app()->user->setFlash('warning', 'Su sesión fue cerrada por <b>Inactividad</b>');
				$this->redirect(array('/user/login'));
			} elseif (Yii::app()->user->getState('userSerial') != User::model()->findByPk(Yii::app()->user->id)->serial) {
				$this->saveLog("Cierre de Sesión por Inicio de Sesión en otro Dispositivo", array($this->getAuditUserInfo(true)), array($this->getAuditUserInfo()), Yii::app()->controller->id, Yii::app()->user->id);
				Yii::app()->user->logout();
				Yii::app()->session->open();
				Yii::app()->user->setFlash('warning', 'Su sesión fue cerrada por <b>inicio de sesión desde otro dispositivo</b>');
				$this->redirect(array('/user/login'));
			} else {
				if (in_array($action->id, Yii::app()->params['accessLogs']) && Yii::app()->controller != "install")
					$this->saveLog(Yii::app()->controller->action->id, null, null, Yii::app()->controller->id, Yii::app()->user->id);
				Yii::app()->user->setState('userSessionTimeout', time() + Yii::app()->params['sessionTimeoutSeconds']);
				return true;
			}
		} else
			return true;
	}

	protected function afterAction($action)
	{
	}

	function init()
	{
		parent::init();
		$app = Yii::app();
		if (isset($_POST['_lang'])) {
			$app->language = $_POST['_lang'];
			$app->session['_lang'] = $app->language;
		} else if (isset($app->session['_lang'])) {
			$app->language = $app->session['_lang'];
		}
	}

	protected function saveLog($accion, $antes, $despues, $modulo, $idUser, $uuid = null, $stringOriginal = null)
	{
		try {
			$log = new Logs;
			$log->accion = $accion;
			$log->idUser = $idUser;
			$log->fecha_modificacion = date("Y-m-d H:i:s");
			$log->modulo = $modulo;
			$log->uuid = $uuid;
			$log->stringOriginal = $stringOriginal;
			if ($antes && $despues) {
				$antesFinal;
				if (is_array($antes) && count($antes) > 0) {
					$antesFinal = new stdClass();
					$antesFinal->attributes = array();
					foreach ($antes as $a) {
						array_push($antesFinal->attributes, $a);
					}
				} else
					$antesFinal = $antes;

				$despuesFinal;
				if (is_array($despues) && count($despues) > 0) {
					$despuesFinal = new stdClass();
					$despuesFinal->attributes = array();
					foreach ($despues as $a) {
						array_push($despuesFinal->attributes, $a);
					}
				} else
					$despuesFinal = $despues;

				$log->antes = CJSON::encode(get_class($antesFinal) == "stdClass" ? $antesFinal->attributes : $antesFinal);
				$log->despues = CJSON::encode(get_class($despuesFinal) == "stdClass" ? $despuesFinal->attributes : $despuesFinal);
				$differences = CJSON::encode(get_class($despuesFinal) == "stdClass" ? $this->CompareStdClass($antesFinal, $despuesFinal) : $antesFinal->compare($despuesFinal));
				$log->diferencias = $differences;
			}
			$log->save();
		} catch (Exception $e) {
		}
	}

	private function CompareStdClass($antes, $despues)
	{
		if (!is_object($antes) || !is_object($despues))
			return false;

		// does the objects have the same type?
		if (get_class($antes) !== get_class($despues))
			return false;

		$differences = array();

		foreach ($antes->attributes as $key => $value) {
			$aux = array();
			foreach ($value as $keyModel => $valueModel) {
				if (isset($despues->attributes[$key][$keyModel]) && $valueModel != $despues->attributes[$key][$keyModel])
					$aux[$keyModel] = $despues->attributes[$key][$keyModel];
				//$differences[$keyModel] = $despues->attributes[$key][$keyModel];
			}
			array_push($differences, $aux);
		}

		return $differences;
	}

	public function createStdObject($json)
	{
		$stdObj = new stdClass();
		$stdObj->attributes = array();

		foreach (is_array($json) ? $json : CJSON::decode($json) as $key => $value)
			$stdObj->attributes[$key] = $value;

		return $stdObj;
	}

	protected function getApiUrl($module, $filters = "[]", $order = "[]")
	{
		if (!empty($filters))
			$filters = CJSON::encode(array_filter(CJSON::decode($filters)));
		return stripos($_SERVER['SERVER_PROTOCOL'], 'https') === 0 ? 'https://' : 'http://' . $_SERVER['HTTP_HOST'] . Yii::app()->baseUrl . "/api/" . $module . "/?filter=" . $filters . "&sort=" . $order;
	}

	protected function getAuth($username = null, $pwd = null)
	{
		if (empty($username) && empty($pwd)) {
			$user = Users::model()->findByPk(Yii::app()->user->id);
			$username = $user->email;
			$pwd = $user->password;
		}
		return array('Authorization: Basic ' . base64_encode($username . ":" . $pwd));
	}

	protected function getUser()
	{
		return Users::model()->findByAttributes(array('email' => $_SERVER['PHP_AUTH_USER'], 'password' => $_SERVER['PHP_AUTH_PW']));
	}

	public function getUserAccess($id = null)
	{
		$id_rol = empty($id) ? Yii::app()->user->id_tipo : Users::model()->findByPk($id)->id_tipo;
		$data = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("roles", CJSON::encode(array(array("property" => "id_rol", "value" => $id_rol, "operator" => "=")))));
		$permisos = CJSON::decode($data)["data"]["roles"][0]["permisos"];
		$session = new CHttpSession;
		$session->open();
		$session["permisos"] = $permisos;
	}

	//FUNCION UTILIZADA PARA EL API PARA RECUPERAR LOS PERMISOS
	public function getAccess($tipo = null)
	{
		//TIPO PUEDE TOMAR LOS SIGUIENTES VALORES
		//v = ver, a = agregar, b = borrar , c = cambiar
		$user = $this->getUser();
		$idEmpresas = array();
		$idAreas = array();
		$idExpedientes = array();

		if ($user->id_tipo != 1) {
			$permisos = Permisos::model()->findAllByAttributes(array("id_rol" => $user->id_tipo, empty($tipo) ? "v" : $tipo => 1));
			$idExpedientes = array_column($permisos, "id_expediente");

			$expedienteCriteria = new CDbCriteria();
			$expedienteCriteria->addInCondition('id_expediente', $idExpedientes);
			$expedientes = Expedientes::model()->findAll($expedienteCriteria);

			$idAreas = array_unique(array_map(function ($e) {
				return is_object($e) ? $e->id_area : $e['id_area'];
			}, $expedientes));

			$areaCriteria = new CDbCriteria();
			$areaCriteria->addInCondition('id_area', $idAreas);
			$areas = Areas::model()->findAll($areaCriteria);

			$idEmpresas = array_unique(array_map(function ($e) {
				return is_object($e) ? $e->id_empresa : $e['id_empresa'];
			}, $areas));
		}

		return array("isAdmin" => $user->id_tipo == 1, "empresas" => $idEmpresas, "areas" => $idAreas, "expedientes" => $idExpedientes);
	}

	public function sanatizeColumnName($name)
	{
		return trim(strtolower(preg_replace("/[^a-zA-Z0-9 ]+/", "", $name)));
	}

	public function sanatizeTableName($name)
	{
		return trim(strtolower(preg_replace("/[^a-zA-Z0-9\_]+/", "", $name)));
	}

	public function convertBase64ToFile($base64, $filename, $folder = null)
	{
		$decodedFile = base64_decode($base64);
		if (empty($folder))
			return file_put_contents(Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . $filename, $decodedFile);
		else
			return file_put_contents(Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . $folder . DIRECTORY_SEPARATOR . $filename, $decodedFile);
	}

	public function convertFileToBase64($filename, $folder = null)
	{
		if (empty($folder))
			$path = Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . $filename;
		else
			$path = Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . $folder . DIRECTORY_SEPARATOR . $filename;

		//EN CASO QUE LOS ARCHIVOS ESTÉN ENCRIPTADOS PARA PODER ENTREGAR EL VALOR REAL BASE64, NECESITAMOS DESENCRIPTAR HASTA EL FINAL
		if (file_exists($path))
			return Yii::app()->params['isEncrypted'] ? $this->decrypt(base64_encode(file_get_contents($path))) : base64_encode(file_get_contents($path));
	}

	public function saveTmpFileToServer($file, $filename, $folder = null)
	{
		$encodedFile = base64_encode(file_get_contents($file));
		return $this->convertBase64ToFile(Yii::app()->params['isEncrypted'] ? $this->encrypt($encodedFile) : $encodedFile, $filename, $folder);
	}

	protected function encrypt(string $data, string $method = null)
	{
		//CODIGO PARA EVITAR EL ERROR
		//Default value for parameters with a class type hint can only be NULL
		$method = empty($method) ? "AES-256-ECB" : $method;

		$ivSize = openssl_cipher_iv_length($method);
		$iv = $ivSize > 0 ? openssl_random_pseudo_bytes($ivSize) : "";
		$encrypted = openssl_encrypt($data, $method, Yii::app()->params['key'], OPENSSL_RAW_DATA, $iv);
		$encrypted = strtoupper(implode(null, unpack('H*', $encrypted)));
		return $encrypted;
	}

	protected function decrypt(string $data, string $method = null)
	{
		//CODIGO PARA EVITAR EL ERROR
		//Default value for parameters with a class type hint can only be NULL
		$method =  empty($method) ? "AES-256-ECB" : $method;

		$data = pack('H*', $data);
		$ivSize = openssl_cipher_iv_length($method);
		$iv = $ivSize > 0 ? openssl_random_pseudo_bytes($ivSize) : "";
		$decrypted = openssl_decrypt($data, $method, Yii::app()->params['key'], OPENSSL_RAW_DATA, $iv);
		return trim($decrypted);
	}

	public function getFileMime($base64)
	{
		$imgdata = base64_decode($base64);
		$f = finfo_open();
		return finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
	}

	private function getAuditUserInfo($empty = false)
	{
		$result = array("HOST_ADDRESS" => null,/*"HOST_NAME"=>null,*/ "MAC_ADDRESS" => null, "HTTP_USER_AGENT" => null);
		if ($empty)
			return $result;

		try {
			$result["HTTP_USER_AGENT"] =  Yii::app()->request->getUserAgent();
			$result["HOST_ADDRESS"] =  Yii::app()->request->getUserHostAddress();
			//$result["HOST_NAME"] =  gethostname();

		} catch (Exception $e) {
		}

		try {

			$ipAddress = Yii::app()->request->getUserHostAddress();
			/*$macAddr;

			$arp=`arp -a $ipAddress`;
			$lines=explode("\n", $arp);

			foreach($lines as $line)
			{
			   $cols=preg_split('/\s+/', trim($line));
			   if ($cols[0]==$ipAddress)
			   {
			       $macAddr=$cols[1];
			   }
			}

			$result["MAC_ADDRESS"] = $macAddr;*/
		} catch (Exception $e) {
		}

		return $result;
	}
}
