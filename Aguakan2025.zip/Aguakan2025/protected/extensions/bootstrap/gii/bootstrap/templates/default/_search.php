<div class="wide form">

<?="<?php"?> $form=$this->beginWidget('CActiveForm', array(
	 'id'=>'search-<?php echo $this->class2id($this->modelClass); ?>-form',
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); <?="?>"?>

<?php foreach($this->tableSchema->columns as $column): ?>
	<div class="col-xs-12 col-md-4">
		<div class="form-group label-floating">
		 	<label class="control-label" for="<?=$this->class2id($this->modelClass)?>_<?=$column->name?>"><?=$column->name?></label>
		  	<input class="form-control" id="<?=$this->class2id($this->modelClass)?>_<?=$column->name?>" name="<?=$column->name?>" value="<?=isset($_GET['<?=$column->name?>'])?$_GET['<?=$column->name?>']:''?>" type="text">
		</div>
	</div>
<?php endforeach ?>

	<div class="col-xs-12">
		<input type="submit" value="Buscar" class="btn btn-raised btn-<?=Yii::app()->params['color']?>" name="src">
	</div>
<?php echo "<?php \$this->endWidget(); ?>\n"; ?>
</div><!-- search-form -->
<?="
<?php 
Yii::app()->clientScript->registerScript('loadRange','
	   $(document).ready(function(){
		   	$(\".date_range\").daterangepicker({

	    	\"showDropdowns\": true,
	    	\"autoUpdateInput\": false,
	    	\"locale\": {
	        \"format\": \"DD/MM/YYYY\",
	        \"separator\": \" al \",
	        \"applyLabel\": \"Aplicar\",
	        \"cancelLabel\": \"Limpiar\",
	        \"fromLabel\": \"Desde\",
	        \"toLabel\": \"A\",
	        \"customRangeLabel\": \"Seleccionar Rango\",
	        \"daysOfWeek\": [
	            \"Do\",
	            \"Lu\",
	            \"Ma\",
	            \"Mi\",
	            \"Ju\",
	            \"Vi\",
	            \"Sa\"
	        ],
	        \"monthNames\": [
	            \"Enero\",
	            \"Febrero\",
	            \"Marzo\",
	            \"Abril\",
	            \"Mayo\",
	            \"Junio\",
	            \"Julio\",
	            \"Agosto\",
	            \"Septiembre\",
	            \"Octubre\",
	            \"Noviembre\",
	            \"Diciembre\"
	        ],
	        \"firstDay\": 1
	    },
	    
	     \"applyClass\": \"btn btn-raised btn-info\",
	      \"cancelClass\": \"btn btn-raised btn-default\",
	     
	        ranges: {
	           \"Hoy\": [moment(), moment()],
	           \"Ayer\": [moment().subtract(1, \"days\"), moment().subtract(1, \"days\")],
	           \"Últimos 7 Días\": [moment().subtract(6, \"days\"), moment()],
	           \"Últimos 30 Días\": [moment().subtract(29, \"days\"), moment()],
	           \"Este Mes\": [moment().startOf(\"month\"), moment().endOf(\"month\")],
	           \"Último Mes\": [moment().subtract(1, \"month\").startOf(\"month\"), moment().subtract(1, \"month\").endOf(\"month\")],
	           
	        }
	    });
	 	
		$(\".date_range\").on(\"cancel.daterangepicker\", function(ev, picker) {
	 		$(this).val(\"\");
		});

		$(\".date_range\").on(\"apply.daterangepicker\", function(ev, picker) {
	    	$(this).val(picker.startDate.format(\"DD/MM/YYYY\") + \" al \" + picker.endDate.format(\"DD/MM/YYYY\"));
	 	});
	   });
	',CClientScript::POS_END);
?>"
?>