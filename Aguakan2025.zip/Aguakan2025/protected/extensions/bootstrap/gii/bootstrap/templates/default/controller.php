<?php echo "<?php\n"; ?>



class <?php echo $this->controllerClass; ?> extends <?php echo $this->baseControllerClass."\n"; ?>

{

	public $layout='//layouts/column1';

	public function filters()

	{

		return array(

			'accessControl',
			'postOnly + delete',

		);

	}

	public function accessRules()

	{

		return array(

			array('allow',

				'actions'=>array('index','view','GeneratePdf','GenerateExcel'),

				'users'=>array('@'),

			),

			array('allow',

				'actions'=>array('admin','delete','create','update'),

				'users'=>array('admin'),

			),

			array('deny',

				'users'=>array('*'),

			),

		);

	}


	public function actionView($id)

	{

		$this->render('view',array(

			'model'=>$this->loadModel($id),

		));

	}


	public function actionCreate()

	{

		$model=new <?php echo $this->modelClass; ?>;



		// Uncomment the following line if AJAX validation is needed

		// $this->performAjaxValidation($model);



		if(isset($_POST['<?php echo $this->modelClass; ?>']))

		{

			$model->attributes=$_POST['<?php echo $this->modelClass; ?>'];

			if($model->save())
				$this->redirect(array('index'));

		}


		$this->render('create',array(

			'model'=>$model,

		));

	}


	public function actionUpdate($id)

	{

		$model=$this->loadModel($id);



		// Uncomment the following line if AJAX validation is needed

		// $this->performAjaxValidation($model);



		if(isset($_POST['<?php echo $this->modelClass; ?>']))

		{

			$model->attributes=$_POST['<?php echo $this->modelClass; ?>'];

			if($model->save())
				$this->redirect(array('index'));

		}


		$this->render('update',array(

			'model'=>$model,

		));

	}


	public function actionDelete()

	{

		$this->loadModel($_POST['id'])->delete();

	}


	public function actionIndex()

	{

        $session=new CHttpSession;

        $session->open();		

        $where= '';

            if(isset($_GET['src'])){

            	<?php 
            		$columnas ="array(";
            		foreach($this->tableSchema->columns as $column):
            			$columnas.="'$column->name',";
            		endforeach;
            		$columnas = substr($columnas,0,strlen($columnas)-1).")";
            	?>

            		$keys = <?=$columnas?>;

            	
            	foreach ($keys as $key)
				{
					if(isset($_GET[$key])&&!empty($_GET[$key]))
			        {
			            if(strlen($where)>0)
			                $where.= " AND ";
			            if(strcmp($key, "id")==0)
			                $where.="$key=".$_GET[$key];
			            /*elseif(strcmp($key, "fecha")==0){
			            	$btwn = explode(' al ',$_GET[$key]);
			                $where.="fecha BETWEEN '".date('Y-m-d',strtotime(implode('-',explode('/',$btwn[0]))))."' and '".date('Y-m-d',strtotime(implode('-',explode('/',$btwn[1]))))."'";
			            }*/
			            else
			                $where.="$key LIKE '%".$_GET[$key]."%'";
			    
			            
			    
			        }

				}
					$model = <?=$this->modelClass?>::model()->findAll("$where");
			}
				else
					$model = <?=$this->modelClass?>::model()->findAll();
			

		$_SESSION['where'] = $where;
        $this->render('index',array('model'=>$model,));
	}



	/**

	 * Manages all models.

	 */

	public function actionAdmin()

	{

		$model=new <?php echo $this->modelClass; ?>('search');

		$model->unsetAttributes();  // clear any default values

		if(isset($_GET['<?php echo $this->modelClass; ?>']))

			$model->attributes=$_GET['<?php echo $this->modelClass; ?>'];



		$this->render('admin',array(

			'model'=>$model,

		));

	}



	/**

	 * Returns the data model based on the primary key given in the GET variable.

	 * If the data model is not found, an HTTP exception will be raised.

	 * @param integer the ID of the model to be loaded

	 */

	public function loadModel($id)

	{

		$model=<?php echo $this->modelClass; ?>::model()->findByPk($id);

		if($model===null)

			throw new CHttpException(404,'The requested page does not exist.');

		return $model;

	}



	/**

	 * Performs the AJAX validation.

	 * @param CModel the model to be validated

	 */

	protected function performAjaxValidation($model)

	{

		if(isset($_POST['ajax']) && $_POST['ajax']==='<?php echo $this->class2id($this->modelClass); ?>-form')

		{

			echo CActiveForm::validate($model);

			Yii::app()->end();

		}

	}

    public function actionGenerateExcel()

	{

        $session=new CHttpSession;

        $session->open();		

        $model = <?php echo $this->modelClass; ?>::model()->findAll($_SESSION['where']);   

		Yii::app()->request->sendFile("<?php echo $this->modelClass; ?>_".date('dmYHis').".xls",

		$this->renderPartial('_excel', array('model'=>$model), true));

	}

    public function actionGeneratePdf() 

	{

        $session=new CHttpSession;

        $session->open();

		Yii::import('application.extensions.bootstrap.gii.*');

		require_once('bootstrap/tcpdf/tcpdf.php');

		require_once('bootstrap/tcpdf/config/lang/eng.php');

		$model = <?php echo $this->modelClass; ?>::model()->findAll($_SESSION['where']);

        $html = $this->renderPartial('_pdf', array('model'=>$model), true);
		
		//die($html);


		$pdf = new TCPDF();

		$pdf->SetCreator(PDF_CREATOR);

		$pdf->SetAuthor(Yii::app()->name);

		$pdf->SetTitle('Reporte <?php echo $this->modelClass; ?>');

		$pdf->SetSubject('Reporte <?php echo $this->modelClass; ?>');

		//$pdf->SetKeywords('example, text, report');

		$pdf->SetHeaderData('', 0, "Report", '');

		$pdf->SetHeaderData('', '', Yii::app()->name, "");

		$pdf->setHeaderFont(Array('helvetica', '', 8));

		$pdf->setFooterFont(Array('helvetica', '', 6));

		$pdf->SetMargins(15, 18, 15);

		$pdf->SetHeaderMargin(5);

		$pdf->SetFooterMargin(10);

		$pdf->SetAutoPageBreak(TRUE, 0);

		$pdf->SetFont('dejavusans', '', 7);

		$pdf->AddPage();

		$pdf->writeHTML($html, true, false, true, false, '');

		$pdf->LastPage();

		$pdf->Output("<?php echo $this->modelClass; ?>_".date('dmYHis').".pdf", "I");

	}

}

