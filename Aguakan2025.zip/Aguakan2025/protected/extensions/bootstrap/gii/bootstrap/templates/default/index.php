<?php $label=$this->class2name($this->modelClass); ?>
<div class="col-xs-12">
	<ul class="breadcrumb" style="text-align:left;">
		<li class="active"><?=$label?></li>
	</ul>

	<div class="panel panel-<?=Yii::app()->params['color']?>">
		<div class="panel-heading">
    		<h3 class="panel-title">Búsqueda</h3>
  		</div>
		<div class="panel-body">
			<?= "<?php \$this->renderPartial('_search'); ?>"?>
	    
	 	</div>
	</div>

	<div class="row">
		<div class="col-xs-12">
		  	<div class="btn-group pull-left">
		      	<a class="btn btn-raised dropdown-toggle" data-toggle="dropdown"><i class="material-icons">save</i>  Exportar a <span class="caret"></span>
		      	</a>
		      	<ul class="dropdown-menu">
			        <li><a target="_blank" download href="<?="<?=Yii::app()->controller->createUrl('generatePdf');?>"?>">PDF</a></li>
			        <li><a target="_blank" href="<?="<?=Yii::app()->controller->createUrl('generateExcel');?>"?>">Excel</a></li>
		      	</ul>
	    	</div>
		</div>
	</div>

	<div class="panel panel-<?=Yii::app()->params['color']?>">
		<div class="panel-heading">
    		<h3 class="panel-title"><?=ucfirst($label)?>s</h3>
  		</div>
	  	<div class="panel-body">
	  		<div class="table-responsive">
	  			<?= "<?php if (!empty(\$model)): ?>" ?>
					<table id="myTable" class="table-striped table-hover table-condensed table">
						<thead>
							<tr>
							<?php
								foreach($this->tableSchema->columns as $column):
							?>
								<th><?=ucfirst($column->name)?></th>
							<?php
								endforeach
							?>
								<th>Opciones</th>
							</tr>
						</thead>
						<tbody>
	  			<?=	"<?php foreach (\$model as \$M): ?>" ?>
	  					<tr id="hd_<?="<?=\$M->id?>"?>">
	  						<?php
								foreach($this->tableSchema->columns as $column):
							?>
								<td><?="<?="?>$M-><?=$column->name?><?="?>"?></td>
							<?php
								endforeach
							?>

	  						<td>
								<?="<?php if (Yii::app()->user->isAdmin()): ?>"?>
									
									<a data-toggle="tooltip" data-placement="bottom" data-original-title="Editar <?=$label?>" href="<?= "<?=Yii::app()->controller->createUrl('update',array('id'=>\$M->id))?>" ?>" ><i class="small material-icons">mode_edit</i></a>
									<a data-toggle="tooltip" data-placement="bottom" data-original-title="Eliminar <?=$label?>" href="#" class="dlt" data-id="<?="<?=\$M->id?>"?>"><i class="small material-icons">delete</i></a>
									
									
								<?="<?php endif ?>"?>
	  						</td>
	  					</tr>
	  			<?=	"<?php endforeach ?>" ?>
						</tbody>
					</table>
				<?= "<?php else: ?>" ?>
					<div class="alert alert-dismissible alert-warning">
						<button type="button" class="close" data-dismiss="alert">&times</button>
						<h4>¡No se encontraron resultados!</h4>

						<p>No se encontraron coincidencias con los parámetros de búsqueda, intente con parámetros distintos.</p>
					</div>
	  			<?= "<?php endif ?>" ?>

			</div>
	    
	  	</div>
	</div>

</div>



<a data-toggle="tooltip" data-placement="top" data-original-title="Agregar <?=$label?>" class="btn btn-<?=Yii::app()->params['color']?> btn-fab" href="<?="<?=Yii::app()->controller->createUrl('create');?>"?>" style="position:fixed; bottom: 45px; right: 24px;"><i class="material-icons">add</i></a>

<?="<?php
Yii::app()->clientScript->registerScript('delete','
	   $(document).ready(function(){
		   $(\".dlt\").click(function(e){
		    	e.preventDefault();
				var id = $(this).attr(\"data-id\");
				swal({   
					title: \"¿Desea eliminar este expediente?\",
					text: \"Una vez eliminado no podrá recuperar este expediente\",
					type: \"warning\",
					showCancelButton: true,
					confirmButtonColor: \"#3085d6\",
					cancelButtonColor: \"#d33\",
					confirmButtonText: \"Eliminar\",
					cancelButtonText: \"Cancelar\",
					confirmButtonClass: \"confirm-class\",
					cancelButtonClass: \"cancel-class\",
					closeOnConfirm: true,
					closeOnCancel: true },
					function(isConfirm) {   
						if (isConfirm) {
						    $.ajax({
						    	type:\"POST\",
						    	url:\"'.Yii::app()->controller->createUrl('delete').'\",
						    	data:{id:id},
						    	success:function()
						    	{
						    		$(\"#hd_\"+id).fadeOut(\"slow\", function() {});
						    	}

						    });
						} 
					});
			});
	   });
	',CClientScript::POS_END);
?>"?>

