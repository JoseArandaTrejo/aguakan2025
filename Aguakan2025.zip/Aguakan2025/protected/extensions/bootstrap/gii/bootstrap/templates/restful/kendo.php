<?php
	$PK ="";
	foreach($this->tableSchema->columns as $column)
		if($column->autoIncrement)
			$PK = $column->name;

?>
	var crudServiceBaseUrl=baseUrl;


	var dataSource = new kendo.data.DataSource({
                            transport: {
                                read:  {						        
							        url: crudServiceBaseUrl + "/api/<?=strtolower($this->modelClass)?>",
							        dataType: "json"
						    	},
							    update: {
							        url: function(options){								        	
							        	return crudServiceBaseUrl + "/api/<?=strtolower($this->modelClass)?>/"+options.models[0].<?=$PK?>;
							        }, 
							        dataType: "json",
							        type:"PUT"								       
							    },
							    destroy: {
							        url: function(options){							        	
							        	return crudServiceBaseUrl + "/api/<?=strtolower($this->modelClass)?>/"+options.models[0].<?=$PK?>;
							        }, 
							      	dataType: "json",
							        type:"DELETE"
							    },
							    create: {
							        url: crudServiceBaseUrl + "/api/<?=strtolower($this->modelClass)?>",
							        dataType: "json",
							        type:"POST"
							    },
                                parameterMap: function(options, operation) {
                                    if (operation !== "read" && options.models) {
                                    	
                                    	return kendo.stringify(options.models[0]);
                                    }
                                }
                            },
                            batch: true,
                            pageSize: 10,
                         	
					schema: {
				        data: "data.<?=strtolower($this->modelClass)?>",
				        total: "data.totalCount",				        
				        model: {
				        <?php
				          	echo "id: '".$PK."',\n";
				        ?>
				          fields: {
				          	<?php
				          		foreach($this->tableSchema->columns as $column)
					            {
					            	if($column->type=="integer")
					            		$type="number";
					            	else
					            		$type="string";

					            	if($column->autoIncrement)
					                	echo "\t'".$column->name."':{type:'".$type."' ,editable: false, nullable: true},\n";
					            	else	
					                	echo "\t\t\t\t\t\t\t\t\t'".$column->name."':{type:'".$type."'},\n";

					            }
					        ?>

					        }           
					      }
				   }
				});


$("#grid_<?=strtolower($this->modelClass)?>").kendoGrid({

	dataSource: dataSource,
	toolbar: ["create", "excel"],
    columns:[
			
			<?php
				foreach($this->tableSchema->columns as $column)
				{
					if($column->type=="integer")
	            		$operator="eq";
	            	else
	            		$operator="contains";

					if($column->autoIncrement)
						echo "{ field: '". $column->name."', title: '".$this->class2name($column->name)."', width: '200px'},\n\t\t\t";
					else
						echo "{ field:  '".$column->name."', title:  '".$this->class2name($column->name)."', width: '200px',
							filterable: {
			                    cell: {
			                        operator: '".$operator."'
			                    }
			                } 
						},\n\t\t\t";			
						
						
				}
			?>
			

			
            {command: [
			"edit",

	    	"destroy"
            ],
            title: "Opciones", width: "150px"
            }
         ],
			

  	selectable: "multiple",                      
  	pageable: {
	    refresh: true,
	    pageSizes: true
	},
	editable: "popup",
	excel: {
       fileName: "<?=strtolower($this->modelClass)?>_report.xlsx",
    },                
  	resizable: true,
  	reorderable: true,
  	//groupable: true | false,
    sortable: true,
  	filterable: {
      mode: "row"
    },
  scrollable: true
  });
