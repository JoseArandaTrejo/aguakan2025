<?php $label=$this->class2name($this->modelClass); ?>
<div class="col-xs-12">
	<ul class="breadcrumb" style="text-align:left;">
		<li ><a href="<?="<?=Yii::app()->controller->createUrl('index');?>"?>"><?=$label?></a></li>
		<li class="active">Nuevo <?=$label?></li>
	</ul>

	<?="<?php \$this->renderPartial('_form', array('model'=>\$model)); ?>"?>

</div>