<?php $model = strtolower($this->modelClass); ?>

<?php $js = strtolower($this->modelClass).".js"; ?>

<div id="top_bar">
    <ul id="breadcrumbs">
        <li><a href="<?="<?=Yii::app()->createUrl('dashboard')?>"?>"><i class="material-icons">home</i></a></li>
        <li><span><?=$model?></span></li>
    </ul>
</div>

<div class="md-card">
    <div class="md-card-toolbar">
        <h3 class="md-card-toolbar-heading-text">
            Búsqueda
        </h3>
    </div>
    <div class="md-card-content">
		<?="<?php \$this->renderPartial('_search'); ?>"?>
	</div>    
        
</div><br>

<div id="grid_<?=$model?>"></div>

<script type="text/javascript">
    baseUrl = <?='"<?=Yii::app()->baseUrl;?>"'?>;
</script>


<?php

echo "<?php\n";

?>

  <?="Yii::app()->clientScript->registerScriptFile(Yii::app()->request->baseUrl.'/assets/kendo/js/kendo.all.min.js',CClientScript::POS_END);"?>



  <?="Yii::app()->clientScript->registerScriptFile(Yii::app()->request->baseUrl.'/assets/kendo/js/cultures/kendo.culture.es-MX.min.js',CClientScript::POS_END);"?>



  <?="Yii::app()->clientScript->registerScriptFile(Yii::app()->request->baseUrl.'/assets/kendo/js/messages/kendo.messages.es-ES.min.js',CClientScript::POS_END);"?>



  <?="Yii::app()->clientScript->registerScriptFile(Yii::app()->request->baseUrl.'/assets/js/pages/$js',CClientScript::POS_END);"?>

  <?="Yii::app()->clientScript->registerScriptFile(Yii::app()->request->baseUrl.'/assets/js/jszip.min.js',CClientScript::POS_END);"?>



  <?="Yii::app()->clientScript->registerCssFile(Yii::app()->request->baseUrl.'/assets/kendo/styles/kendo.common.min.css');"?>



  <?="Yii::app()->clientScript->registerCssFile(Yii::app()->request->baseUrl.'/assets/kendo/styles/kendo.uniform.min.css');"?>

<?php echo "\n?>"; ?>