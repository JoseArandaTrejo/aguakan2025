<style type="text/css">
.panel-title{color: #fff;}
</style>
<div class="form">

	<?php echo "<?php \$form=\$this->beginWidget('bootstrap.widgets.TbActiveForm',array(

	'id'=>'".$this->class2id($this->modelClass)."-form',

	'enableAjaxValidation'=>false,

        'method'=>'post',

	'type'=>'horizontal',

	'htmlOptions'=>array(

		'enctype'=>'multipart/form-data',

		'role'=>'form'

	)

	)); ?>\n"; ?>


	<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

	<?="<?php echo \$form->errorSummary(\$model); ?>"?>

	<div class="row">

		<div class="col-xs-12 col-md-12">

			<div class="panel panel-<?=Yii::app()->params['color']?>">
				<div class="panel-heading">
					<a role="button" data-toggle="collapse" href="#<?=$this->class2id($this->modelClass)?>" aria-expanded="true" aria-controls="<?=$this->class2id($this->modelClass)?>">
						<h3 class="panel-title"><?=$this->class2id($this->modelClass)?> : <span class="glyphicon glyphicon-menu-down pull-right"></span></h3>
					</a>
				</div>
				<div class="panel-body collapse in" id="<?=$this->class2id($this->modelClass)?>">

					<?php foreach($this->tableSchema->columns as $column): ?>

						<div class="col-xs-12 col-md-4">
							<?="<?php echo \$form->textFieldRow(\$model,'$column->name',array('maxlength'=>100, 'class'=>'form-control')); ?>"?>
						</div>
					<?php endforeach ?>
				</div>
			</div>
		</div>

	</div>


	<button data-toggle="tooltip" data-placement="top" data-original-title="Guardar" class="btn btn-<?=Yii::app()->params['color']?> btn-fab" style="position:fixed; bottom: 45px; right: 24px;"><i class="material-icons">done</i></button>

	<?= "<?php \$this->endWidget(); ?>" ?>

</div>