<?php $label=$this->class2name($this->modelClass); ?>
<div class="col-xs-12">
	<div class="panel panel-info">
		<div class="panel-heading">
    		<h3 class="panel-title">Reporte de <?=ucfirst($label)?></h3>
  		</div>

  		<table>
			<tr style="text-align:center;">
				<th>
					<img src="<?="<?=Yii::app()->baseUrl?>/images/logo.png"?>">
				</th>
			</tr>
		</table>

	  	<div class="panel-body">
	  		<div class="table-responsive">
	  			<?= "<?php if (!empty(\$model)): ?>" ?>
					<table id="myTable" border="1" cellpadding="5">
						<thead>
							<tr style="text-align:center; background-color:#ddd">
								<?php
									foreach($this->tableSchema->columns as $column):
								?>
								<th style="font-weight:bold;"><?=$column->name?></th>
								<?php
									endforeach
								?>
							</tr>
						</thead>
						<tbody>
	  				<?="<?php foreach (\$model as \$M): ?>"?>
	  					<tr style="text-align:center;">
	  						<?php
								foreach($this->tableSchema->columns as $column):
							?>
							
	  						<td><?=$column->name?></td>
							<?php
								endforeach
							?>
	  					</tr>
	  				<?="<?php endforeach ?>"?>
						</tbody>
					</table>
	  			<?="<?php else: ?>"?>
					<div class="alert alert-dismissible alert-warning">
						<button type="button" class="close" data-dismiss="alert">&times</button>
						<h4>¡No se encontraron resultados!</h4>

						<p>No se encontraron coincidencias con los parámetros de búsqueda, intente con parámetros distintos.</p>
					</div>
	  			<?= "<?php endif ?>" ?>

			</div>
	    
	  	</div>
	</div>
</div>
