<?php
/**
 * The following variables are available in this template:
 * - $this: the BootCrudCode object
 */
?>
<?php
echo "<?php\n";
$label=$this->pluralize($this->class2name($this->modelClass));
echo "\$this->breadcrumbs=array(
	'$label',
);\n";
?>


?>

<!--<h1><?php echo $label; ?></h1>-->

<?php echo "<?php"; ?> 
$this->beginWidget('zii.widgets.CPortlet', array(
	'htmlOptions'=>array(
		'class'=>''
	)
));
$this->widget('bootstrap.widgets.TbMenu', array(
	'type'=>'pills',
	'items'=>array(
		array('label'=>'Nuevo', 'icon'=>'icon-plus', 'url'=>Yii::app()->controller->createUrl('create'), 'linkOptions'=>array()),
                array('label'=>'Lista', 'icon'=>'icon-th-list', 'url'=>Yii::app()->controller->createUrl('index'),'active'=>true, 'linkOptions'=>array()),
		array('label'=>'Buscar', 'icon'=>'icon-search', 'url'=>'#', 'linkOptions'=>array('class'=>'search-button')),
		array('label'=>'Exportar a PDF', 'icon'=>'icon-download', 'url'=>Yii::app()->controller->createUrl('GeneratePdf'), 'linkOptions'=>array('target'=>'_blank'), 'visible'=>true),
		array('label'=>'Exportar a Excel', 'icon'=>'icon-download', 'url'=>Yii::app()->controller->createUrl('GenerateExcel'), 'linkOptions'=>array('target'=>'_blank'), 'visible'=>true),
	),
));
$this->endWidget();
?>



<div class="search-form" style="display:none">
<?php echo "<?php \$this->renderPartial('_search',array(
	'model'=>\$model,
)); ?>\n"; ?>
</div><!-- search-form -->
<br />


<?php echo "<?php"; ?> $this->widget('bootstrap.widgets.TbGridView',array(
	'id'=>'<?php echo $this->class2id($this->modelClass); ?>-grid',
	'dataProvider'=>$model->search(),
        'type'=>'striped bordered hover condensed',
        'template'=>'{summary}{pager}{items}{pager}',
	'columns'=>array(
<?php
$count=0;
foreach($this->tableSchema->columns as $column)
{
	if(++$count==7)
		echo "\t\t/*\n";
	echo "\t\t'".$column->name."',\n";
}
if($count>=7)
	echo "\t\t*/\n";
?>
       array(
            'class'=>'bootstrap.widgets.TbButtonColumn',
			'template' => '{view} {update} {delete}',
			'buttons' => array(
			      'view' => array(
					'label'=> 'View',
					'options'=>array(
						'class'=>'btn btn-small view'
					)
				),	
                              'update' => array(
					'label'=> 'Update',
					'options'=>array(
						'class'=>'btn btn-small update'
					)
				),
				'delete' => array(
					'label'=> 'Delete',
					'options'=>array(
						'class'=>'btn btn-small delete'
					)
				)
			),
            'htmlOptions'=>array('style'=>'width: 135px'),
           )
	),
)); ?>

<?php echo "<?php"; ?>

    Yii::app()->clientScript->registerScript('$label','

      $(window).on("resize", function () {
            resizeGrid();
        });


function ver(e){

	e.preventDefault();

	var dataItem = this.dataItem($(e.currentTarget).closest("tr"));



	document.location="../agencias/update/id/"+dataItem.id_agencia+".html";

}

 function resizeGrid() {
            var gridElement = $("#gridkendo"),
                dataArea = gridElement.find(".k-grid-content"),
                gridHeight = gridElement.innerHeight(),
                otherElements = gridElement.children().not(".k-grid-content"),
                otherElementsHeight = 0;
                otherElements.each(function () {
                    otherElementsHeight += $(this).outerHeight();
                });
                dataArea.height(gridHeight - otherElementsHeight);
  }



 $("#gridkendo").kendoGrid({

	dataSource: {

		type: "odata",

		transport: {

			

			read: urljson

		},

		schema: {

				data: "data",

				total: "__count",

				sort: { field: "fecha_alta", dir: "desc" },

				model: {

					id: "id_agencia",

					fields: {

<?php
$count=0;
foreach($this->tableSchema->columns as $column)
{
	if(++$count==7)
		echo "\t\t/*\n";
	echo "\t\t'".$column->name."': { type:\"string\"},\n";
}
if($count>=7)
	echo "\t\t*/\n";
?>
								
					}						
			}
		},

		  pageSize: 50

	},
  	columns:[

<?php
$count=0;
foreach($this->tableSchema->columns as $column)
{
	if(++$count==7)
		echo "\t\t/*\n";
	
	echo '\t\t { field: "'.$column->name.'", title: "'.$column->name.'", width: 180,
				filterable: {
                                cell: {
                                    operator: "contains"
                                }
                            }  
            },\n
          ';

}
if($count>=7)
	echo "\t\t*/\n";
?>




			{ command: [

				{ name:"Ver", text: "", width:15, click:ver, 
				 template: "<span class=\'k-icon k-i-search\'></span>"  },

				], 				

				title: "", width: 40  },									

			],   

	selectable: "multiple",			                 

	pageable: {

		refresh: true,

		pageSizes: true

	},

	resizable: true,

	reorderable: true,

	//groupable: true,

    sortable: true,

	filterable: {
			mode: "row"
		},
	

	scrollable: true

               

	});

	gridAgencias("'.Yii::app()->createUrl('agencias/agenciasjson').'");


    ',CClientScript::POS_READY);



$cs = Yii::app()->getClientScript();

$cs->registerScriptFile(Yii::app()->request->baseUrl.'/kendomaterial/js/kendo.all.min.js',CClientScript::POS_END);

$cs->registerScriptFile(Yii::app()->request->baseUrl.'/kendo/js/cultures/kendo.es-MX.js',CClientScript::POS_END);

$cs->registerCssFile(Yii::app()->request->baseUrl.'/kendomaterial/styles/kendo.common-material.min.css');

$cs->registerCssFile(Yii::app()->request->baseUrl.'/kendomaterial/styles/kendo.material.min.css');



?>
