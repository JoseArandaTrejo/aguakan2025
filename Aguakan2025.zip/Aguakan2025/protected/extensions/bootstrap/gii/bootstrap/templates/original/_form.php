<?php
/**
 * The following variables are available in this template:
 * - $this: the BootCrudCode object
 */
?>
<div class="form">
<?php echo "<?php \$form=\$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'".$this->class2id($this->modelClass)."-form',
	'enableAjaxValidation'=>false,
        'method'=>'post',
	'type'=>'horizontal',
	'htmlOptions'=>array(
		'enctype'=>'multipart/form-data',
		'role'=>'form'
	)
)); ?>\n"; ?>


	<?php echo "<?php echo \$form->errorSummary(\$model,'Error: ', null,array('class'=>'alert alert-error col-md-12')); ?>\n"; ?>
        		
   <div class="row">		
			<div class="col-md-8">

<?php
foreach($this->tableSchema->columns as $column)
{
 
	if($column->autoIncrement)
		continue;
?>
	<?php echo "<?php echo ".$this->generateActiveRow($this->modelClass,$column)."; ?>\n"; ?>

<?php
}
?>
                      
	<div class="form-group">
		<div class="col-lg-offset-4 col-lg-8 ">
		<?php echo "<?php \$this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'primary',
                        'icon'=>'ok white',  
			'label'=>\$model->isNewRecord ? 'Nuevo' : 'Guardar',
		)); ?>\n"; ?>
              <?php echo "<?php \$this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'reset',
                        'icon'=>'remove',  
			'label'=>'Restablecer',
		)); ?>\n"; ?>
        <p class="note">Campos con <span class="required">*</span> son obligatorios.</p>
        </div>
	</div>
  </div></div> 

  </div>   
  </div>

<?php echo "<?php \$this->endWidget(); ?>\n"; ?>

</div>
