<?php

class AreasController extends Controller
{
	
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			array(
                'ext.starship.RestfullYii.filters.ERestFilter + 
                REST.GET, REST.PUT, REST.POST, REST.DELETE'
            ),
		);
	}

	public function accessRules()
	{
		return array( 
            array('allow', 'actions'=>array('REST.GET', 'REST.PUT', 'REST.POST', 'REST.DELETE'),
                'users'=>array('*'),
            ),
            array('allow','actions'=>array('index','save','remove'),
            	'users'=>array('@'),
        	),

            array('deny', 

                'users'=>array('*'), 

            ),


        );

	}

	public function actions()
	{
        return array('REST.'=>'ext.starship.RestfullYii.actions.ERestActionProvider',);
	}

	public function actionIndex($slug){
		//PERMISOS
		$this->getUserAccess();
		$session=new CHttpSession;
  		$session->open();

		$id = Empresas::model()->getIdFromSlug($slug);
		$empresa = Empresas::model()->findByPk($id);

		//SE VALIDA QUE LA EMPRESA EXISTA ANTES DE INTENTAR IR POR SUS AREAS
		if (empty($empresa))
		    throw new CHttpException(404, "No se encontró la vista solicitada");
		
		$filters = CJSON::encode(array(array("property"=>"id_empresa","value"=>$id,"operator"=>"="),isset($_POST['filters'])?CJSON::decode($_POST['filters']):null));
		
		$data = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("areas",$filters));

		$data =CJSON::decode($data)["data"];
		
		$areas = $data["areas"];


		foreach ($areas as $index=> $area)
			$areas[$index]["slug"]=Areas::model()->findByPk($area["id_area"])->slug;

		$dataProvider=new CArrayDataProvider($areas, array(
			'keyField'=>'id_area',
			'id'=>'areas',
		    'sort'=>array(
		        'attributes'=>array(
		        	'id_area',
		            'nombre'
		        ),
		    ),
		    'pagination'=>array(
		        'pageSize'=>12,
		    ),
		));

		if(isset($_POST['filters']))
			$this->renderPartial("_listView",array("areas"=>$dataProvider,"empresa"=>$empresa,"permisos"=>$session["permisos"]["areas"]));
		else
			$this->render('index',array('areas'=>$dataProvider,"empresa"=>$empresa,"permisos"=>$session["permisos"]["areas"]));
	}

	public function actionSave(){
		$this->getUserAccess();
        $session=new CHttpSession;
		$session->open();

		$model = $_POST['Areas'];
		$areas = Areas::model()->findAll();

		if(!empty($_FILES['image']['name'])){
			$attributes = array("file"=>base64_encode(file_get_contents($_FILES['image']['tmp_name'])),"filename"=>$_FILES['image']['name']);
			$model = array_merge($model, array("picture"=>$attributes));
		}

		if(!empty($model["id_area"]) && boolval($session["permisos"]["areas"]["update"]))
			echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("areas/".$model["id_area"]),CJSON::encode($model));
		else if(empty($model["id_area"]) && (boolval($session["permisos"]["areas"]["create"]) && (count($areas) < Yii::app()->params['max_areas'] || Yii::app()->params['max_areas'] == 0)))
			echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->post($this->getApiUrl("areas"),CJSON::encode($model));
		else
			echo CJSON::encode(array(
				'success'			=> false,
				'message'			=> 'No tiene los permisos necesarios para realizar esta acción',
				'totalCount'		=> 0,
			));
	}

	public function actionRemove(){
		$this->getUserAccess();
        $session=new CHttpSession;
		$session->open();

		if(!boolval($session["permisos"]["areas"]["delete"]))
        	echo CJSON::encode(array(
				'success'			=> false,
				'message'			=> 'No tiene los permisos necesarios para realizar esta acción',
				'totalCount'		=> 0,
			));
        else
			echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->delete($this->getApiUrl("areas/".$_POST['id']));
	}


	public function restEvents(){

		$this->onRest('pre.filter.req.get.resources.render', function($data, $model_name, $relations, $count, $visibleProperties, $hiddenProperties){

            $result=[];
            $access =$this->getAccess();
            
            if($access['isAdmin'])
                $result = $data;
            else{
                foreach ($data as $registro)
                    if(in_array($registro['id_area'],$access['areas']))
                        array_push($result,$registro);
            }

            return [$result, $model_name, $relations, count($result), $visibleProperties, $hiddenProperties];
        });

		$this->onRest('model.with.relations', function($model) {
		    $nestedRelations = [];
		    
		    foreach($model->metadata->relations as $rel=>$val)
		    {
		        $className = $val->className;
		        $rel_model = call_user_func([$className, 'model']);
		        if((isset($_GET['showChildren']) && boolval($_GET['showChildren'])) || (!is_array($rel_model->tableSchema->primaryKey) && substr($rel, 0, 1) != '_')) {
		            $nestedRelations[] = $rel;
		        }
		    }
		    return $nestedRelations;
		});

		//SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN UPDATE
		$this->onRest('req.put.resource.render',function($model, $relations, $visibleProperties=[], $hiddenProperties=[]) {
			echo $this->renderJSON([
				'type'				=> 'rest',
				'success'			=> 'true',
				'message'			=> sprintf("%s '<b>%s</b>' actualizada",Yii::app()->params["segundo"],$model->nombre),
				'totalCount'	=> "1",
				'modelName'		=> get_class($model),
				'relations'		=> $relations,
				'visibleProperties'	=> $visibleProperties,
				'hiddenProperties'	=> $hiddenProperties,
				'data'				=> $model,
			]);
		});

		//SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN CREATE
		$this->onRest('req.post.resource.render',function($model, $relations, $visibleProperties=[], $hiddenProperties=[]) {
			echo $this->renderJSON([
				'type'				=> 'rest',
				'success'			=> 'true',
				'message'			=> sprintf("%s '<b>%s</b>' creada",Yii::app()->params["segundo"],$model->nombre),
				'totalCount'	=> "1",
				'modelName'		=> get_class($model),
				'relations'		=> $relations,
				'visibleProperties'	=> $visibleProperties,
				'hiddenProperties'	=> $hiddenProperties,
				'data'				=> $model,
			]);
		});

		//SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER DELETE
		$this->onRest('req.delete.resource.render', function($model, $visibleProperties=[], $hiddenProperties=[]) {
			echo $this->renderJSON([
				'type'				=> 'rest',
				'success'			=> 'true',
				'message'			=> sprintf("%s '<b>%s</b>' eliminada",Yii::app()->params["segundo"],$model->nombre),
				'totalCount'		=> "1",
				'modelName'			=> get_class($model),
				'relations'			=> [],
				'visibleProperties'	=> $visibleProperties,
				'hiddenProperties'	=> $hiddenProperties,
				'data'				=> $model,
			]);
		});

		//ANTES DE BORRAR UN AREA
		$this->onRest('pre.filter.model.delete', function($model) {
			$transaction = Yii::app()->db->beginTransaction();
			try{

				$idArea = $model['attributes']['id_area'];
				
				foreach ($model->_expedientes as $expediente) {
					//BORRAMOS LOS PERMISOS
					$permisos = Permisos::model()->deleteAll('id_expediente='.$expediente->id_expediente);
					//BORRAMOS LISTA_EXP
					$listaExp = ListaExp::model()->deleteAll('id_expediente='.$expediente->id_expediente);
					//BORRAMOS ARCHIVOS DE TABLA MULTI
					$multi = Multi::model()->deleteAll('id_expediente='.$expediente->id_expediente);
					//BORRAMOS DE LA TABLA EXPEDIENTES
					$expedientes = Expedientes::model()->deleteByPk($expediente->id_expediente);
					//HACEMOS DROP TABLE
					Yii::import('application.controllers.AlterTable');
	                $alterTable = new AlterTable();
	                $tableName = $idArea."_".$expediente->nombre;
	                $alterTable->dropTable($this->sanatizeTableName($tableName));
					
				}
				//BORRAMOS TODOS LOS REGISTROS TEMPORALES DEL AREA
				$tmp = Tmp::model()->deleteAll('tipo=2 and id_fk='.$idArea);
				
				$transaction->commit();
			}
			catch(Exception $e){
				$transaction->rollBack();
			}

			return $model;
		});

		$this->onRest('pre.filter.model.apply.post.data', function($model, $data, $restricted_properties){
			if(isset($data["picture"]) && !empty($data["picture"])){
	            $name_aux="";
	            if(empty($data["picture"]["filename"]))
	                throw new CHttpException('011', "El atributo 'filename' no puede estar vacio.");
	            else
	            	$data["image"] = date("dmYHis").$data["picture"]["filename"];

	            if($this->convertBase64ToFile($data["picture"]["file"],$data["image"],"thumbs")===false)
	                throw new CHttpException('010', "Error al subir el archivo.");

	            unset($data["picture"]);
			}

			return [$model, $data, $restricted_properties];
		});

		$this->onRest('pre.filter.model.apply.put.data', function($model, $data, $restricted_properties){

			if(isset($data["picture"]) && !empty($data["picture"])){
	            $name_aux="";
	            if(empty($data["picture"]["filename"]))
	                throw new CHttpException('011', "El atributo 'filename' no puede estar vacio.");
	            else
	            	$data["image"] = date("dmYHis").$data["picture"]["filename"];

	            if($this->convertBase64ToFile($data["picture"]["file"],$data["image"],"thumbs")===false)
	                throw new CHttpException('010', "Error al subir el archivo.");

	            unset($data["picture"]);
			}

			return [$model, $data, $restricted_properties];
		});

		//LOG PARA CREATE
		$this->onRest('model.apply.post.data', function($model, $data, $restricted_properties) {
			$result = $this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties);
			if($result->validate()){
				$old = new $model;
				$this->saveLog(Yii::app()->controller->action->id,array($old),array($data),Yii::app()->controller->id,$this->getUser()->id_usuario);
			}
			return $result;
		});

		//LOG PARA UPDATE
		$this->onRest('model.apply.put.data', function($model, $data, $restricted_properties) {
			$result = $this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties);
			if($result->validate()){
				$old = $model::model()->findByPk($model->id_area);
				$this->saveLog(Yii::app()->controller->action->id,array($old),array($data),Yii::app()->controller->id,$this->getUser()->id_usuario);
			}
			return $result;
		});

		//LOG PARA DELETE
		$this->onRest('post.filter.model.delete', function($result) {
			$old = new Areas;
			$this->saveLog(Yii::app()->controller->action->id,array($old),array($result),Yii::app()->controller->id,$this->getUser()->id_usuario);
			return $result;
		});
	}

}