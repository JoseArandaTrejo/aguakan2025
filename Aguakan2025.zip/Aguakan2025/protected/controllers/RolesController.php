<?php

class RolesController extends Controller
{
	
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			array(
                'ext.starship.RestfullYii.filters.ERestFilter + 
                REST.GET, REST.PUT, REST.POST, REST.DELETE'
            ),
		);
	}

	public function accessRules()
	{
		return array( 
            array('allow', 'actions'=>array('REST.GET', 'REST.PUT', 'REST.POST', 'REST.DELETE'),
                'users'=>array('*'),
            ),
            array('allow','actions'=>array('create','update','save','remove'),
                'users'=>array('@'),
            ),
            array('deny', 

                'users'=>array('*'), 

            ),


        );

	}

	public function actions()
	{
        return array('REST.'=>'ext.starship.RestfullYii.actions.ERestActionProvider',);
	}

    public function actionCreate(){
        //PERMISOS
        $this->getUserAccess();
        $session=new CHttpSession;
        $session->open();

        if(!filter_var($session["permisos"]["roles"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        $empresas =Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("empresas?showChildren=true"));
        $empresas= CJSON::decode($empresas)["data"]["empresas"];

        $this->render("_form",array("titulo"=>"Nuevo Rol","permisos"=>$session["permisos"]["roles"],"empresas"=>$empresas,"rol"=>null));
        

    }

    public function actionUpdate($id){
        //PERMISOS
        $this->getUserAccess();
        $session=new CHttpSession;
        $session->open();

        if(!filter_var($session["permisos"]["roles"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');
        
        $data =Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("roles/".$id));
        $data= CJSON::decode($data)["data"]["roles"];

        $empresas =Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("empresas?showChildren=true"));
        $empresas= CJSON::decode($empresas)["data"]["empresas"];

        $this->render('_form',array("titulo"=>"Editar Rol","permisos"=>$session["permisos"]["roles"],"model"=>$data,"empresas"=>$empresas,"rol"=>$data));
        
    }

    public function actionSave(){
        $this->getUserAccess();
        $session=new CHttpSession;
        $session->open();

        $_POST["permisos"]["registros"] = isset($_POST["permisos"]["registros"])?array_values($_POST["permisos"]["registros"]):array();

        if(!empty($_POST["id_rol"]) && filter_var($session["permisos"]["roles"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("roles/".$_POST["id_rol"]),CJSON::encode($_POST));
        else if(empty($_POST["id_rol"]) && (filter_var($session["permisos"]["roles"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE)))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->post($this->getApiUrl("roles"),CJSON::encode($_POST));
        else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    public function actionRemove(){
        $this->getUserAccess();
        $session=new CHttpSession;
        $session->open();

        if(!filter_var($session["permisos"]["roles"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE))
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
        else
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->delete($this->getApiUrl("roles/".$_POST['id']));
    }

	public function restEvents(){
        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN UPDATE
        $this->onRest('req.put.resource.render',function($model, $relations, $visibleProperties=[], $hiddenProperties=[]) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("Rol '<b>%s</b>' actualizado",$model->nombre),
                'totalCount'    => "1",
                'modelName'     => get_class($model),
                'relations'     => $relations,
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN CREATE
        $this->onRest('req.post.resource.render',function($model, $relations, $visibleProperties=[], $hiddenProperties=[]) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("Rol '<b>%s</b>' creado",$model->nombre),
                'totalCount'    => "1",
                'modelName'     => get_class($model),
                'relations'     => $relations,
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER DELETE
        $this->onRest('req.delete.resource.render', function($model, $visibleProperties=[], $hiddenProperties=[]) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("Rol '<b>%s</b>' eliminado",$model->nombre),
                'totalCount'        => "1",
                'modelName'         => get_class($model),
                'relations'         => [],
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

		//EVITAMOS LOS LLAMADOS AJAX PUT SOBRE LOS EXPEDIENTES
        $this->onRest('post.filter.req.auth.ajax.user', function($validation) {
            switch ($this->getAction()->getId()) {
                default:
                    return $validation;
                    break;
            }
        });

        //EVITAMOS LOS LLAMADOS PUT SOBRE LOS EXPEDIENTES
        $this->onRest('post.filter.req.auth.user', function($validation) {
            switch ($this->getAction()->getId()) {
                default:
                    return $validation;
                    break;
            }
        });

        //HACEMOS OVERRIDE AL EVENTO ENCARGADO DE RECUPERAR LOS VALORES
        $this->onRest('model.roles.override.attributes', function($model) {
            //OBTENEMOS EL TIPO DE LLAMADO
            switch ($this->getAction()->getId()) {
                default:
	                
                	$grl = PermisosGrl::model()->find("id_rol=".$model->id_rol);
                	$permisos = array();
                	$permisos["empresas"]["create"] = (!empty($grl->id) && $grl->ea==1) || $model->id_rol==1?true:false;
                	$permisos["empresas"]["update"] = (!empty($grl->id) && $grl->ec==1) || $model->id_rol==1?true:false;
                	$permisos["empresas"]["delete"] = (!empty($grl->id) && $grl->eb==1) || $model->id_rol==1?true:false;

                	$permisos["areas"]["create"] = (!empty($grl->id) && $grl->aa==1) || $model->id_rol==1?true:false;
                	$permisos["areas"]["update"] = (!empty($grl->id) && $grl->ac==1) || $model->id_rol==1?true:false;
                	$permisos["areas"]["delete"] = (!empty($grl->id) && $grl->ab==1) || $model->id_rol==1?true:false;

                	$permisos["expedientes"]["create"] = (!empty($grl->id) && $grl->xa==1) || $model->id_rol==1?true:false;
                    $permisos["expedientes"]["update"] = (!empty($grl->id) && $grl->xc==1) || $model->id_rol==1?true:false;
                	$permisos["expedientes"]["delete"] = (!empty($grl->id) && $grl->xb==1) || $model->id_rol==1?true:false;
                    $permisos["expedientes"]["pdf"] = (!empty($grl->id) && $grl->pdfv==1) || $model->id_rol==1?true:false;
                    $permisos["expedientes"]["excel"] = (!empty($grl->id) && $grl->xlsv==1) || $model->id_rol==1?true:false;

                	$permisos["users"]["view"] = (!empty($grl->id) && $grl->uv==1) || $model->id_rol==1?true:false;
                    $permisos["users"]["create"] = (!empty($grl->id) && $grl->ua==1) || $model->id_rol==1?true:false;
                	$permisos["users"]["update"] = (!empty($grl->id) && $grl->uc==1) || $model->id_rol==1?true:false;
                	$permisos["users"]["delete"] = (!empty($grl->id) && $grl->ub==1) || $model->id_rol==1?true:false;
                	$permisos["users"]["change_password"] = (!empty($grl->id) && $grl->up==1) || $model->id_rol==1?true:false;

                    $permisos["roles"]["view"] = (!empty($grl->id) && $grl->rv==1) || $model->id_rol==1?true:false;
                	$permisos["roles"]["create"] = (!empty($grl->id) && $grl->ra==1) || $model->id_rol==1?true:false;
                	$permisos["roles"]["update"] = (!empty($grl->id) && $grl->rc==1) || $model->id_rol==1?true:false;
                	$permisos["roles"]["delete"] = (!empty($grl->id) && $grl->rb==1) || $model->id_rol==1?true:false;

                	$permisos["logs"]["view"] = (!empty($grl->id) && $grl->lv==1) || $model->id_rol==1?true:false;
                	$permisos["logs"]["excel"] = (!empty($grl->id) && $grl->lxls==1) || $model->id_rol==1?true:false;
                    $permisos["logs"]["pdf"] = (!empty($grl->id) && $grl->lpdf==1) || $model->id_rol==1?true:false;

                	$permisos["lists"]["view"] = (!empty($grl->id) && $grl->lstv==1) || $model->id_rol==1?true:false;
                	$permisos["lists"]["create"] = (!empty($grl->id) && $grl->lsta==1) || $model->id_rol==1?true:false;
                	$permisos["lists"]["update"] = (!empty($grl->id) && $grl->lstc==1) || $model->id_rol==1?true:false;
                	$permisos["lists"]["delete"] = (!empty($grl->id) && $grl->lstb==1) || $model->id_rol==1?true:false;

                	$expedientes = Expedientes::model()->findAll();
            		$permisos["registros"]= array();
                	foreach ($expedientes as $expediente) {
                		$acciones = Permisos::model()->find("id_expediente=".$expediente->id_expediente." and id_rol=".$model->id_rol);
                		$array_permiso =array(
                			"id_expediente"=>$expediente->id_expediente,
                			"create"=>(!empty($acciones->id_permiso) && $acciones->a==1) || $model->id_rol==1?true:false,
                			"update"=>(!empty($acciones->id_permiso) && $acciones->c==1) || $model->id_rol==1?true:false,
                			"delete"=>(!empty($acciones->id_permiso) && $acciones->b==1) || $model->id_rol==1?true:false,
                			"view"=>(!empty($acciones->id_permiso) && $acciones->v==1) || $model->id_rol==1?true:false,
                            "download"=>(!empty($acciones->id_permiso) && $acciones->down==1) || $model->id_rol==1?true:false,
                            "print"=>(!empty($acciones->id_permiso) && $acciones->print==1) || $model->id_rol==1?true:false,
                		);
                		array_push($permisos["registros"], $array_permiso);
                	}
                		
	                
                    return array_merge($model->attributes,["permisos"=>$permisos]);
                    break;
            }
        });

        //ANTES DE LLAMAR EL EVENTO POST SEPARAMOS LOS DATOS DEL MODELO Y LOS PERMISOS
        $this->onRest('pre.filter.model.apply.post.data', function($model, $data, $restricted_properties) {
           	if(!isset($data["nombre"]))
                throw new CHttpException('026', 'El parámetro nombre no se encuentra definido');

            $mod = ['nombre'=>$data['nombre']];
            return [$model, $mod, $restricted_properties,isset($data['permisos'])?$data['permisos']:array()];
        });

        //RECIBIMOS UN PARAMETRO NUEVO LLAMADO $permisos CON LOS ATRIBUTOS Y SU DEFINICION
        $this->onRest('model.apply.post.data', function($model, $data, $restricted_properties,$permisos=null) {
            $result = ["model"=>$this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties),"permisos"=>$permisos];

            if($result["model"]->validate()){
                $this->saveLog(Yii::app()->controller->action->id,array(new $model),array($data),Yii::app()->controller->id,$this->getUser()->id_usuario);
            }
            return $result;
        });

        //ANTES DE LLAMAR EL EVENTO PUT SEPARAMOS LOS DATOS DEL MODELO Y LOS PERMISOS
        $this->onRest('pre.filter.model.apply.put.data', function($model, $data, $restricted_properties) {
           	if(!isset($data["nombre"]))
                throw new CHttpException('026', 'El parámetro nombre no se encuentra definido');

            $mod = ['nombre'=>$data['nombre']];
            return [$model, $mod, $restricted_properties,isset($data['permisos'])?$data['permisos']:array()];
        });

        //RECIBIMOS UN PARAMETRO NUEVO LLAMADO $attributes CON LOS ATRIBUTOS Y SU DEFINICION
        $this->onRest('model.apply.put.data', function($model, $data, $restricted_properties,$permisos=null) {
            $result = ["model"=>$this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties),"permisos"=>$permisos];

            if($result["model"]->validate()){
                $old = $model::model()->findByPk($model->id_rol);
                $this->saveLog(Yii::app()->controller->action->id,array($old),array($data),Yii::app()->controller->id,$this->getUser()->id_usuario);
            }

            return $result;
        });

        $this->onRest('model.save', function($model) {
            if(!$model['model']->save()) {
                throw new CHttpException('400', CJSON::encode($model->errors));
            }
            
            return ["model"=>$model['model'],"permisos"=>$model['permisos']];
        });

        $this->onRest('post.filter.model.save', function($result) {
            try
            {
            	$transaction = Yii::app()->db->beginTransaction();
                if($this->getAction()->getId()==="REST.POST"){
                    $grl = new PermisosGrl;

                    //PERMISOS EMPRESAS
                    $grl->ea = isset($result["permisos"]["empresas"]["create"])?filter_var($result["permisos"]["empresas"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->eb = isset($result["permisos"]["empresas"]["delete"])?filter_var($result["permisos"]["empresas"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->ec = isset($result["permisos"]["empresas"]["update"])?filter_var($result["permisos"]["empresas"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;

                    //PERMISOS AREAS
                    $grl->aa = isset($result["permisos"]["areas"]["create"])?filter_var($result["permisos"]["areas"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->ab = isset($result["permisos"]["areas"]["delete"])?filter_var($result["permisos"]["areas"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->ac = isset($result["permisos"]["areas"]["update"])?filter_var($result["permisos"]["areas"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;

                    //PERMISOS EXPEDIENTES
                    $grl->xa = isset($result["permisos"]["expedientes"]["create"])?filter_var($result["permisos"]["expedientes"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->xc = isset($result["permisos"]["expedientes"]["update"])?filter_var($result["permisos"]["expedientes"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->xb = isset($result["permisos"]["expedientes"]["delete"])?filter_var($result["permisos"]["expedientes"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->pdfv = isset($result["permisos"]["expedientes"]["pdf"])?filter_var($result["permisos"]["expedientes"]["pdf"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->xlsv = isset($result["permisos"]["expedientes"]["excel"])?filter_var($result["permisos"]["expedientes"]["excel"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;

                    //PERMISOS USUARIOS
                    $grl->uv = isset($result["permisos"]["users"]["view"])?filter_var($result["permisos"]["users"]["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->ua = isset($result["permisos"]["users"]["create"])?filter_var($result["permisos"]["users"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->ub = isset($result["permisos"]["users"]["delete"])?filter_var($result["permisos"]["users"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->uc = isset($result["permisos"]["users"]["update"])?filter_var($result["permisos"]["users"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->up = isset($result["permisos"]["users"]["change_password"])?filter_var($result["permisos"]["users"]["change_password"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;

                    //PERMISOS ROLES
                    $grl->rv = isset($result["permisos"]["roles"]["view"])?filter_var($result["permisos"]["roles"]["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->ra = isset($result["permisos"]["roles"]["create"])?filter_var($result["permisos"]["roles"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->rb = isset($result["permisos"]["roles"]["delete"])?filter_var($result["permisos"]["roles"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->rc = isset($result["permisos"]["roles"]["update"])?filter_var($result["permisos"]["roles"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;

                    //PERMISOS LOGS
                    $grl->lv = isset($result["permisos"]["logs"]["view"])?filter_var($result["permisos"]["logs"]["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->lxls = isset($result["permisos"]["logs"]["excel"])?filter_var($result["permisos"]["logs"]["excel"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->lpdf = isset($result["permisos"]["logs"]["pdf"])?filter_var($result["permisos"]["logs"]["pdf"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;

                    //PERMISOS LISTAS
                    $grl->lstv = isset($result["permisos"]["lists"]["view"])?filter_var($result["permisos"]["lists"]["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->lsta = isset($result["permisos"]["lists"]["create"])?filter_var($result["permisos"]["lists"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->lstb = isset($result["permisos"]["lists"]["delete"])?filter_var($result["permisos"]["lists"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    $grl->lstc = isset($result["permisos"]["lists"]["update"])?filter_var($result["permisos"]["lists"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    

                    foreach ($result["permisos"]["registros"] as $registro) {
                    	$perm_reg = new Permisos;
                    	if(!isset($registro["id_expediente"]))
                			throw new CHttpException('027', "No se encuentra definido el parámetro 'id_expediente'");

                		$expediente  = Expedientes::model()->findByPk($registro["id_expediente"]);
                		if(empty($expediente->id_expediente))
                			throw new CHttpException('028', "No existe un expediente con el id '".$registro["id_expediente"]."'");

                    	$perm_reg->id_expediente = $registro["id_expediente"];
                    	$perm_reg->v = isset($registro["view"])?filter_var($registro["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    	$perm_reg->a = isset($registro["create"])?filter_var($registro["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    	$perm_reg->b = isset($registro["delete"])?filter_var($registro["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    	$perm_reg->c = isset($registro["update"])?filter_var($registro["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                        $perm_reg->down = isset($registro["download"])?filter_var($registro["download"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                        $perm_reg->print = isset($registro["print"])?filter_var($registro["print"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):false;
                    	$perm_reg->id_rol = $result["model"]["id_rol"];

                    	if(!$perm_reg->save())
                			throw new CHttpException('400', CJSON::encode($perm_reg->errors));
                    }

                    $grl->id_rol = $result["model"]["id_rol"];
                	if(!$grl->save())
                		throw new CHttpException('400', CJSON::encode($grl->errors));
		            
                }

                if($this->getAction()->getId()==="REST.PUT"){
                	$grl = PermisosGrl::model()->find("id_rol=".$result["model"]["id_rol"]);
                    $old = Roles::model()->findByPk($result["model"]["id_rol"]);
                    $oldGrl = PermisosGrl::model()->find("id_rol=".$result["model"]["id_rol"]);

                	//PERMISOS EMPRESAS
                    $grl->ea = isset($result["permisos"]["empresas"]["create"])?filter_var($result["permisos"]["empresas"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->ea;
                    $grl->eb = isset($result["permisos"]["empresas"]["delete"])?filter_var($result["permisos"]["empresas"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->eb;
                    $grl->ec = isset($result["permisos"]["empresas"]["update"])?filter_var($result["permisos"]["empresas"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->ec;

                    //PERMISOS AREAS
                    $grl->aa = isset($result["permisos"]["areas"]["create"])?filter_var($result["permisos"]["areas"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->aa;
                    $grl->ab = isset($result["permisos"]["areas"]["delete"])?filter_var($result["permisos"]["areas"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->ab;
                    $grl->ac = isset($result["permisos"]["areas"]["update"])?filter_var($result["permisos"]["areas"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->ac;

                    //PERMISOS EXPEDIENTES
                    $grl->xa = isset($result["permisos"]["expedientes"]["create"])?filter_var($result["permisos"]["expedientes"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->xa;
                    $grl->xc = isset($result["permisos"]["expedientes"]["update"])?filter_var($result["permisos"]["expedientes"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->xc;
                    $grl->xb = isset($result["permisos"]["expedientes"]["delete"])?filter_var($result["permisos"]["expedientes"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->xb;
                    $grl->pdfv = isset($result["permisos"]["expedientes"]["pdf"])?filter_var($result["permisos"]["expedientes"]["pdf"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->pdfv;
                    $grl->xlsv = isset($result["permisos"]["expedientes"]["excel"])?filter_var($result["permisos"]["expedientes"]["excel"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->xlsv;

                    //PERMISOS USUARIOS
                    $grl->uv = isset($result["permisos"]["users"]["view"])?filter_var($result["permisos"]["users"]["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->uv;
                    $grl->ua = isset($result["permisos"]["users"]["create"])?filter_var($result["permisos"]["users"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->ua;
                    $grl->ub = isset($result["permisos"]["users"]["delete"])?filter_var($result["permisos"]["users"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->ub;
                    $grl->uc = isset($result["permisos"]["users"]["update"])?filter_var($result["permisos"]["users"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->uc;
                    $grl->up = isset($result["permisos"]["users"]["change_password"])?filter_var($result["permisos"]["users"]["change_password"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->up;

                    //PERMISOS ROLES
                    $grl->rv = isset($result["permisos"]["roles"]["view"])?filter_var($result["permisos"]["roles"]["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->rv;
                    $grl->ra = isset($result["permisos"]["roles"]["create"])?filter_var($result["permisos"]["roles"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->ra;
                    $grl->rb = isset($result["permisos"]["roles"]["delete"])?filter_var($result["permisos"]["roles"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->rb;
                    $grl->rc = isset($result["permisos"]["roles"]["update"])?filter_var($result["permisos"]["roles"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->rc;

                    //PERMISOS LOGS
                    $grl->lv = isset($result["permisos"]["logs"]["view"])?filter_var($result["permisos"]["logs"]["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->lv;
                    $grl->lxls = isset($result["permisos"]["logs"]["excel"])?filter_var($result["permisos"]["logs"]["excel"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->lxls;
                    $grl->lpdf = isset($result["permisos"]["logs"]["pdf"])?filter_var($result["permisos"]["logs"]["pdf"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->lpdf;

                    //PERMISOS LISTAS
                    $grl->lstv = isset($result["permisos"]["lists"]["view"])?filter_var($result["permisos"]["lists"]["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->lstv;
                    $grl->lsta = isset($result["permisos"]["lists"]["create"])?filter_var($result["permisos"]["lists"]["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->lsta;
                    $grl->lstb = isset($result["permisos"]["lists"]["delete"])?filter_var($result["permisos"]["lists"]["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->lstb;
                    $grl->lstc = isset($result["permisos"]["lists"]["update"])?filter_var($result["permisos"]["lists"]["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$grl->lstc;

                    foreach ($result["permisos"]["registros"] as $registro) {
                    	if(!isset($registro["id_expediente"]))
                			throw new CHttpException('027', "No se encuentra definido el parámetro 'id_expediente'");

                		$expediente  = Expedientes::model()->findByPk($registro["id_expediente"]);
                		if(empty($expediente->id_expediente))
                			throw new CHttpException('028', "No existe un expediente con el id '".$registro["id_expediente"]."'");

                    	$perm_reg = Permisos::model()->find("id_expediente=".$registro["id_expediente"]." and id_rol=".$result["model"]["id_rol"]);
                    	if(empty($perm_reg->id_permiso))
                    		$perm_reg = new Permisos;

                    	$perm_reg->id_expediente = $registro["id_expediente"];
                    	$perm_reg->v = isset($registro["view"])?filter_var($registro["view"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$perm_reg->v;
                    	$perm_reg->a = isset($registro["create"])?filter_var($registro["create"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$perm_reg->a;
                    	$perm_reg->b = isset($registro["delete"])?filter_var($registro["delete"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$perm_reg->b;
                    	$perm_reg->c = isset($registro["update"])?filter_var($registro["update"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$perm_reg->c;
                        $perm_reg->down = isset($registro["download"])?filter_var($registro["download"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$perm_reg->c;
                        $perm_reg->print = isset($registro["print"])?filter_var($registro["print"],FILTER_VALIDATE_BOOLEAN,FILTER_NULL_ON_FAILURE):$perm_reg->c;
                    	$perm_reg->id_rol = $result["model"]["id_rol"];

                    	if(!$perm_reg->save())
                			throw new CHttpException('400', CJSON::encode($perm_reg->errors));
                    }

                    if(!$grl->save())
                		throw new CHttpException('400', CJSON::encode($grl->errors));
                }

                $transaction->commit();
            }
            catch(Exception $ex){
                $transaction->rollBack();
                Roles::model()->findByPk($result["model"]["id_rol"])->delete();
                throw new CHttpException($ex->statusCode, $ex->getMessage());
                
            }

            return $result["model"];
        });

		//ANTES DE BORRAR UN ROL
        $this->onRest('pre.filter.model.delete', function($model) {
        	$transaction = Yii::app()->db->beginTransaction();
            try{
                $usuarios = Users::model()->findAll("id_tipo=".$model["id_rol"]);
                if(count($usuarios)>0)
					throw new CHttpException('029', "No se puede eliminar un rol que se encuentra asignado");
                	
                //BORRAMOS LOS PERMISOS
                $permisos = Permisos::model()->deleteAll('id_rol='.$model['id_rol']);
                $permisosGrl = PermisosGrl::model()->deleteAll('id_rol='.$model['id_rol']);
                
                
                $transaction->commit();
            }
            catch(Exception $e){
                $transaction->rollBack();
                throw new CHttpException($e->statusCode, $e->getMessage());
            }

            return $model;

        });

        //DESPUES DE BORRAR UN ROL
        $this->onRest('post.filter.model.delete', function($result) {
            $old = new Roles;
            $this->saveLog(Yii::app()->controller->action->id,array($old),array($result),Yii::app()->controller->id,$this->getUser()->id_usuario);
            return $result;
        });
    }

    private function createLog($result){
		$user = Users::model()->findByPk(Yii::app()->params["idApiUser"]);
		$logs = new Log();
		switch ($this->getAction()->getId()) {
			case 'REST.POST':
				$logs->movimiento= sprintf("ROL %s AGREGADO",$result->nombre);	
				break;
			case 'REST.PUT':
				$logs->movimiento= sprintf("ROL %s MODIFICADO ",$result->nombre);
				break;
			case 'REST.DELETE':
				$logs->movimiento= sprintf("ROL %s ELIMINADO",$result->nombre);
				break;
			default:
				return false;
				break;
		}
		
		$logs->nombre=sprintf("%s %s %s",$user->apellido_p,$user->apellido_m,$user->nombre);
		$logs->correo=$user->email;
		$logs->id_usuario=$user->id_usuario;
		$logs->save();
	}

}