<?php

class SiteController extends Controller
{
	/**
	 * Declares class-based actions.
	 */
	public function actions()
	{
		return array(
			// captcha action renders the CAPTCHA image displayed on the contact page
			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,
			),
			// page action renders "static" pages stored under 'protected/views/site/pages'
			// They can be accessed via: index.php?r=site/page&view=FileName
			'page'=>array(
				'class'=>'CViewAction',
			),
		);
	}

	private function renameToUpper($cadena,$isName){
		$charToReplace =[" ",$isName?"":".","á","é","í","ó","ú","ñ"];
		$charForReplace=["_",$isName?"":"","a","e","i","o","u","n"];
		$result =$cadena;
		for ($i = 0; $i < count($charToReplace); $i++) {
			$result =str_replace($charToReplace[$i],$charForReplace[$i],$result);
		}
		return strtoupper($result);
	}

	public function actionError(){
		if($error=Yii::app()->errorHandler->error){
			if($error['code']==500)
				echo CHtml::encode($error['message']);
			else
        		$this->renderPartial('error', array('error'=>$error));
		}
	}

	public function actionIndex(){
		$archivo64 = $this->convertFileToBase64("CAMPECHE_YUCATAN.pdf");
		echo $archivo64;
		echo "<hr/>";
		$encriptado= $this->encrypt($archivo64);
		$this->convertBase64ToFile($encriptado,"testencriptado.pdf");
		echo $encriptado;
		echo "<hr/>";
		$desencriptado =$this->decrypt($encriptado);
		echo $desencriptado;
		echo "<hr/>";
		echo $this->convertFileToBase64("testencriptado.pdf");
	}

} 