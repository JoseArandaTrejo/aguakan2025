<?php

class ListasController extends Controller
{

    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
            array(
                'ext.starship.RestfullYii.filters.ERestFilter + 
                REST.GET, REST.PUT, REST.POST, REST.DELETE'
            ),
        );
    }

    public function accessRules()
    {
        return array(
            array(
                'allow',
                'actions' => array('REST.GET', 'REST.PUT', 'REST.POST', 'REST.DELETE'),
                'users' => array('*'),
            ),
            array(
                'allow',
                'actions' => array('index', 'create', 'update', 'save', 'remove', 'getListas'),
                'users' => array('@'),
            ),

            array(
                'deny',

                'users' => array('*'),

            ),


        );
    }

    public function actions()
    {
        return array('REST.' => 'ext.starship.RestfullYii.actions.ERestActionProvider',);
    }

    public function actionRemove()
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        if (boolval($session["permisos"]["lists"]["delete"]))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->delete($this->getApiUrl("listas/" . $_POST['id']));
        else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    public function actionIndex()
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        if (!boolval($session["permisos"]["lists"]["view"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        $this->render('index', array("permisos" => $session["permisos"]["lists"]));
    }

    public function actionCreate()
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        if (!boolval($session["permisos"]["lists"]["create"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        $this->render('_formLista', array("titulo" => "Nueva Lista", "permisos" => $session["permisos"]["lists"]));
    }

    public function actionUpdate($id)
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        if (!boolval($session["permisos"]["lists"]["update"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        $data = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("listas/" . $id));
        $data = CJSON::decode($data)["data"]["listas"];
        $this->render('_formLista', array("titulo" => "Editar Lista", "permisos" => $session["permisos"]["lists"], "model" => $data));
    }

    public function actionSave()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $model = $_POST;
        if (!empty($model["id"]) && boolval($session["permisos"]["lists"]["update"]))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("listas/" . $model["id"]), CJSON::encode($model));
        else if (empty($model["id"]) && (boolval($session["permisos"]["lists"]["create"])))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->post($this->getApiUrl("listas"), CJSON::encode($model));
        else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    public function restEvents()
    {

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN UPDATE
        $this->onRest('req.put.resource.render', function ($model, $relations, $visibleProperties = [], $hiddenProperties = []) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("Lista '<b>%s</b>' actualizada", $model->nombre),
                'totalCount'    => "1",
                'modelName'     => get_class($model),
                'relations'     => $relations,
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN CREATE
        $this->onRest('req.post.resource.render', function ($model, $relations, $visibleProperties = [], $hiddenProperties = []) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("Lista '<b>%s</b>' creada", $model->nombre),
                'totalCount'    => "1",
                'modelName'     => get_class($model),
                'relations'     => $relations,
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER DELETE
        $this->onRest('req.delete.resource.render', function ($model, $visibleProperties = [], $hiddenProperties = []) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("Lista '<b>%s</b>' eliminada", $model->nombre),
                'totalCount'        => "1",
                'modelName'         => get_class($model),
                'relations'         => [],
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        $this->onRest('post.filter.req.auth.ajax.user', function ($validation) {
            switch ($this->getAction()->getId()) {
                default:
                    return $validation;
                    break;
            }
        });

        $this->onRest('post.filter.req.auth.user', function ($validation) {
            switch ($this->getAction()->getId()) {
                default:
                    return $validation;
                    break;
            }
        });

        //HACEMOS OVERRIDE AL EVENTO ENCARGADO DE RECUPERAR LOS VALORES
        $this->onRest('model.listas.override.attributes', function ($model) {
            //OBTENEMOS EL TIPO DE LLAMADO
            switch ($this->getAction()->getId()) {
                default:
                    $model["lista"] = explode(",", $model["lista"]);
                    return $model;
                    break;
            }
        });

        $this->onRest('pre.filter.model.apply.post.data', function ($model, $data, $restricted_properties) {
            $lista_string = null;
            if (!isset($data["nombre"]))
                throw new CHttpException('020', "El párametro 'nombre' no se encuentra definido");
            if (!isset($data["lista"]) || empty($data["lista"]))
                throw new CHttpException('021', "El párametro 'lista' no se encuentra definido o está vacío");

            foreach ($data["lista"] as $list)
                if (!empty($list))
                    $lista_string .= str_replace(",", "", trim($list)) . ",";

            $data["lista"] = substr($lista_string, 0, strlen($lista_string) - 1);
            return [$model, $data, $restricted_properties];
        });

        $this->onRest('pre.filter.model.apply.put.data', function ($model, $data, $restricted_properties) {
            $lista_string = null;
            if (isset($data["lista"]) && !empty($data["lista"])) {
                foreach ($data["lista"] as $list)
                    if (!empty($list))
                        $lista_string .= str_replace(",", "", trim($list)) . ",";

                $data["lista"] = substr($lista_string, 0, strlen($lista_string) - 1);
            }

            return [$model, $data, $restricted_properties];
        });

        $this->onRest('pre.filter.model.delete', function ($model) {
            $listaExp = ListaExp::model()->findAll("id_lista=" . $model["id"]);
            if (count($listaExp) > 0)
                throw new CHttpException('022', "No se puede eliminar una lista que se encuentra en uso");

            return $model;
        });

        //LOG PARA CREATE
        $this->onRest('model.apply.post.data', function ($model, $data, $restricted_properties) {
            $result = $this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties);
            if ($result->validate()) {
                $this->saveLog(Yii::app()->controller->action->id, array(new $model), array($data), Yii::app()->controller->id, $this->getUser()->id_usuario);
            }
            return $result;
        });

        //LOG PARA UPDATE
        $this->onRest('model.apply.put.data', function ($model, $data, $restricted_properties) {
            $result = $this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties);
            if ($result->validate()) {
                $old = $model::model()->findByPk($model->id);
                $this->saveLog(Yii::app()->controller->action->id, array($old), array($data), Yii::app()->controller->id, $this->getUser()->id_usuario);
            }
            return $result;
        });

        //LOG PARA DELETE
        $this->onRest('post.filter.model.delete', function ($result) {
            $this->saveLog(Yii::app()->controller->action->id, array(new Listas), array($result), Yii::app()->controller->id, $this->getUser()->id_usuario);
            return $result;
        });
    }

    public function actionGetListas()
    {
        $data = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("listas"));
        $data = CJSON::decode($data)["data"]["listas"];
        echo CJSON::encode(array("data" => $data));
    }
}
