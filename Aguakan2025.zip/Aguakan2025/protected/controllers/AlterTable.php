<?php

class AlterTable
{
	//{return}	integer	number of rows affected by the execution.
    public function addColumn($table,$column,$type){
        $connection = Yii::app()->db;
        return $connection->createCommand()->addColumn($table,$column,$type);
    }

    //{return}	integer	number of rows affected by the execution.
    public function alterColumn($table,$column,$type){
        $connection = Yii::app()->db;
        return $connection->createCommand()->alterColumn($table,$column,$type);
    }

    //{return}	integer	0 is always returned
    public function createTable($table,$columns,$options=NULL){
        $connection = Yii::app()->db;
        return $connection->createCommand()->createTable($table,$columns,$options);
    }

    //{return}	integer	number of rows affected by the execution.
    public function dropColumn($table,$column){
        $connection = Yii::app()->db;
        return $connection->createCommand()->dropColumn($table,$column);
    }

    //{return}  integer 0 is always returned
    public function dropTable($table){
        $connection = Yii::app()->db;
        return $connection->createCommand()->dropTable($table);
    }


    //{return}  integer number of rows affected by the execution.
    public function renameColumn($table,$name,$newName){
        $connection = Yii::app()->db;
        return $connection->createCommand()->renameColumn($table,$name,$newName);
    }

    //{return}  integer 0 is always returned
    public function renameTable($table,$newName){
        $connection = Yii::app()->db;
        return $connection->createCommand()->renameTable($table,$newName);
    }

    //{return}  integer 0 is always returned
    public function truncateTable($table){
        $connection = Yii::app()->db;
        return $connection->createCommand()->truncateTable($table);
    }
}