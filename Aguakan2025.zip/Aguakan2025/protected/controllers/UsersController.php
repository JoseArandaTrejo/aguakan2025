<?php

class UsersController extends Controller
{
	
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			array(
                'ext.starship.RestfullYii.filters.ERestFilter + 
                REST.GET, REST.PUT, REST.POST, REST.DELETE'
            ),
		);
	}

	public function accessRules()
	{
		return array( 
            array('allow', 'actions'=>array('REST.GET', 'REST.PUT', 'REST.POST'),
                'users'=>array('*'),
            ),
            array('allow','actions'=>array('index','changeStatus','changePassword','save'),
                'users'=>array('@'),
            ),

            array('deny', 

                'users'=>array('*'), 

            ),


        );

	}
	
    public function actions()
	{
        return array('REST.'=>'ext.starship.RestfullYii.actions.ERestActionProvider',);
	}

    public function actionChangeStatus(){
        //PERMISOS
        $this->getUserAccess();
        $session=new CHttpSession;
        $session->open();

        if(!boolval($session["permisos"]["users"]["delete"]))
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
        else
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("users/status/".$_POST['id']),CJSON::encode(array('status'=>$_POST['status'])));
    }

    public function actionChangePassword() {
        //PERMISOS
        $this->getUserAccess();
        $session=new CHttpSession;
        $session->open();

        if(!boolval($session["permisos"]["users"]["change_password"]))
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
        else{
            $this->saveLog("Cambiar Contraseña",null,null,Yii::app()->controller->id,Yii::app()->user->id);
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("users/password/".$_POST['id']),CJSON::encode(array("password"=>md5($_POST['password']))));
        }
    }

    public function actionIndex(){
        //PERMISOS
        $this->getUserAccess();
        $session=new CHttpSession;
        $session->open();

        if(!boolval($session["permisos"]["users"]["view"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        $data = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("users",isset($_POST['filters'])?$_POST['filters']:null));

        $dataRoles = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("roles"));

        $data =CJSON::decode($data)["data"];
        $dataRoles =CJSON::decode($dataRoles)["data"];
        
        $usuarios = $data["users"];
        $roles = $dataRoles["roles"];

        $dataProvider=new CArrayDataProvider($usuarios, array(
            'keyField'=>'id_usuario',
            'id'=>'usuarios',
            'sort'=>array(
                'attributes'=>array(
                    'id_usuario',
                    'nombre',
                    'email',
                ),
            ),
            'pagination'=>array(
                'pageSize'=>12,
            ),
        ));

        if(isset($_POST['filters']))
            $this->renderPartial("_listView",array("usuarios"=>$dataProvider,"permisos"=>$session["permisos"]["users"],"pRoles"=>$session["permisos"]["roles"]));
        else
            $this->render("index",array("usuarios"=>$dataProvider,"permisos"=>$session["permisos"]["users"],"pRoles"=>$session["permisos"]["roles"],"roles"=>$roles));
    }

    public function actionSave(){
        $this->getUserAccess();
        $session=new CHttpSession;
        $session->open();
        
        $model = $_POST['Users'];

        if(!empty($_FILES['image']['name'])){
            $attributes = array("file"=>base64_encode(file_get_contents($_FILES['image']['tmp_name'])),"filename"=>$_FILES['image']['name']);
            $model = array_merge($model, array("picture"=>$attributes));
        }

        if(!empty($model["id_usuario"]) && boolval($session["permisos"]["users"]["update"])){
            unset($model["password"]);
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("users/".$model["id_usuario"]),CJSON::encode($model));
        }
        else if(empty($model["id_usuario"]) && (boolval($session["permisos"]["users"]["create"]))){
            $model["password"] = md5($model["password"]);
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->post($this->getApiUrl("users"),CJSON::encode($model));
        }
        else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    public function restEvents(){

        //EVENTO PARA AGREGAR EL ATRIBUTO rol_name a los usuarios
        $this->onRest('model.users.override.attributes', function($model) {
           return array_merge($model->attributes, array('rol_name'=>$model->rol));
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN UPDATE
        $this->onRest('req.put.resource.render',function($model, $relations, $visibleProperties=[], $hiddenProperties=[]) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("Usuario '<b>%s %s %s</b>' actualizado",$model->nombre,$model->apellido_p,$model->apellido_m),
                'totalCount'    => "1",
                'modelName'     => get_class($model),
                'relations'     => $relations,
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN CREATE
        $this->onRest('req.post.resource.render',function($model, $relations, $visibleProperties=[], $hiddenProperties=[]) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("Usuario '<b>%s %s %s</b>' creado",$model->nombre,$model->apellido_p,$model->apellido_m),
                'totalCount'    => "1",
                'modelName'     => get_class($model),
                'relations'     => $relations,
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        //EVITAMOS LOS LLAMADOS AJAX DELETE SOBRE LOS USUARIOS
        $this->onRest('post.filter.req.auth.ajax.user', function($validation) {
            switch ($this->getAction()->getId()) {
                case 'REST.DELETE':
                    return false;
                    break;
                default:
                    return $validation;
                    break;
            }
        });

        //EVITAMOS LOS LLAMADOS DELETE SOBRE LOS USUARIOS
        $this->onRest('post.filter.req.auth.user', function($validation) {
            switch ($this->getAction()->getId()) {
                case 'REST.DELETE':
                    return false;
                    break;
                default:
                    return $validation;
                    break;
            }
        });

        $this->onRest('pre.filter.model.apply.post.data', function($model, $data, $restricted_properties){

            if(isset($data["picture"]) && !empty($data["picture"])){
                $name_aux="";
                if(empty($data["picture"]["filename"]))
                    throw new CHttpException('011', "El atributo 'filename' no puede estar vacio.");
                else
                    $data["image"] = date("dmYHis").$data["picture"]["filename"];

                if($this->convertBase64ToFile($data["picture"]["file"],$data["image"],"users")===false)
                    throw new CHttpException('010', "Error al subir el archivo.");

                unset($data["picture"]);
            }
            return [$model, $data, $restricted_properties];
        });

        $this->onRest('pre.filter.model.apply.put.data', function($model, $data, $restricted_properties){
            if(isset($data["picture"]) && !empty($data["picture"])){
                $name_aux="";
                if(empty($data["picture"]["filename"]))
                    throw new CHttpException('011', "El atributo 'filename' no puede estar vacio.");
                else
                    $data["image"] = date("dmYHis").$data["picture"]["filename"];

                if($this->convertBase64ToFile($data["picture"]["file"],$data["image"],"users")===false)
                    throw new CHttpException('010', "Error al subir el archivo.");

                unset($data["picture"]);
            }

            return [$model, $data, $restricted_properties];
        });

        //ANTES DE LLAMAR AL EVENTO PARA SALVAR
        $this->onRest('pre.filter.model.save', function($model) {
            if(!isset($model["nombre"]))
                throw new CHttpException("030","El parámetro 'nombre' no se encuentra definido");
            if(!isset($model["email"]))
                throw new CHttpException("031","El parámetro 'email' no se encuentra definido");
            if(!isset($model["password"]))
                throw new CHttpException("032","El parámetro 'password' no se encuentra definido");

            if(!isset($model["id_tipo"]))
                throw new CHttpException("033","El parámetro 'id_tipo' no se encuentra definido");

            $rol = Roles::model()->findByPk($model["id_tipo"]);
            if(empty($rol->id_rol))
                throw new CHttpException("034","No existe un rol con el id '".$model["id_tipo"]."'");
            

            if(!isset($model["status"]))
                $model["status"]="activo";
            return $model;
        });

        //LOG PARA CREATE
        $this->onRest('model.apply.post.data', function($model, $data, $restricted_properties) {
            $result = $this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties,['password','serial','fecha_expira']);
            $result["status"] = 'activo';
            if($result->validate()){
                $old = new $model;
                $this->saveLog(Yii::app()->controller->action->id,array($old),array($data),Yii::app()->controller->id,$this->getUser()->id_usuario);
            }
            return $result;
        });

        //EN EL EVENTO PUT PASAMOS LAS PROPIEDADES RESTRINGIDAS
        $this->onRest('model.apply.put.data', function($model, $data, $restricted_properties) {
            $result = $this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties,['password','serial','fecha_expira']);
            if($result->validate()){
                $old = $model::model()->findByPk($model->id_usuario);
                $this->saveLog(Yii::app()->controller->action->id,array($old),array($data),Yii::app()->controller->id,$this->getUser()->id_usuario);
            }
            return $result;
        });

        //EVENTO PUT PARA ACTUALIZAR LA CONTRASEÑA DE UN USUARIO
        $this->onRest('req.put.password.render', function($data,$id) {
                
                //VALIDAMOS QUE ENVIEN EL PASSWORD e ID_USUARIO
                if(isset($data['password'])){
                    $model = Users::model()->findByPk($id);
                    if(is_null($model))
                        throw new CHttpException(404, "RESOURCE ".$id." NOT FOUND");
                    $model->password =$data['password'];
                    if($model->save()){
                        echo CJSON::encode(['success'=>true,'message'=>'Contraseña actualizada','data'=>['totalCount'=>1,'users'=>$model]]);
                    }else{
                        throw new CHttpException('400', CJSON::encode($model->errors));
                    }
                }
                else{
                    throw new CHttpException("032","El parámetro 'password' no se encuentra definido");
                }
        });

        //EVENTO PUT PARA ACTUALIZAR EL STATUS DEL USUARIOS
        $this->onRest('req.put.status.render', function($data,$id) {
            //VALIDAMOS QUE ENVIEN EL STATUS e ID_USUARIO
            if(isset($data['status'])){
                $model = Users::model()->findByPk($id);
                $old = Users::model()->findByPk($id);
                if(is_null($model))
                    throw new CHttpException(404, "RESOURCE ".$id." NOT FOUND");
                $model->status =$data['status']==="activo"?"activo":"inactivo";
                if($model->save()){
                    $this->saveLog(Yii::app()->controller->action->id,array($old),array($model),Yii::app()->controller->id,$this->getUser()->id_usuario);
                    echo CJSON::encode(["success"=>true,"message"=>sprintf("El Status del usuario '<b>%s %s</b>' cambió a '<b>%s</b>'",$model->nombre,$model->apellido_p,$model->status),"data"=>["totalCount"=>1,"users"=>$model]]);
                }else{
                    throw new CHttpException('400', CJSON::encode($model->errors));
                }
            }
            else{
                throw new CHttpException("035","El parámetro 'status' no se encuentra definido");
            }
        });      
    }

}