<?php

class LogsController extends Controller
{

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			array(
                'ext.starship.RestfullYii.filters.ERestFilter + 
                REST.GET, REST.PUT, REST.POST, REST.DELETE'
            ),
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array( 
            array('allow', 'actions'=>array('REST.GET', 'REST.POST','REST.DELETE'),
                'users'=>array('*'),
            ),
            array('allow','actions'=>array('index','view','getLogs','pdf','excel'),
            	'users'=>array('@'),
        	),

            array('deny', 

                'users'=>array('*'), 
            ),
        );

	}

	public function actions()
	{
        return array('REST.'=>'ext.starship.RestfullYii.actions.ERestActionProvider',);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		//PERMISOS
		$this->getUserAccess();
		$session=new CHttpSession;
  		$session->open();

  		if(!boolval($session["permisos"]["logs"]["view"]))
        	throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

		$model = $this->loadModel($id);
		$color ="primary";
		if (in_array($model->accion,Yii::app()->params['dangerActions']))
			$color = "danger";
		elseif(in_array($model->accion,Yii::app()->params['successActions']))
			$color = "success";
		elseif(in_array($model->accion,Yii::app()->params['warningActions']))
			$color ="warning";

		$this->render('view',array(
			'model'=>$model,"color"=>$color
		));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		//PERMISOS
		$this->getUserAccess();
		$session=new CHttpSession;
  		$session->open();

  		if(!boolval($session["permisos"]["logs"]["view"]))
        	throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        $this->render('index',array("permisos"=>$session["permisos"]["logs"]));
	}


	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer the ID of the model to be loaded
	 */
	public function loadModel($id)
	{
		$model=Logs::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param CModel the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='logs-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}

	public function restEvents(){

		//EVENTO PARA AGREGAR EL ATRIBUTO INFO A LOS EXPEDIENTES
		$this->onRest('model.logs.override.attributes', function($model) {
		   return array_merge($model->attributes, array('fecha_formated'=>$model->fechaModificacionLarge,'username'=>$model->userFullname,'modulo_friendly'=>Yii::t("logs",$model->modulo),'accion_friendly'=>Yii::t("logs",$model->accion)));
		});
		
	}

	public function actionGetLogs(){
		$this->getUserAccess();
		$session=new CHttpSession;
  		$session->open();

  		$filters=array();
  		if(isset($_POST['filters']) && !empty($_POST['filters'])){
  			foreach ($_POST['filters'] as $filter) {
  				if(!empty($filter["value"])){
	  				if($filter["name"] !== "fecha_modificacion")
	  					array_push($filters, array("property"=>$filter["name"],"value"=>$filter["value"],"operator"=>"="));
	  				else{
	  					array_push($filters, array("property"=>$filter["name"],"value"=>implode("-",array_reverse(explode("/",explode(" al ",$filter["value"])[0])))." 00:00:00","operator"=>">="));
	  					array_push($filters, array("property"=>$filter["name"],"value"=>implode("-",array_reverse(explode("/",explode(" al ",$filter["value"])[1])))." 23:59:59","operator"=>"<="));
	  				}
  				}
  			}
  		}
  		
		$data =Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("logs",empty($filters)?null:CJSON::encode($filters),CJSON::encode(array(array("property"=>"id","direction"=>"DESC")))));
		$data= CJSON::decode($data)["data"];
		$logs = $data["logs"];
		$session["logs"] = $logs;
		echo CJSON::encode(array("data"=>$logs));
	}

	public function actionExcel(){
		$this->getUserAccess();
		$session=new CHttpSession;
  		$session->open();

  		if(!boolval($session["permisos"]["logs"]["excel"]))
        	throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        Yii::app()->request->sendFile("Reporte_logs_".date("dmYHis").'.xls',
            $this->renderPartial('_reporte', array("logs"=>$session["logs"],'config'=>array('logoSide'=>'left','title'=>Yii::app()->name,'logo'=>Yii::app()->params['logo'])), true)
        );
	}

	public function actionPdf(){
		$this->getUserAccess();
		$session=new CHttpSession;
  		$session->open();

  		if(!boolval($session["permisos"]["logs"]["pdf"]))
        	throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

  		Yii::import('application.extensions.bootstrap.gii.*');
		require_once('bootstrap/tcpdf/tcpdf.php');
		require_once('bootstrap/tcpdf/config/lang/eng.php');

		$pdf = new TCPDF();
		$pdf->SetCreator(PDF_CREATOR);
		$pdf->SetAuthor(Yii::app()->name);
		$pdf->SetMargins(15, 18, 15);
		$pdf->SetHeaderMargin(5);
		$pdf->SetFooterMargin(10);
		$pdf->SetAutoPageBreak(TRUE, 15);
		$pdf->SetFont('dejavusans', '', 7);
		$pdf->SetPrintHeader(false);
		$pdf->AddPage();

  		$html = $this->renderPartial('_reporte',array("logs"=>$session["logs"],'config'=>array('logoSide'=>'left','title'=>Yii::app()->name,'logo'=>Yii::app()->params['logo'])),true);
		$pdf->writeHTML($html, true, false, true, false, '');
		$pdf->LastPage();
		$pdf->Output("Reporte_logs_".date("dmYHis"), "I");

	}
}
