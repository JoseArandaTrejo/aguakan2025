<?php

class ExpedientesController extends Controller
{

    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
            array(
                'ext.starship.RestfullYii.filters.ERestFilter + 
                REST.GET, REST.PUT, REST.POST, REST.DELETE'
            ),
        );
    }

    public function accessRules()
    {
        return array(
            array(
                'allow',
                'actions' => array('REST.GET', 'REST.PUT', 'REST.POST', 'REST.DELETE'),
                'users' => array('*'),
            ),
            array(
                'allow',
                'actions' => array('index', 'save', 'remove', 'getExpByArea', 'create', 'records', 'newRecord', 'updateRecord', 'saveRecord', 'search', 'preview', 'multiple', 'removeRecord', 'addFile', 'deleteFile', 'excel', 'pdf', 'uploadMassive', 'downloadDemo', 'createZip', 'deleteZip', 'getUUID'),
                'users' => array('@'),
            ),
            array(
                'deny',

                'users' => array('*'),

            ),


        );
    }

    public function actions()
    {
        return array('REST.' => 'ext.starship.RestfullYii.actions.ERestActionProvider',);
    }

    public function actionPreview($uuid)
    {
        ini_set('memory_limit', '-1');
        ini_set('MAX_EXECUTION_TIME', '-1');

        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //ID_EXPEDIENTE, ID REGISTRO, NOMBRE DE LA PROPIEDAD
        $values = explode("-", $uuid);
        $idExpediente = $this->decrypt($values[0]);
        $id = $this->decrypt($values[1]);
        $attribute = $this->decrypt($values[2]);


        if (count($values) < 3 || intval($idExpediente) == 0 || intval($id) == 0)
            throw new CHttpException(404, "No se encontró la vista solicitada");


        $permisos = array();

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $idExpediente)
                $permisos = $permiso;

        if (!boolval($permisos["view"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        $records = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/records/" . $idExpediente, CJSON::encode(array(array("property" => "id", "value" => $id, "operator" => "=")))));

        $records = CJSON::decode($records)["data"]["records"];

        if (empty($records))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        $record;
        if (count($values) == 3)
            $record = $records[0][$attribute];
        elseif (count($values) == 4) {
            foreach ($records[0][$attribute] as $file) {
                if ($file['id'] == $this->decrypt($values[3]))
                    $record = $file;
            }
        }


        $base64 = Yii::app()->params["show_file_base64"] ? $record["file"] : $this->convertFileToBase64(basename($record["path"]));
        $fileUrl = str_replace("\\", "/", Yii::app()->baseUrl . DIRECTORY_SEPARATOR . "fls" . DIRECTORY_SEPARATOR . basename($record["path"]));

        $record["mime"] = $this->getFileMime($base64);

        $options = array(
            'sideBarOpen' => false,
            'direction' => 'ltr',
            'buttons' => array(
                'sidebarToggle' => true,
                'viewFind' => true,
                'previous' => true,
                'next' => true,
                'zoomIn' => true,
                'zoomOut' => true,
                'scaleSelect' => true,
                'presentationMode' => true,
                'print' => $permisos["print"],
                'openFile' => false,
                'download' => $permisos["download"],
                'viewBookmark' => false,
            )
        );

        switch (true) {
            case $record["mime"] === 'application/pdf':
                $visor = "_pdfViewer";
                break;
            case (is_int(strpos($record["mime"], 'image'))):
                $visor = "_imgViewer";
                break;
            default:
                $visor = "_download";
                break;
        }

        $this->saveLog(Yii::app()->controller->action->id, array(array("mime" => null, "filename" => null, "path" => null, "uuid" => null)), array($record), Yii::app()->controller->id, Yii::app()->user->id);

        $this->renderPartial(
            $visor,
            array(
                "options" => $options,
                "url" => $fileUrl,
                "mime" => $record["mime"],
                "title" => $record["filename"]
            )
        );
    }

    public function actionGetUUID()
    {
        $valores = explode("-", $_POST['uuid']);
        $result = array();
        foreach ($valores as $valor)
            array_push($result, $this->encrypt($valor));

        echo implode("-", $result);
    }

    public function actionMultiple($uuid)
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //ID_EXPEDIENTE, ID REGISTRO, NOMBRE DE LA PROPIEDAD, ID ARCHIVOs
        $values = explode("-", $uuid);
        $idExpediente = $this->decrypt($values[0]);
        $idRecord = $this->decrypt($values[1]);
        $attribute = $this->decrypt($values[2]);
        //$id = $this->decrypt($values[3]);

        if (count($values) < 3 || intval($idExpediente) == 0 || intval($idRecord) == 0 /*|| intval($id) == 0*/)
            throw new CHttpException(404, "No se encontró la vista solicitada");

        //OBTENEMOS EL AREA Y LA EMPRESA
        $expediente = Expedientes::model()->findByPk($idExpediente);
        if (empty($expediente->id_expediente))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        $area = Areas::model()->findByPk($expediente->id_area);
        $empresa = Empresas::model()->findByPk($area->id_empresa);

        $permisos = array();

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $idExpediente)
                $permisos = $permiso;

        if (!boolval($permisos["view"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        $records = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/records/" . $idExpediente, CJSON::encode(array(array("property" => "id", "value" => $idRecord, "operator" => "=")))));

        $records = CJSON::decode($records)["data"]["records"][0][$attribute];

        /*if(empty($records))
            throw new CHttpException(404, "No se encontró la vista solicitada");*/

        $options = array(
            'sideBarOpen' => false,
            'direction' => 'ltr',
            'buttons' => array(
                'sidebarToggle' => true,
                'viewFind' => true,
                'previous' => true,
                'next' => true,
                'zoomIn' => true,
                'zoomOut' => true,
                'scaleSelect' => true,
                'presentationMode' => true,
                'print' => true,
                'openFile' => false,
                'download' => true,
                'viewBookmark' => false,
            )
        );

        $this->render("_multiple", array("records" => $records, "options" => $options, "attribute" => $attribute, "empresa" => $empresa, "area" => $area, "expediente" => $expediente, "permisos" => $permisos, "uuid" => $uuid));
    }

    public function actionIndex($slug)
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA
        $id = Areas::model()->getIdFromSlug($slug);
        $area = Areas::model()->findByPk($id);

        //SE VALIDA QUE LA AREA EXISTA ANTES DE INTENTAR IR POR SUS EXPEDIENTES
        if (empty($area))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        //BUSCAR LA MANERA DE VALIDAR SI PUEDE ESTARDENTRO DE ESTA AREA

        $empresa = Empresas::model()->findByPk($area->id_empresa);

        $filters = CJSON::encode(array(array("property" => "id_area", "value" => $id, "operator" => "="), isset($_POST['filters']) ? CJSON::decode($_POST['filters']) : null));

        $data = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes", $filters));

        $data = CJSON::decode($data)["data"];

        $expedientes = $data["expedientes"];

        foreach ($expedientes as $index => $expediente)
            $expedientes[$index]["slug"] = Expedientes::model()->findByPk($expediente["id_expediente"])->slug;

        $dataProvider = new CArrayDataProvider($expedientes, array(
            'keyField' => 'id_expediente',
            'id' => 'expedientes',
            'sort' => array(
                'attributes' => array(
                    'id_expediente',
                    'nombre'
                ),
            ),
            'pagination' => array(
                'pageSize' => 12,
            ),
        ));

        if (isset($_POST['filters']))
            $this->renderPartial("_listView", array("expedientes" => $dataProvider, "empresa" => $empresa, "area" => $area, "permisos" => $session["permisos"]["expedientes"]));
        else
            $this->render('index', array("expedientes" => $dataProvider, "empresa" => $empresa, "area" => $area, "permisos" => $session["permisos"]["expedientes"]));
    }

    public function actionCreate($slug)
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA
        $id = Areas::model()->getIdFromSlug($slug);
        $area = Areas::model()->findByPk($id);
        $empresa = Empresas::model()->findByPk($area->id_empresa);

        $data = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("listas"));

        $data = CJSON::decode($data)["data"];

        $listas = $data["listas"];

        $this->render('create', array("empresa" => $empresa, "area" => $area, "permisos" => $session["permisos"]["expedientes"], "listas" => $listas, "extraFields" => Yii::app()->params['createExtraFields'] ? Yii::app()->params['extraFields'] : array()));
    }

    public function actionNewRecord($slug)
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA Y LA EMPRESA
        $id = Expedientes::model()->getIdFromSlug($slug);
        $expediente = Expedientes::model()->findByPk($id);

        //SE VALIDA QUE EL EXPEDIENTE EXISTA ANTES DE INTENTAR IR POR SUS AREAS
        if (empty($expediente))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        $area = Areas::model()->findByPk($expediente->id_area);
        $empresa = Empresas::model()->findByPk($area->id_empresa);

        $permisos = array();

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $id)
                $permisos = $permiso;

        if (!boolval($permisos["create"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
        $dataAttributes = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/" . $expediente->id_expediente));

        $dataAttributes = CJSON::decode($dataAttributes)["data"];

        $atributos = $dataAttributes["expedientes"]["attributes"];

        $this->render('_frmRecord', array("expediente" => $expediente, "empresa" => $empresa, "area" => $area, "permisos" => $permisos, "atributos" => $atributos, "record" => null));
    }

    public function actionUpdateRecord($slug, $id)
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA Y LA EMPRESA
        $idExpediente = Expedientes::model()->getIdFromSlug($slug);
        $expediente = Expedientes::model()->findByPk($idExpediente);

        //SE VALIDA QUE EL EXPEDIENTE EXISTA ANTES DE INTENTAR IR POR SUS AREAS
        if (empty($expediente))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        $area = Areas::model()->findByPk($expediente->id_area);
        $empresa = Empresas::model()->findByPk($area->id_empresa);

        $permisos = array();

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $idExpediente)
                $permisos = $permiso;

        if (!boolval($permisos["update"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
        $dataAttributes = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/" . $expediente->id_expediente));

        $dataAttributes = CJSON::decode($dataAttributes)["data"];

        $atributos = $dataAttributes["expedientes"]["attributes"];

        //OBTENEMOS LOS VALORES DEL REGISTRO
        $filters = CJSON::encode(array(array("property" => "id", "value" => $id, "operator" => "=")));

        $dataRecords = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/records/" . $expediente->id_expediente, $filters));

        $dataRecords = CJSON::decode($dataRecords)["data"];

        $data = $dataRecords["records"][0];

        $this->render('_frmRecord', array("expediente" => $expediente, "empresa" => $empresa, "area" => $area, "permisos" => $permisos, "atributos" => $atributos, "record" => $data));
    }

    public function actionAddFile()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $permisos = array();

        //ID_EXPEDIENTE, ID REGISTRO, NOMBRE DE LA PROPIEDAD, ID ARCHIVOs
        $values = explode("-", $_POST['uuid']);
        $idExpediente = $this->decrypt($values[0]);
        $idRecord = $this->decrypt($values[1]);
        $attribute = $this->decrypt($values[2]);
        //ESTE PARAMETRO SOLO NECESITA PARA SOBRE-ESCRIBIR UN ARCHIVO
        $id = isset($values[3]) ? $this->decrypt($values[3]) : 9999;

        if (count($values) < 3 || intval($idExpediente) == 0 || intval($idRecord) == 0 || intval($id) == 0)
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'Favor de enviar todos los datos e intentarlo nuevamente',
                'totalCount'        => 0,
            ));

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $idExpediente)
                $permisos = $permiso;


        //OBTENEMOS EL AREA Y LA EMPRESA
        $expediente = Expedientes::model()->findByPk($idExpediente);
        if (empty($expediente->id_expediente))
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'Favor de enviar todos los datos e intentarlo nuevamente',
                'totalCount'        => 0,
            ));

        $data;
        if (Yii::app()->params['useFEA']) {
            $records = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/records/" . $idExpediente, CJSON::encode(array(array("property" => "id", "value" => $idRecord, "operator" => "=")))));

            $records = CJSON::decode($records)["data"]["records"][0];

            $data = array();
            foreach (Yii::app()->params['extraFields'] as $attributo)
                if (isset($records[$attributo["nombre"]]))
                    $data[$attributo["nombre"]] = $records[$attributo["nombre"]];

            $data[$attribute] = array(array("id" => isset($_POST['isUpdate']) ? $id : null, "file" => base64_encode(file_get_contents($_FILES['file']['tmp_name'])), "filename" => $_FILES['file']['name']));

            $data["certData"] = $_POST['certData'];
            $data = CJSON::encode($data);
        } else
            $data = CJSON::encode(array($attribute => array(array("id" => isset($_POST['isUpdate']) ? $id : null, "file" => base64_encode(file_get_contents($_FILES['file']['tmp_name'])), "filename" => $_FILES['file']['name']))));

        if (isset($idRecord) && !empty($idRecord) && (boolval($permisos["create"]) || (boolval($permisos["update"]) && isset($_POST['isUpdate']) && $id > 0)))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("expedientes/records/" . $idExpediente . "/" . $idRecord), $data);
        else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    public function actionDeleteFile()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $permisos = array();

        //ID_EXPEDIENTE, ID REGISTRO, NOMBRE DE LA PROPIEDAD, ID ARCHIVOs
        $values = explode("-", $_POST['uuid']);
        $idExpediente = $this->decrypt($values[0]);
        $idRecord = $this->decrypt($values[1]);
        $attribute = $this->decrypt($values[2]);
        $id = $this->decrypt($values[3]);

        if (count($values) != 4 || intval($idExpediente) == 0 || intval($idRecord) == 0 || intval($id) == 0)
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'Favor de enviar todos los datos e intentarlo nuevamente',
                'totalCount'        => 0,
            ));

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $idExpediente)
                $permisos = $permiso;

        if (boolval($permisos["delete"])) {
            $file = Multi::model()->findByPk($id);
            $firmaLog = array("uuid" => null, "stringOriginal" => null);

            if (Yii::app()->params['useFEA']) {
                $certData = CJSON::decode($_POST['certData']);
                //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
                $records = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/records/" . $idExpediente, CJSON::encode(array(array("property" => "id", "value" => $idRecord, "operator" => "=")))));

                $records = CJSON::decode($records)["data"]["records"];

                if (count($records) > 0)
                    $firmaLog = $this->signProccess($certData, $records[0], Users::model()->findByPk(Yii::app()->user->id), true);
            }

            $result = Multi::model()->deleteByPk($id);

            echo CJSON::encode(array(
                'success'           => $result > 0 ? true : false,
                'message'           => $result > 0 ? 'Documento <b>' . substr($file['path'], 14) . '</b> eliminado con éxito' : 'No se pudo eliminar el documento <b>' . substr($file['path'], 14) . '</b>',
                'totalCount'        => 0,
            ));

            $this->saveLog(Yii::app()->controller->action->id, array(new Multi), array($file), Yii::app()->controller->id, Yii::app()->user->id, $firmaLog['uuid'], $firmaLog['stringOriginal']);
        } else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    public function actionRecords($slug)
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA Y LA EMPRESA
        $id = Expedientes::model()->getIdFromSlug($slug);
        $expediente = Expedientes::model()->findByPk($id);

        //SE VALIDA QUE EL EXPEDIENTE EXISTA ANTES DE INTENTAR IR POR SUS AREAS
        if (empty($expediente))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        $area = Areas::model()->findByPk($expediente->id_area);
        $empresa = Empresas::model()->findByPk($area->id_empresa);

        $permisos = array();

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $id)
                $permisos = $permiso;

        if (!boolval($permisos["view"]))
            throw new CHttpException(403, 'No tiene los permisos necesarios para realizar esta acción');

        //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
        $dataAttributes = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/" . $expediente->id_expediente));

        $dataAttributes = CJSON::decode($dataAttributes)["data"];

        $atributos = $dataAttributes["expedientes"]["attributes"];

        $this->saveLog(Yii::app()->controller->action->id, array(new Expedientes), array($expediente), Yii::app()->controller->id, Yii::app()->user->id);

        $this->render('registros', array("expediente" => $expediente, "empresa" => $empresa, "area" => $area, "permisos" => $permisos, "atributos" => $atributos, "permisosReportes" => $session["permisos"]["expedientes"]));
    }

    //METODO PARA OBTENER REGISTROS DEL EXPEDIENTE
    public function actionSearch()
    {
        //PERMISOS
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA Y LA EMPRESA
        $id = Expedientes::model()->getIdFromSlug($_POST['slug']);
        $expediente = Expedientes::model()->findByPk($id);
        $area = Areas::model()->findByPk($expediente->id_area);
        $empresa = Empresas::model()->findByPk($area->id_empresa);

        $permisos = array();

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $id)
                $permisos = $permiso;

        //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
        $records = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/records/" . $expediente->id_expediente, $_POST['filters']));

        $records = CJSON::decode($records)["data"]["records"];
        $session["searchRecords"] = $records;

        $old_array = array(new Expedientes);
        $new_array = array($expediente);

        foreach (CJSON::decode($_POST['filters']) as $filter) {
            array_push($old_array, array("property" => null, "value" => null, "operator" => null));
            array_push($new_array, $filter);
        }

        $this->saveLog(Yii::app()->controller->action->id, $old_array, $new_array, Yii::app()->controller->id, Yii::app()->user->id);

        echo CJSON::encode(array("data" => $records));
    }

    public function actionSave()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $expedientes = Expedientes::model()->findAll();

        //SE QUITAN LOS INDICES DE LOS ATRIBUTOS Y SE DEJA CONFORME LO NECESITA EL API
        $_POST["attributes"] = isset($_POST["attributes"]) ? array_values($_POST["attributes"]) : array();

        //SE AGREGA EL ATRIBUTO REQUIRED EN CASO DE NO TENERLO
        foreach ($_POST["attributes"] as $index => $attribute) {
            $_POST["attributes"][$index]["required"] = isset($attribute["required"]) ? true : false;
        }

        //SE AGREGA LA PROPIEDAD PICTURE
        if (!empty($_FILES['image']['name'])) {
            $attributes = array("file" => base64_encode(file_get_contents($_FILES['image']['tmp_name'])), "filename" => $_FILES['image']['name']);
            $_POST["model"] = array_merge($_POST["model"], array("picture" => $attributes));
        }

        if (!empty($_POST["model"]["id_expediente"]) && boolval($session["permisos"]["expedientes"]["update"]))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("expedientes/" . $_POST["model"]["id_expediente"]), CJSON::encode($_POST));
        else if (empty($_POST["model"]["id_expediente"]) && (boolval($session["permisos"]["expedientes"]["create"]) && (count($expedientes) < Yii::app()->params['max_expedientes'] || Yii::app()->params['max_expedientes'] == 0)))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->post($this->getApiUrl("expedientes"), CJSON::encode($_POST));
        else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    //ACCION PARA GUARDAR UN NUEVO REGISTROS MODIFICAR
    public function actionSaveRecord($idExpediente, $idRecord = null)
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $permisos = array();

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $idExpediente)
                $permisos = $permiso;

        //ITERAMOS EL OBJETO ENVIADO EN BUSCA DE CAMPOS TIPO ARCHIVO
        foreach ($_FILES as $name => $archivo) {
            if (is_array($archivo['name'])) {
                for ($i = 0; $i < count($archivo['name']); $i++) {
                    if (!$archivo['error'][$i]) {
                        $_POST[$name][$i] = array("file" => base64_encode(file_get_contents($archivo['tmp_name'][$i])), "filename" => $archivo['name'][$i]);
                    }
                }
            } else {
                if (!$archivo['error'])
                    $_POST[$name] = array("file" => base64_encode(file_get_contents($archivo['tmp_name'])), "filename" => $archivo['name']);
            }
        }

        if (isset($idRecord) && !empty($idRecord) && boolval($permisos["update"]))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->put($this->getApiUrl("expedientes/records/" . $idExpediente . "/" . $idRecord), CJSON::encode($_POST));
        else if (empty($idRecord) && boolval($permisos["create"]))
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->post($this->getApiUrl("expedientes/records/" . $idExpediente), CJSON::encode($_POST));
        else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    public function actionRemove()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        if (!boolval($session["permisos"]["expedientes"]["delete"]))
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
        else
            echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->delete($this->getApiUrl("expedientes/" . $_POST['id']));
    }

    public function actionRemoveRecord()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $permisos = array();

        if (!isset($_POST['idExpediente']) || !isset($_POST["id"]))
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'Favor de enviar todos los datos e intentarlo nuevamente',
                'totalCount'        => 0,
            ));
        else {
            $idExpediente = $_POST['idExpediente'];
            $id = $_POST["id"];

            //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
            foreach ($session["permisos"]["registros"] as $permiso)
                if ($permiso["id_expediente"] == $idExpediente)
                    $permisos = $permiso;

            if (!boolval($permisos["delete"]))
                echo CJSON::encode(array(
                    'success'           => false,
                    'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                    'totalCount'        => 0,
                ));
            else {
                if (Yii::app()->params['useFEA']) {
                    $certData = CJSON::decode($_POST['certData']);
                    //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
                    $records = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/records/" . $idExpediente, CJSON::encode(array(array("property" => "id", "value" => $id, "operator" => "=")))));

                    $expediente = Expedientes::model()->findByPk($idExpediente);

                    $records = CJSON::decode($records)["data"]["records"];
                    if (count($records) > 0) {

                        $firmaLog = $this->signProccess($certData, $records[0], Users::model()->findByPk(Yii::app()->user->id), true);

                        echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->delete($this->getApiUrl("expedientes/records/" . $idExpediente . "/" . $id));

                        $this->saveLog("REST.DELETE.RECORDS", array(Repositorios::forTable($this->sanatizeTableName($expediente->id_area . "_" . $expediente->nombre))), array($records[0]), Yii::app()->controller->id, Yii::app()->user->id, $firmaLog['uuid'], $firmaLog['stringOriginal']);
                    }
                } else {
                    echo Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->delete($this->getApiUrl("expedientes/records/" . $idExpediente . "/" . $id));
                }
            }
        }
    }

    public function actionExcel($slug)
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA Y LA EMPRESA
        $id = Expedientes::model()->getIdFromSlug($slug);
        $expediente = Expedientes::model()->findByPk($id);

        //SE VALIDA QUE EL EXPEDIENTE EXISTA ANTES DE INTENTAR IR POR SUS AREAS
        if (empty($expediente))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        $area = Areas::model()->findByPk($expediente->id_area);
        $empresa = Empresas::model()->findByPk($area->id_empresa);

        //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
        $dataAttributes = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/" . $expediente->id_expediente));

        $dataAttributes = CJSON::decode($dataAttributes)["data"];

        $atributos = $dataAttributes["expedientes"]["attributes"];

        $user = Users::model()->findByPk(Yii::app()->user->id);

        $permisos = array();
        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $expediente->id_expediente)
                $permisos = $permiso;

        if (!boolval($session["permisos"]["expedientes"]["excel"]) || !boolval($permisos["view"]))
            throw new CHttpException(403, "No tiene los permisos necesarios para realizar esta acción");
        else {
            Yii::app()->request->sendFile(
                "Registros_" . date('dmYHis') . ".xls",
                $this->renderPartial('_excel', array('model' => $session["searchRecords"], 'atributos' => $atributos, 'expediente' => $expediente, 'area' => $area, 'empresa' => $empresa, 'nombreCompleto' => $user->apellido_p . " " . $user->apellido_m . " " . $user->nombre, 'email' => $user->email), true)
            );
        }
    }

    public function actionDownloadDemo($slug)
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA Y LA EMPRESA
        $id = Expedientes::model()->getIdFromSlug($slug);
        $expediente = Expedientes::model()->findByPk($id);

        //SE VALIDA QUE EL EXPEDIENTE EXISTA ANTES DE INTENTAR IR POR SUS AREAS
        if (empty($expediente))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
        $dataAttributes = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/" . $expediente->id_expediente));

        $dataAttributes = CJSON::decode($dataAttributes)["data"];

        $atributos = $dataAttributes["expedientes"]["attributes"];

        $permisos = array();
        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $expediente->id_expediente)
                $permisos = $permiso;

        if (!boolval($permisos["create"]))
            throw new CHttpException(403, "No tiene los permisos necesarios para realizar esta acción");
        else {

            $f = fopen('php://memory', 'r+');
            $delimiter = Yii::app()->params['delimiterCsv'];
            $enclosure = '"';
            $escape_char = "\\";

            $header = array_column($atributos, "nombre");

            fputcsv($f, $header, $delimiter, $enclosure, $escape_char);

            for ($i = 0; $i < rand(2, 10); $i++) {
                $item = array();
                foreach ($atributos as $atributo) {
                    if ($atributo['tipo'] === "ARCHIVO" || $atributo['tipo'] === "ARCHIVO_MULTIPLE") :
                        array_push($item, Yii::app()->params['randomDataGen']['files'][rand(0, count(Yii::app()->params['randomDataGen']['files']) - 1)]);
                    elseif ($atributo['tipo'] === "MAPA") :
                        array_push($item, Yii::app()->params['randomDataGen']['mapa'][rand(0, count(Yii::app()->params['randomDataGen']['mapa']) - 1)]);
                    elseif ($atributo['tipo'] === "NUMERICO") :
                        array_push($item, rand(1000, 9999));
                    elseif ($atributo['tipo'] === "LISTA") :
                        array_push($item, $atributo['lista'][rand(0, count($atributo['lista']) - 1)]);
                    elseif ($atributo['tipo'] === "FECHA") :
                        array_push($item, date("Y-m-d", mt_rand(1, time())));
                    elseif ($atributo['tipo'] === "TEXTO") :
                        array_push($item, Yii::app()->params['randomDataGen']['texto'][rand(0, count(Yii::app()->params['randomDataGen']['texto']) - 1)]);
                    elseif ($atributo['tipo'] === "TEXTO_LARGO") :
                        array_push($item, Yii::app()->params['randomDataGen']['texto_largo'][rand(0, count(Yii::app()->params['randomDataGen']['texto_largo']) - 1)]);
                    endif;
                }
                fputcsv($f, $item, $delimiter, $enclosure, $escape_char);
            }

            $this->saveLog(Yii::app()->controller->action->id, array(new Expedientes), array($expediente), Yii::app()->controller->id, Yii::app()->user->id);

            rewind($f);
            Yii::app()->request->sendFile(
                "Demo_CSV_" . date('dmYHis') . ".csv",
                stream_get_contents($f),
                true
            );
        }
    }

    public function actionPdf($slug)
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        //OBTENEMOS EL AREA Y LA EMPRESA
        $id = Expedientes::model()->getIdFromSlug($slug);
        $expediente = Expedientes::model()->findByPk($id);

        //SE VALIDA QUE EL EXPEDIENTE EXISTA ANTES DE INTENTAR IR POR SUS AREAS
        if (empty($expediente))
            throw new CHttpException(404, "No se encontró la vista solicitada");

        $area = Areas::model()->findByPk($expediente->id_area);
        $empresa = Empresas::model()->findByPk($area->id_empresa);

        //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
        $dataAttributes = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/" . $expediente->id_expediente));

        $dataAttributes = CJSON::decode($dataAttributes)["data"];

        $atributos = $dataAttributes["expedientes"]["attributes"];

        $user = Users::model()->findByPk(Yii::app()->user->id);

        $permisos = array();
        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $expediente->id_expediente)
                $permisos = $permiso;

        if (!boolval($session["permisos"]["expedientes"]["pdf"]) || !boolval($permisos["view"]))
            throw new CHttpException(403, "No tiene los permisos necesarios para realizar esta acción");
        else {
            Yii::import('application.extensions.bootstrap.gii.*');
            require_once('bootstrap/tcpdf/tcpdf.php');
            require_once('bootstrap/tcpdf/config/lang/eng.php');
            $html = $this->renderPartial('_excel', array('model' => $session["searchRecords"], 'atributos' => $atributos, 'expediente' => $expediente, 'area' => $area, 'empresa' => $empresa, 'nombreCompleto' => $user->apellido_p . " " . $user->apellido_m . " " . $user->nombre, 'email' => $user->email), true);
            $pdf = new TCPDF('L');
            $pdf->SetCreator(PDF_CREATOR);
            $pdf->SetAuthor(Yii::app()->name);
            $pdf->SetTitle('Reporte Expediente');
            $pdf->SetSubject('Reporte Expediente');
            $pdf->setPrintHeader(false);
            $pdf->setFooterFont(array('helvetica', '', 6));
            $pdf->SetMargins(5, 18, 15);
            $pdf->SetFooterMargin(10);
            $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
            $pdf->SetFont('dejavusans', '', 7);
            $pdf->AddPage();
            $pdf->writeHTML($html, true, false, true, false, '');
            $pdf->LastPage();
            $pdf->Output("Registros_" . date('dmYHis') . ".pdf", "I");
        }
    }

    public function actionUploadMassive()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $permisos = array();
        $records = array();
        $result = array();
        $idExpediente = $_POST['idExpediente'];

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $idExpediente)
                $permisos = $permiso;

        if (boolval($permisos["create"]) && !Yii::app()->params['useFEA']) {
            $file = $_FILES['file']['tmp_name'];
            if (in_array($_FILES['file']['type'], Yii::app()->params['csvExtensions'])) {
                //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
                $dataAttributes = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/" . $idExpediente));

                $dataAttributes = CJSON::decode($dataAttributes)["data"];

                $atributos = $dataAttributes["expedientes"]["attributes"];

                $records = $this->readCSV($file, $atributos);
                //AQUI INSERTAR DATOS
                foreach ($records as $record) {
                    set_time_limit(0);
                    array_push($result, CJSON::decode(Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->post($this->getApiUrl("expedientes/records/" . $idExpediente), CJSON::encode($record))));
                }

                echo CJSON::encode(array(
                    'success'           => true,
                    'message'           => 'Se encontraron <b>' . count($result) . ' registros</b>',
                    'totalCount'        => count($result),
                    'data' => $result,
                ));
            } else {
                if ($this->saveTmpFileToServer($file, "00000000000000" . $_FILES['file']['name']) === false)
                    echo CJSON::encode(array(
                        'success'           => false,
                        'message'           => "Error al subir el archivo <b>" . $_FILES['file']['name'] . "</b>",
                        'totalCount'        => 0,
                    ));
                else
                    echo CJSON::encode(array(
                        'success'           => true,
                        'message'           => "Archivo <b>" . $_FILES['file']['name'] . "</b> guardado con éxito",
                        'totalCount'        => 1,
                    ));
            }
        } else
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => Yii::app()->params['useFEA'] ? 'El módulo de carga másiva no es compatible con el módulo de Firma Electrónica Avanzada' : 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
    }

    public function actionCreateZip()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $permisos = array();

        //OBTENEMOS EL AREA Y LA EMPRESA
        $id = Expedientes::model()->getIdFromSlug($_POST['slug']);
        $expediente = Expedientes::model()->findByPk($id);

        //SE VALIDA QUE EL EXPEDIENTE EXISTA ANTES DE INTENTAR IR POR SUS AREAS
        if (empty($expediente)) {
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No se encontró la vista solicitada',
                'totalCount'        => 0,
            ));
            return;
        }

        //ITERAMOS LOS PERMISOS HASTA ENCONTRAR EL PERMISO DEL EXPEDIENTE ACTUAL
        foreach ($session["permisos"]["registros"] as $permiso)
            if ($permiso["id_expediente"] == $expediente->id_expediente)
                $permisos = $permiso;

        if (!boolval($permisos["view"]) || !boolval($permisos["download"])) {
            echo CJSON::encode(array(
                'success'           => false,
                'message'           => 'No tiene los permisos necesarios para realizar esta acción',
                'totalCount'        => 0,
            ));
            return;
        }

        //OBTENEMOS LOS ATRIBUTOS DEL EXPEDIENTE
        $dataAttributes = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes/" . $expediente->id_expediente));

        $dataAttributes = CJSON::decode($dataAttributes)["data"];

        $atributos = $dataAttributes["expedientes"]["attributes"];

        $filesAttributes = array();
        $filesArray = array();
        $old_array = array(new Expedientes);
        $new_array = array($expediente);


        ignore_user_abort(true);
        set_time_limit(0);

        foreach ($atributos as $atributo)
            if (in_array($atributo['nombre'], $_POST['atributos'])) {
                array_push($filesAttributes, array("nombre" => $atributo["nombre"], "tipo" => $atributo["tipo"]));
                array_push($old_array, array("indice" => null));
                array_push($new_array, array("indice" => !empty($atributo["label"]) ? $atributo["label"] : $atributo["nombre"]));
            }

        foreach ($session["searchRecords"] as $record) {
            foreach ($filesAttributes as $att) {
                if ($att["tipo"] === "ARCHIVO" && !empty($record[$att["nombre"]]['filename']))
                    array_push($filesArray, Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . basename($record[$att["nombre"]]['path']));
                else {
                    foreach ($record[$att["nombre"]] as $file) {
                        if (!empty($file['filename']))
                            array_push($filesArray, Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . basename($file['path']));
                    }
                }
            }
        }

        $this->saveLog(Yii::app()->controller->action->id, $old_array, $new_array, Yii::app()->controller->id, Yii::app()->user->id);

        $zip = Yii::app()->zip;
        $zipName = Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . date("YmdHis") . ".zip";
        if ($zip->makeZip($filesArray, $zipName, false))
            echo CJSON::encode(array('success' => true, 'message' => "Descargando el ZIP <b>" . basename($zipName) . "</b>", 'data' => Yii::app()->params['HTTP_SERVER_PATH'] . DIRECTORY_SEPARATOR . basename($zipName)));
        else
            echo CJSON::encode(array('success' => false, 'message' => "No se pudo crear el archivo ZIP", 'data' => null));
    }

    public function actionDeleteZip()
    {
        $this->getUserAccess();
        $session = new CHttpSession;
        $session->open();

        $permisos = array();

        unlink(Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . basename($_POST['path']));
    }

    private function readCSV($csv, $attributes)
    {
        $result = array();

        if (($gestor = fopen($csv, "r")) !== FALSE) {

            $isHeader = Yii::app()->params['usingHeaderCSV'];
            $delimiter = Yii::app()->params['delimiterCsv'];
            $header = array();

            while (($datos = fgetcsv($gestor, 1000, $delimiter)) !== FALSE) {
                if ($isHeader) {
                    $isHeader = false;
                    foreach ($datos as $head)
                        array_push($header, $head);
                    continue;
                }
                $record = array();
                foreach ($datos as $index => $col) {
                    set_time_limit(0);
                    foreach ($attributes as $atributo) {
                        if (strtolower($header[$index]) === strtolower($atributo["label"]) || strtolower($header[$index]) === strtolower($atributo["nombre"])) {
                            if ($atributo["tipo"] === "ARCHIVO" && !empty($col))
                                $record[$header[$index]] = array("filename" => $col, "file" => null, "skipFileValidation" => true);
                            elseif ($atributo["tipo"] === "ARCHIVO_MULTIPLE" && !empty($col))
                                $record[$header[$index]] = array(array("filename" => $col, "file" => null, "skipFileValidation" => true));
                            elseif ($atributo["tipo"] === "MAPA" && !empty($col)) {
                                $latlng = explode(",", $col);
                                if (count($latlng) == 2)
                                    $record[$header[$index]] = array("lat" => $latlng[0], "lng" => $latlng[1]);
                            } elseif ($atributo["tipo"] === "FECHA" && !empty($col))
                                $record[$header[$index]] = implode("-", array_reverse(explode("/", $col)));
                            elseif (!empty($col))
                                $record[$header[$index]] = mb_convert_encoding($col, "UTF-8", 'Windows-1252');
                        } elseif (strtolower($header[$index]) === strtolower('Document Filename')) {
                            $record['archivo_path'] = array("filename" => $col, "file" => null, "skipFileValidation" => true);
                        }
                    }
                }
                array_push($result, $record);
            }
        }

        return $result;
    }

    public function restEvents()
    {

        $this->onRest('pre.filter.req.get.resources.render', function ($data, $model_name, $relations, $count, $visibleProperties, $hiddenProperties) {

            $result = [];
            $access = $this->getAccess();

            if ($access['isAdmin'])
                $result = $data;
            else {
                foreach ($data as $registro)
                    if (in_array($registro['id_expediente'], $access['expedientes']))
                        array_push($result, $registro);
            }

            return [$result, $model_name, $relations, count($result), $visibleProperties, $hiddenProperties];
        });

        //EVITAMOS LOS LLAMADOS AJAX PUT SOBRE LOS EXPEDIENTES
        $this->onRest('post.filter.req.auth.ajax.user', function ($validation) {
            switch ($this->getAction()->getId()) {
                default:
                    return $validation;
                    break;
            }
        });

        //EVITAMOS LOS LLAMADOS PUT SOBRE LOS EXPEDIENTES
        $this->onRest('post.filter.req.auth.user', function ($validation) {
            switch ($this->getAction()->getId()) {
                default:
                    return $validation;
                    break;
            }
        });

        //ANTES DE LLAMAR EL EVENTO POST SEPARAMOS LOS DATOS EN MODELO Y COLUMNAS
        $this->onRest('pre.filter.model.apply.post.data', function ($model, $data, $restricted_properties) {

            if (isset($data["model"]["picture"]) && !empty($data["model"]["picture"])) {
                $name_aux = "";
                if (empty($data["model"]["picture"]["filename"]))
                    throw new CHttpException('011', "El atributo 'filename' no puede estar vacio.");
                else
                    $data["model"]["image"] = date("dmYHis") . $data["model"]["picture"]["filename"];

                if ($this->convertBase64ToFile($data["model"]["picture"]["file"], $data["model"]["image"], "thumbs") === false)
                    throw new CHttpException('010', "Error al subir el archivo.");

                unset($data["model"]["picture"]);
            }

            //VALIDAMOS QUE ESTEN PASANDO TODOS LOS ATRIBUTOS CORRECTOS
            if (!isset($data["model"]))
                throw new CHttpException('000', 'El parámetro model no se encuentra definido');
            if (!isset($data["model"]["id_area"]))
                throw new CHttpException('001', 'El parámetro model.id_area no se encuentra definido');
            if (!isset($data["model"]["nombre"]))
                throw new CHttpException('002', 'El parámetro model.nombre no se encuentra definido');

            if (!isset($data["attributes"]))
                throw new CHttpException('003', 'El parámetro attributes no se encuentra definido');

            $data['model']['nombre'] = $this->sanatizeColumnName($data['model']['nombre']);

            foreach ($data["attributes"] as $attribute) {
                if (isset($attribute["tipo"]) && strtoupper($attribute["tipo"]) === "LISTA")
                    if (!isset($attribute["id_lista"]))
                        throw new CHttpException('004', 'El atributo ' . $attribute["nombre"] . ' de tipo lista no tiene definido la propiedad id_lista');
            }

            //VALIDAMOS QUE NO EXISTA LA TABLA QUE DESEAN CREAR
            $table = Yii::app()->db->schema->getTable($this->sanatizeTableName($data["model"]["id_area"] . "_" . $data["model"]["nombre"]));
            if ($table !== null)
                throw new CHttpException('006', "Ya existe un expediente '" . $data["model"]["nombre"] . "' con el mismo nombre en esta area");
            return [$model, $data['model'], $restricted_properties, $data['attributes']];
        });

        //RECIBIMOS UN PARAMETRO NUEVO LLAMADO $attributes CON LOS ATRIBUTOS Y SU DEFINICION
        $this->onRest('model.apply.post.data', function ($model, $data, $restricted_properties, $attributes = null) {
            $result = array("model" => $this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties), "attributes" => $attributes);
            //LOG PARA CREATE
            if ($result["model"]->validate()) {
                $array_old = array();
                $array_new = array();

                foreach ($attributes as $attributo) {
                    array_push($array_old, array("nombre" => null, "tipo" => null, "required" => null, "id_lista" => null));
                    array_push($array_new, $attributo);
                }

                array_push($array_old, new $model);
                array_push($array_new, $data);


                $this->saveLog(Yii::app()->controller->action->id, $array_old, $array_new, Yii::app()->controller->id, $this->getUser()->id_usuario);
            }
            return $result;
        });

        //IMPLEMENTAR UPDATE
        /*$this->onRest('model.apply.put.data', function($model, $data, $restricted_properties,$attributes=null) {
            $result = array("model"=>$this->getResourceHelper()->setModelAttributes($model, $data, $restricted_properties),"attributes"=>$attributes);
            //LOG PARA UPDATE
            if($result["model"]->validate()){
                $old = $model::model()->findByPk($model->id_expediente);
                $this->saveLog(Yii::app()->controller->action->id,array($old),array($data),Yii::app()->controller->id,$this->getUser()->id_usuario);
            }
            return $result;
        });*/

        $this->onRest('post.filter.model.delete', function ($result) {
            //LOG PARA DELETE
            $this->saveLog(Yii::app()->controller->action->id, array(new Expedientes), array($result), Yii::app()->controller->id, $this->getUser()->id_usuario);
            return $result;
        });

        $this->onRest('post.filter.model.apply.post.data', function ($result) {
            return ["model" => $result["model"], "attributes" => $result["attributes"]]; //
        });

        $this->onRest('model.save', function ($model) {
            if (!$model['model']->save()) {
                throw new CHttpException('400', CJSON::encode($model->errors));
            }
            $model['model']->refresh();
            return ["model" => $model['model'], "attributes" => $model['attributes']];
        });


        $this->onRest('post.filter.model.save', function ($result) {
            try {
                if ($this->getAction()->getId() === "REST.POST") {
                    $tableName = $result["model"]["id_area"] . "_" . $result["model"]["nombre"];
                    //SE LE PASA EL ID DEL EXPEDIENTE
                    $columns = $this->convertArrayColumns($result["attributes"], $result["model"]["id_expediente"]);
                    //MANDAMOS A CREAR LA TABLA DESPUES DE SALVAR EL EXPEDIENTE
                    Yii::import('application.controllers.AlterTable');
                    $alterTable = new AlterTable();
                    $alterTable->createTable($this->sanatizeTableName($tableName), $columns);
                }
            } catch (Exception $ex) {
                Expedientes::model()->findByPk($result["model"]["id_expediente"])->delete();
                return $ex;
            }

            return $result["model"];
        });

        //ANTES DE BORRAR UN EXPEDIENTE
        $this->onRest('pre.filter.model.delete', function ($model) {
            $transaction = Yii::app()->db->beginTransaction();
            try {

                //BORRAMOS LOS PERMISOS
                $permisos = Permisos::model()->deleteAll('id_expediente=' . $model['attributes']['id_expediente']);
                //BORRAMOS LISTA_EXP
                $listaExp = ListaExp::model()->deleteAll('id_expediente=' . $model['attributes']['id_expediente']);
                //BORRAMOS ARCHIVOS DE TABLA MULTI
                $multi = Multi::model()->deleteAll('id_expediente=' . $model['attributes']['id_expediente']);
                //HACEMOS DROP TABLE
                Yii::import('application.controllers.AlterTable');
                $alterTable = new AlterTable();
                $tableName = $model['attributes']['id_area'] . "_" . $model['attributes']['nombre'];
                $alterTable->dropTable($this->sanatizeTableName($tableName));

                $transaction->commit();
            } catch (Exception $e) {
                $transaction->rollBack();
            }

            return $model;
        });

        //EVENTO PARA AGREGAR UNA NUEVA COLUMNA A UN EXPEDIENTE YA CREADO
        $this->onRest('req.post.attribute.render', function ($data, $id) {
            $expediente = Expedientes::model()->findByPk($id);
            if (empty($expediente->id_expediente))
                throw new CHttpException(404, "Resource '$id' Not Found");

            Yii::import('application.controllers.AlterTable');
            $alterTable = new AlterTable();
            $tableName = $expediente->id_area . "_" . $expediente->nombre;
            $columnName = $this->renameColumnByType($expediente->id_expediente, $data['nombre'], isset($data['tipo']) ? $data['tipo'] : 'TEXTO', isset($data['required']) ? $data['required'] : true, isset($data['id_lista']) ? $data['id_lista'] : null);


            //CONSEGUIMOS EL SCHEMA DEL EXPEDIENTE
            Yii::app()->db->schema->refresh();
            $schema = Repositorios::forTable($this->sanatizeTableName($tableName))->getTableSchema()->getColumnNames();
            $columnExist = false;

            //RECORREMOS TODAS LAS COLUMNAS EN BUSCA DE UNA COLUMNA CON EL MISMO NOMBRE
            foreach ($schema as $name)
                if ($name === $columnName)
                    $columnExist = true;

            //SI LA COLUMNA QUE QUEREMOS AGREGAR YA EXISTE ENTONCES MARCARMOS ERROR
            //EN CASO CONTRARIO SE MANDA A CREAR
            if ($columnExist)
                throw new CHttpException('007', "Ya existe un atributo '" . $columnName . "' en este expediente con el mismo nombre");
            else
                $alterTable->addColumn($this->sanatizeTableName($tableName), $columnName, "VARCHAR(" . Yii::app()->params['MAX_CHAR'] . ")");

            //CARGAMOS Y LIMPIAMOS EL SCHEMA EN CACHE DE TODAS LAS TABLAS
            Yii::app()->db->schema->refresh();
            $schema = Repositorios::forTable($this->sanatizeTableName($tableName))->getTableSchema()->getColumnNames();

            $columns = array();
            //RECORREMOS TODAS LAS COLUMNAS PARA MOSTRARLAS EN EL RESULTADO
            foreach ($schema as $name)
                if ($name !== "id")
                    array_push($columns, $this->getColumnsInfo($name));


            $result["totalCount"] = 1;
            $result["expedientes"] = $expediente;
            $result["attributes"] = $columns;

            $area = Areas::model()->findByPk($expediente->id_area);
            //$this->createCustomLog("POST.ATTRIBUTE",$area->id_empresa,$expediente->id_area,$expediente->id_expediente,$data);

            echo CJSON::encode(['success' => true, 'message' => "Attribute '" . $data['nombre'] . "' added", 'data' => $result]);
        });


        //EVENTO PARA MOSTRAR LOS REGISTROS DE UN EXPEDIENTE
        $this->onRest('req.get.records.render', function ($id) {
            $model = Expedientes::model()->findByPk($id);

            $access = $this->getAccess();

            if (empty($model->id_expediente))
                throw new CHttpException(404, "Resource '$id' Not Found");

            if (!$access['isAdmin'] && !in_array($id, $access['expedientes']))
                throw new CHttpException(403, "No tiene los permisos necesarios para realizar esta acción");

            //EN CUALQUIER OTRO CASO OBTENEMOS TODOS LOS ATRIBUTOS DE LA TABLA CREADA POR EL EXPEDIENTE Y LO DEVOLVEMOS
            $tableName = $model->id_area . "_" . $model->nombre;
            $condition = "";
            $showAttributes = array();

            Yii::app()->db->schema->refresh();
            $schema = Repositorios::forTable($this->sanatizeTableName($tableName))->getTableSchema()->getColumnNames();

            if (isset($_GET["select"]) && !empty($_GET["select"])) {
                $existID = false;
                foreach (CJSON::decode($_GET["select"]) as $select) {
                    if ($select === "id")
                        $existID = true;

                    $exist = false;
                    foreach ($schema as $attribute) {
                        if ($select === $attribute)
                            $exist = true;
                    }

                    if ($exist)
                        array_push($showAttributes, $select);
                }

                if (!$existID)
                    array_push($showAttributes, "id");
            }


            $criteria = new CDbCriteria;
            $criteria->select = count($showAttributes) > 0 ? implode(",", $showAttributes) : "*";

            if (isset($_GET["limit"]))
                $criteria->limit = $_GET["limit"];
            if (isset($_GET["offset"]))
                $criteria->offset = $_GET["offset"];


            //VAMOS EN BUSCA DE LOS REGISTROS
            if (isset($_GET["filter"])) {
                //CREAMOS EL QUERY
                $index = 0;
                //ITERAMOS CADA FILTRO ENVIADO
                foreach (CJSON::decode($_GET["filter"]) as $filter) {
                    if ($index > 0)
                        $condition .= " AND ";

                    $property = $filter["property"];
                    $operator = isset($filter["operator"]) ? $filter["operator"] : "LIKE";
                    $value = $filter["value"];

                    //SI ES UN LIKE APLICAMOS COMODINES %, EN CASO CONTRARIO HACEMOS UNA BUSQUEDA NORMAL
                    if ($operator === "LIKE")
                        $condition .= $property . " " . $operator . " '%" . $value . "%'";
                    else
                        $condition .= $property . $operator . "'" . $value . "'";

                    $index++;
                }

                $criteria->condition = $condition;
            }

            $expedientes = Repositorios::forTable($this->sanatizeTableName($tableName))->findAll($criteria);

            //ITREAMOS CADA UNO DE LOS REGISTROS
            foreach ($expedientes as $expediente) {
                //ITERAMOS CADA ATTRIBUTO DEL REGISTRO 
                foreach ($expediente->attributes as $attribute => $value) {
                    if (isset($_GET["select"]) && !empty($_GET["select"])) {

                        foreach (CJSON::decode($_GET["select"]) as $show) {
                            if ($show === $attribute) {
                                ini_set('MAX_EXECUTION_TIME', '300');
                                //EN CASO QUE SEA DE TIPO MULTIPLE
                                if (strpos($attribute, '_multi') !== false)
                                    $expediente[$attribute] = $expediente->getMultiFiles($model->id_expediente, $attribute);

                                //EN CASO QUE SEA DE TIPO ARCHIVO
                                if (strpos($attribute, '_path') !== false)
                                    $expediente[$attribute] = $expediente->getSingleFile($model->id_expediente, $attribute);
                            }
                        }
                    } else {
                        ini_set('MAX_EXECUTION_TIME', '300');
                        //EN CASO QUE SEA DE TIPO MULTIPLE
                        if (strpos($attribute, '_multi') !== false)
                            $expediente[$attribute] = $expediente->getMultiFiles($model->id_expediente, $attribute);

                        //EN CASO QUE SEA DE TIPO ARCHIVO
                        if (strpos($attribute, '_path') !== false)
                            $expediente[$attribute] = $expediente->getSingleFile($model->id_expediente, $attribute);
                    }
                }
            }

            //AGREGAMOS UN NUEVO ATRIBUTO DONDE SE ENCONTRARAN TODOS LOS REGISTROS DEL EXPEDIENTE
            $result["totalCount"] = count($expedientes);
            $result["records"] = $expedientes;
            echo CJSON::encode(['success' => count($expedientes) > 0 ? true : false, 'message' => count($expedientes) > 0 ? "Record(s) Found" : "No Record(s) Found", 'data' => $result]);
        });

        //EVENTO PARA AGREGAR REGISTROS AL EXPEDIENTE
        $this->onRest('req.post.records.render', function ($data, $id) {
            $transaction = Yii::app()->db->beginTransaction();
            $array_multi = array();
            try {
                $model = Expedientes::model()->findByPk($id);

                $access = $this->getAccess("a");

                if (empty($model->id_expediente))
                    throw new CHttpException(404, Yii::app()->params['tercero'] . " '$id' no encontrado");

                if (!$access['isAdmin'] && !in_array($model->id_expediente, $access['expedientes']))
                    throw new CHttpException(403, "No tiene los permisos necesarios para realizar esta acción");

                //EN CUALQUIER OTRO CASO OBTENEMOS TODOS LOS ATRIBUTOS DE LA TABLA CREADA POR EL EXPEDIENTE Y LO DEVOLVEMOS
                $tableName = $model->id_area . "_" . $model->nombre;
                $expedientes = Repositorios::forTable($this->sanatizeTableName($tableName));

                //SI ESTA ACTIVADO EL MODULO DE FIRMA ELECTRONICA
                //ENTONCES QUITAMOS certDATA PARA PODER GUARDAR EL REGISTRO
                //Y MANDAMOS A LLAMAR TODOS LOS PROCESOS DE FIRMADO
                $firmaLog = array("uuid" => null, "stringOriginal" => null);

                if (Yii::app()->params['useFEA']) {
                    $certData = CJSON::decode($data['certData']);
                    unset($data['certData']);
                    $firmaLog = $this->signProccess($certData, $data, $this->getUser(), false);
                }

                $response = $this->setValuesToExpediente($data, $expedientes, $id);
                $expedientes = $response['expedientes'];
                $array_multi = $response['array_multi'];
                $newFiles = array();
                if ($expedientes->save()) {

                    $old_array = array(Repositorios::forTable($this->sanatizeTableName($tableName)));
                    $new_array = array($expedientes);

                    foreach ($array_multi as $multi) {
                        $multi->id_registro = $expedientes->id;
                        $multi->save();
                        array_push($old_array, new Multi);
                        array_push($new_array, $multi);
                        array_push($newFiles, $multi->id);
                    }
                    $transaction->commit();

                    $result = $this->fileAttributeInfo($expedientes, $id, $newFiles);
                    $area = Areas::model()->findByPk($model->id_area);

                    $this->saveLog("REST.POST.RECORDS", $old_array, $new_array, Yii::app()->controller->id, $this->getUser()->id_usuario, $firmaLog['uuid'], $firmaLog['stringOriginal']);

                    echo CJSON::encode(['success' => true, 'message' => "Registro creado", 'data' => $result]);
                } else
                    throw new CHttpException(500, "Error al salvar el " . Yii::app()->params['cuarto']);
            } catch (Exception $e) {

                $transaction->rollBack();
                throw new CHttpException(isset($e->statusCode) ? $e->statusCode : 500, $e->getMessage());
            }
        });

        //EVENTO PARA EDITAR UN REGISTRO DEL EXPEDIENTE
        $this->onRest('req.put.records.render', function ($data, $idExpediente, $idRecord) {
            if (!isset($idExpediente))
                throw new CHttpException("017", "El parámetro id_expediente no se encuentra definido");
            if (!isset($idRecord))
                throw new CHttpException("018", "El parámetro id_registro no se encuentra definido");

            $transaction = Yii::app()->db->beginTransaction();
            $array_multi = array();
            try {
                $model = Expedientes::model()->findByPk($idExpediente);

                if (empty($model->id_expediente))
                    throw new CHttpException(404, Yii::app()->params['tercero'] . " '$idExpediente' no encontrado");

                //EN CUALQUIER OTRO CASO OBTENEMOS TODOS LOS ATRIBUTOS DE LA TABLA CREADA POR EL EXPEDIENTE Y LO DEVOLVEMOS
                $tableName = $model->id_area . "_" . $model->nombre;
                $expediente = Repositorios::forTable($this->sanatizeTableName($tableName))->findByPk($idRecord);
                $original = Repositorios::forTable($this->sanatizeTableName($tableName))->findByPk($idRecord);
                if (empty($expediente->id))
                    throw new CHttpException(404, "Record '$idRecord' Not Found");

                //SI ESTA ACTIVADO EL MODULO DE FIRMA ELECTRONICA
                //ENTONCES QUITAMOS certDATA PARA PODER GUARDAR EL REGISTRO
                //Y MANDAMOS A LLAMAR TODOS LOS PROCESOS DE FIRMADO
                $firmaLog = array("uuid" => null, "stringOriginal" => null);

                if (Yii::app()->params['useFEA']) {
                    $certData = CJSON::decode($data['certData']);
                    unset($data['certData']);
                    $firmaLog = $this->signProccess($certData, $data, $this->getUser(), false);
                }


                $response = $this->setValuesToExpediente($data, $expediente, $idExpediente);


                $expediente = $response['expedientes'];
                $array_multi = $response['array_multi'];
                $newFiles = array();

                if ($expediente->save()) {
                    $old_array = array($original);
                    $new_array = array($expediente);

                    foreach ($array_multi as $multi) {
                        $multi->id_registro = $expediente->id;
                        $multi->save();
                        array_push($old_array, new Multi);
                        array_push($new_array, $multi);
                        array_push($newFiles, $multi->id);
                    }

                    $result = $this->fileAttributeInfo($expediente, $idExpediente, $newFiles);

                    $area = Areas::model()->findByPk($model->id_area);

                    $transaction->commit();
                    $this->saveLog("REST.PUT.RECORDS", $old_array, $new_array, Yii::app()->controller->id, $this->getUser()->id_usuario, $firmaLog['uuid'], $firmaLog['stringOriginal']);

                    echo CJSON::encode(['success' => true, 'message' => Yii::app()->params['cuarto'] . " actualizado", 'data' => $result]);
                } else
                    throw new CHttpException(500, "Error al salvar el " . strtolower(Yii::app()->params['cuarto']));
            } catch (Exception $e) {

                $transaction->rollBack();
                throw new CHttpException($e->statusCode, $e->getMessage());
            }
        });

        //EVENTO PARA ELIMINAR UN REGISTRO DEL EXPEDIENTE
        $this->onRest('req.delete.records.render', function ($idExpediente, $idRecord) {
            $transaction = Yii::app()->db->beginTransaction();

            try {

                if (!isset($idExpediente))
                    throw new CHttpException("017", "El parámetro id_expediente no se encuentra definido");
                if (!isset($idRecord))
                    throw new CHttpException("018", "El parámetro id_registro no se encuentra definido");

                $model = Expedientes::model()->findByPk($idExpediente);

                if (empty($model->id_expediente))
                    throw new CHttpException(404, Yii::app()->params['tercero'] . " '$idExpediente' no encontrado");

                //EN CUALQUIER OTRO CASO OBTENEMOS TODOS LOS ATRIBUTOS DE LA TABLA CREADA POR EL EXPEDIENTE Y LO DEVOLVEMOS
                $tableName = $model->id_area . "_" . $model->nombre;
                $expediente = Repositorios::forTable($this->sanatizeTableName($tableName))->findByPk($idRecord);
                if (empty($expediente->id))
                    throw new CHttpException(404, Yii::app()->params['cuarto'] . " '$idRecord' no encontrado");

                $result = $this->fileAttributeInfo($expediente, $idExpediente);

                if ($expediente->delete()) {
                    $old_array = array(Repositorios::forTable($this->sanatizeTableName($tableName)));
                    $new_array = array($result);

                    $multis = Multi::model()->findAll('id_expediente=' . $idExpediente . ' and id_registro=' . $idRecord);
                    foreach ($multis as $multi) {
                        array_push($old_array, new Multi);
                        array_push($new_array, $multi);
                    }
                    //BORRAMOS ARCHIVOS DE TABLA MULTI
                    Multi::model()->deleteAll('id_expediente=' . $idExpediente . ' and id_registro=' . $idRecord);
                    $area = Areas::model()->findByPk($model->id_area);


                    $this->saveLog("REST.DELETE.RECORDS", $old_array, $new_array, Yii::app()->controller->id, $this->getUser()->id_usuario);

                    echo CJSON::encode(['success' => true, 'message' => Yii::app()->params['cuarto'] . " eliminado", 'data' => $result]);
                } else
                    throw new CHttpException(500, "Error al borrar el " . strtolower(Yii::app()->params['cuarto']));

                $transaction->commit();
            } catch (Exception $e) {
                $transaction->rollBack();
                throw new CHttpException($e->statusCode, $e->getMessage());
            }
        });

        //HACEMOS OVERRIDE AL EVENTO ENCARGADO DE RECUPERAR LOS VALORES
        $this->onRest('model.expedientes.override.attributes', function ($model) {
            try {

                //OBTENEMOS EL TIPO DE LLAMADO
                switch ($this->getAction()->getId()) {
                    case 'REST.DELETE':
                        //EN CASO DE SER UN DELETE, DEVOLVEMOS UNICAMENTE LOS ATRIBUTOS DEL EXPEDIENTE
                        return array_merge($model->attributes);
                        break;
                    default:
                        //EN CUALQUIER OTRO CASO OBTENEMOS TODOS LOS ATRIBUTOS DE LA TABLA CREADA POR EL EXPEDIENTE Y LO DEVOLVEMOS
                        $tableName = $model->id_area . "_" . $model->nombre;
                        //CONSEGUIMOS EL SCHEMA DEL EXPEDIENTE
                        Yii::app()->db->schema->refresh();
                        $schema = Repositorios::forTable($this->sanatizeTableName($tableName))->getTableSchema();
                        $columns = array();
                        foreach ($schema->columns as $column)
                            if ($column->name !== "id")
                                array_push($columns, $this->getColumnsInfo($column->name, $column->comment, $model->id_expediente));
                        return array_merge($model->attributes, ['attributes' => $columns]);
                        break;
                }
            } catch (Exception $e) {
                return array_merge($model->attributes);
            }
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN CREATE
        $this->onRest('req.post.resource.render', function ($model, $relations, $visibleProperties = [], $hiddenProperties = []) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("%s '<b>%s</b>' creado", Yii::app()->params["tercero"], $model->nombre),
                'totalCount'    => "1",
                'modelName'     => get_class($model),
                'relations'     => $relations,
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER UN UPDATE
        $this->onRest('req.put.resource.render', function ($model, $relations, $visibleProperties = [], $hiddenProperties = []) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("%s '<b>%s</b>' actualizado", Yii::app()->params["tercero"], $model->nombre),
                'totalCount'    => "1",
                'modelName'     => get_class($model),
                'relations'     => $relations,
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });

        //SE CAMBIA EL MENSAJE QUE DEVUELVE AL HACER DELETE
        $this->onRest('req.delete.resource.render', function ($model, $visibleProperties = [], $hiddenProperties = []) {
            echo $this->renderJSON([
                'type'              => 'rest',
                'success'           => 'true',
                'message'           => sprintf("%s '<b>%s</b>' eliminado", Yii::app()->params["tercero"], $model->nombre),
                'totalCount'        => "1",
                'modelName'         => get_class($model),
                'relations'         => [],
                'visibleProperties' => $visibleProperties,
                'hiddenProperties'  => $hiddenProperties,
                'data'              => $model,
            ]);
        });
    }

    public function actionGetExpByArea()
    {
        $data = Yii::app()->curl->setOption(CURLOPT_HTTPHEADER, $this->getAuth())->get($this->getApiUrl("expedientes", CJSON::encode(array(array("property" => "id_area", "value" => $_POST['id_area'], "operator" => "=")))));
        echo CJSON::encode(CJSON::decode($data)["data"]["expedientes"]);
    }

    private function convertArrayColumns($attributes, $id_expediente)
    {
        $arrayAttributes = array('id' => 'int(11) AUTO_INCREMENT PRIMARY KEY ');
        foreach ($attributes as $attribute) {
            switch (isset($attribute['tipo']) ? strtoupper($attribute['tipo']) : "TEXTO") {
                case 'TEXTO':
                    $arrayAttributes[$this->sanatizeTableName((isset($attribute['required']) && !$attribute['required']) ? $attribute['nombre'] . "_opt" : $attribute['nombre'])] = "VARCHAR(" . Yii::app()->params['MAX_CHAR'] . ") COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);
                    break;
                case 'TEXTO_LARGO':
                    $arrayAttributes[$this->sanatizeTableName((isset($attribute['required']) && !$attribute['required']) ? $attribute['nombre'] . "_txt_opt" : $attribute['nombre'] . "_txt")] = "TEXT COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);
                    break;
                case 'ARCHIVO':
                    $arrayAttributes[$this->sanatizeTableName((isset($attribute['required']) && !$attribute['required']) ? $attribute['nombre'] . "_path_opt" : $attribute['nombre'] . "_path")] = "VARCHAR(" . Yii::app()->params['MAX_CHAR'] . ") COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);
                    break;
                case 'ARCHIVO_MULTIPLE':
                    $arrayAttributes[$this->sanatizeTableName((isset($attribute['required']) && !$attribute['required']) ? $attribute['nombre'] . "_multi_opt" : $attribute['nombre'] . "_multi")] = "VARCHAR(" . Yii::app()->params['MAX_CHAR'] . ") COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);
                    break;
                case 'FECHA':
                    $arrayAttributes[$this->sanatizeTableName((isset($attribute['required']) && !$attribute['required']) ? $attribute['nombre'] . "_date_opt" : $attribute['nombre'] . "_date")] = "DATE COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);
                    break;
                case 'LISTA':
                    $arrayAttributes[$this->sanatizeTableName($attribute['nombre']) . "_list"] = "VARCHAR(" . Yii::app()->params['MAX_CHAR'] . ") COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);

                    if (!isset($attribute["id_lista"]))
                        throw new CHttpException('004', "El atributo '" . $attribute["nombre"] . "' de tipo lista no tiene definido la propiedad id_lista");


                    $lista = Listas::model()->findByPk($attribute["id_lista"]);
                    if (empty($lista->id))
                        throw new CHttpException('005', 'La lista con id ' . $attribute["id_lista"] . ' no existe');

                    //SE CREA UN REGISTRO EN LISTA_EXP
                    $listaExp = new ListaExp;
                    $listaExp->id_expediente = $id_expediente;
                    $listaExp->id_lista = $attribute["id_lista"];
                    $listaExp->field = $this->sanatizeTableName($attribute['nombre']) . "_list";
                    $listaExp->save();
                    break;
                case 'NUMERICO':
                    $arrayAttributes[$this->sanatizeTableName((isset($attribute['required']) && !$attribute['required']) ? $attribute['nombre'] . "_numero_opt" : $attribute['nombre'] . "_numero")] = "DOUBLE COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);
                    break;
                case 'MAPA':
                    $arrayAttributes[$this->sanatizeTableName((isset($attribute['required']) && !$attribute['required']) ? $attribute['nombre'] . "_gmapsjs_opt" : $attribute['nombre'] . "_gmapsjs")] = "VARCHAR(" . Yii::app()->params['MAX_CHAR'] . ") COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);
                    break;
                default:
                    $arrayAttributes[$this->sanatizeTableName((isset($attribute['required']) && !$attribute['required']) ? $attribute['nombre'] . "_opt" : $attribute['nombre'])] = "VARCHAR(" . Yii::app()->params['MAX_CHAR'] . ") COMMENT " . Yii::app()->db->quoteValue($attribute['nombre']);
                    break;
            }
        }

        return $arrayAttributes;
    }

    private function renameColumnByType($id_expediente, $name, $tipo = null, $required = false, $id_lista = null)
    {
        switch (isset($tipo) ? strtoupper($tipo) : "TEXTO") {
            case 'TEXTO':
                return $this->sanatizeTableName((isset($required) && !$required) ? $name . "_opt" : $name);
                break;
            case 'ARCHIVO':
                return $this->sanatizeTableName((isset($required) && !$required) ? $name . "_path_opt" : $name . "_path");
                break;
            case 'ARCHIVO_MULTIPLE':
                return $this->sanatizeTableName((isset($required) && !$required) ? $name . "_multi_opt" : $name . "_multi");
                break;
            case 'FECHA':
                return $this->sanatizeTableName((isset($required) && !$required) ? $name . "_date_opt" : $name . "_date");
                break;
            case 'LISTA':

                if (!isset($id_lista))
                    throw new CHttpException('004', "El attributo '" . $name . "' de tipo lista no tiene definido la propiedad id_lista");

                $lista = Listas::model()->findByPk($id_lista);
                if (empty($lista->id))
                    throw new CHttpException('002', 'La lista con id ' . $id_lista . ' no existe');

                //SE CREA UN REGISTRO EN LISTA_EXP
                $listaExp = new ListaExp;
                $listaExp->id_expediente = $id_expediente;
                $listaExp->id_lista = $id_lista;
                $listaExp->field = $this->sanatizeTableName($name) . "_list";
                $listaExp->save();

                return $this->sanatizeTableName($name) . "_list";
                break;
            case 'NUMERICO':
                return $this->sanatizeTableName((isset($required) && !$required) ? $name . "_numero_opt" : $name . "_numero");
                break;
            case 'MAPA':
                return $this->sanatizeTableName((isset($required) && !$required) ? $name . "_gmapsjs_opt" : $name . "_gmapsjs");
                break;
            default:
                return $this->sanatizeTableName((isset($required) && !$required) ? $name . "_opt" : $name);
                break;
        }
    }

    private function getColumnsInfo($nombre, $comment = false, $id = null)
    {
        $aux["nombre"] = $nombre;

        if (strpos($nombre, "_path") !== false)
            $aux["tipo"] = "ARCHIVO";
        else if (strpos($nombre, "_multi") !== false)
            $aux["tipo"] = "ARCHIVO_MULTIPLE";
        else if (strpos($nombre, "_date") !== false)
            $aux["tipo"] = "FECHA";
        else if (strpos($nombre, "_list") !== false) {
            $aux["tipo"] = "LISTA";

            if (!empty($id)) {
                $listExp = ListaExp::model()->findByAttributes(array('id_expediente' => $id, 'field' => $nombre));
                $lista = Listas::model()->findByPk($listExp->id_lista);
                $aux["lista"] = explode(",", $lista->lista);
            }
        } else if (strpos($nombre, "_numero") !== false)
            $aux["tipo"] = "NUMERICO";
        else if (strpos($nombre, "_gmapsjs") !== false)
            $aux["tipo"] = "MAPA";
        else if (strpos($nombre, "_txt") !== false)
            $aux["tipo"] = "TEXTO_LARGO";
        else
            $aux["tipo"] = "TEXTO";

        $aux["requerido"] = (strpos($nombre, "_opt") !== false) ? false : true;

        $aux["label"] = $comment;

        return $aux;
    }

    private function fileAttributeInfo($expediente, $idExpediente, $newFiles = array())
    {
        //ITERAMOS CADA ATTRIBUTO DEL REGISTRO 
        foreach ($expediente->attributes as $attribute => $value) {
            //EN CASO QUE SEA DE TIPO MULTIPLE
            if (strpos($attribute, '_multi') !== false) {
                $archivos = array();
                //VAMOS EN BUSCA DE TODOS LOS ARCHIVOS LIGADOS A ESE ATRIBUTO
                $files = Multi::model()->findAllByAttributes(array('id_expediente' => $idExpediente, 'field' => $attribute, 'id_registro' => $expediente->id));
                foreach ($files as $file) {
                    if (!empty($newFiles) && in_array($file->id, $newFiles)) {
                        $record = array("id" => $file->id, "filename" => substr($file->path, 14), "fecha" => $file->fecha);
                        if (Yii::app()->params["show_file_path"])
                            $record["path"] = Yii::app()->params["HTTP_SERVER_PATH"] . DIRECTORY_SEPARATOR . $file->path;
                        if (Yii::app()->params["show_file_base64"])
                            $record["file"] = $this->convertFileToBase64($file->path);

                        array_push($archivos, $record);
                    }
                }
                //ASIGNAMOS LOS ARCHIVOS ENCONTRADOS EN DICHO ATRIBUTO
                $expediente[$attribute] = $archivos;
            }

            //EN CASO QUE SEA DE TIPO ARCHIVO
            if (strpos($attribute, '_path') !== false) {
                $real_value = $expediente[$attribute];
                //ASIGNAMOS LOS ARCHIVOS ENCONTRADOS EN DICHO ATRIBUTO
                $array_values = array("filename" => substr($expediente[$attribute], 14));
                if (Yii::app()->params["show_file_path"])
                    $array_values["path"] = Yii::app()->params["HTTP_SERVER_PATH"] . DIRECTORY_SEPARATOR . $real_value;
                if (Yii::app()->params["show_file_base64"])
                    $array_values["file"] = $this->convertFileToBase64($real_value);

                $expediente[$attribute] = $array_values;
            }
        }

        return $expediente;
    }

    private function setValuesToExpediente($data, $expedientes, $id)
    {
        $array_multi = array();
        foreach ($data as $attr => $value) {
            $info = $this->getColumnsInfo($attr);
            switch ($info["tipo"]) {
                case "ARCHIVO":
                    if (!isset($value["filename"]))
                        throw new CHttpException('008', "El parámetro filename no se encuentra definido para el atributo '" . $attr . "'");
                    if (!isset($value["file"]) && !isset($value["skipFileValidation"]))
                        throw new CHttpException('009', "El parámetro file no se encuentra definido para el atributo '" . $attr . "'");

                    $filename_aux = (!isset($value["skipFileValidation"]) || !$value["skipFileValidation"]) ? date("YmdHis") . $value["filename"] : "00000000000000" . $value["filename"];
                    if ((!isset($value["skipFileValidation"]) || !$value["skipFileValidation"]) && $this->convertBase64ToFile(Yii::app()->params['isEncrypted'] ? $this->encrypt($value["file"]) : $value["file"], $filename_aux) === false)
                        throw new CHttpException('010', "Error al subir el archivo '" . $value["filename"] . "'");
                    $expedientes[$attr] = $filename_aux;
                    break;
                case "ARCHIVO_MULTIPLE":

                    foreach ($value as $multifile) {
                        if (!isset($multifile["filename"]))
                            throw new CHttpException('008', "El parámetro filename no se encuentra definido para el atributo '" . $attr . "'");
                        if (!isset($multifile["file"]) && !isset($multifile["skipFileValidation"]))
                            throw new CHttpException('009', "El parámetro file no se encuentra definido para el atributo '" . $attr . "'");

                        $filename_aux = (!isset($multifile["skipFileValidation"]) || !$multifile["skipFileValidation"]) ? date("YmdHis") . $multifile["filename"] : "00000000000000" . $multifile["filename"];
                        if ((!isset($multifile["skipFileValidation"]) || !$multifile["skipFileValidation"]) && $this->convertBase64ToFile(Yii::app()->params['isEncrypted'] ? $this->encrypt($multifile["file"]) : $multifile["file"], $filename_aux) === false)
                            throw new CHttpException('010', "Error al subir el archivo '" . $multifile["filename"] . "'");
                        else {
                            $multi;
                            if (isset($multifile["id"])) {
                                $multi = Multi::model()->findByPk($multifile["id"]);
                                if (empty($multi->id))
                                    throw new CHttpException('019', "El archivo con id '" . $multifile["id"] . "' no existe");
                            } else
                                $multi = new Multi;


                            $multi->id_expediente = $id;
                            $multi->field = $attr;
                            $multi->path = $filename_aux;
                            $multi->fecha = date("Y-m-d H:i:s");
                            array_push($array_multi, $multi);
                        }
                        $expedientes[$attr] = null;
                    }

                    break;
                case 'FECHA':
                    //Validamos que el campo sea requerido y no se encuentre vacio
                    if (boolval($info['requerido']) && empty($value))
                        throw new CHttpException('036', "El campo '" . $attr . "' no puede estar vacio");

                    if (!empty($value)) {
                        if (preg_match("/^\d{4}-\d{2}-\d{2}$/", $value)) {
                            $date_explode = explode("-", $value);
                            $year = $date_explode[0];
                            $month = $date_explode[1];
                            $day = $date_explode[2];
                            if (checkdate($month, $day, $year)) {
                                $expedientes[$attr] = $value;
                            } else {
                                throw new CHttpException('012', "'" . $value . "' no es una fecha valida");
                            }
                        } else
                            throw new CHttpException("011", "El formato de la fecha debe ser 'YYYY-MM-DD'");
                    }

                    break;
                case 'LISTA':

                    $listaExp = ListaExp::model()->find("id_expediente=" . $id . " and field='" . $attr . "'");
                    if (empty($listaExp->id))
                        throw new CHttpException("013", "No existe una lista ligada al atributo '" . $attr . "'");
                    $lista = Listas::model()->findByPk($listaExp->id_lista);
                    $options = explode(",", $lista->lista);
                    $option_exist = false;
                    foreach ($options as $option)
                        if ($option === $value)
                            $option_exist = true;

                    if (!$option_exist)
                        throw new CHttpException('014', "El valor  '" . $value . "' no se encuentra en la lista '" . $lista->nombre . "'");

                    $expedientes[$attr] = $value;
                    break;
                case 'MAPA':
                    if (!isset($value['lat']))
                        throw new CHttpException("015", "La propiedad '" . $attr . "' de tipo mapa no tiene definido el atributo 'lat'");
                    if (!isset($value['lng']))
                        throw new CHttpException("016", "La propiedad '" . $attr . "' de tipo mapa no tiene definido el atributo 'lng'");

                    $expedientes[$attr] = $value['lat'] . "," . $value['lng'];
                    break;
                default:
                    if (boolval($info['requerido']) && empty($value))
                        throw new CHttpException("037", "El campo <b>'" . $attr . "'</b> no puede estar vacio");
                    $expedientes[$attr] = $value;
                    break;
            }
        }
        return array('expedientes' => $expedientes, 'array_multi' => $array_multi);
    }

    private function getHashFromFiles($data, $isDelete = false)
    {
        $files = array();
        foreach ($data as $attr => $value) {
            $info = $this->getColumnsInfo($attr);
            switch ($info["tipo"]) {
                case "ARCHIVO":
                    if (!isset($value["filename"]))
                        throw new CHttpException('008', "El parámetro filename no se encuentra definido para el atributo '" . $attr . "'");
                    /*if(!isset($value["file"]) && !$isDelete)
                            throw new CHttpException('009', "El parámetro file no se encuentra definido para el atributo '".$attr."'");*/

                    $filename_aux = (!$isDelete) ? date("YmdHis") . $value["filename"] : "00000000000000" . $value["filename"];

                    $temp = tmpfile();
                    fwrite($temp, !isset($value["file"]) ? base64_decode($this->convertFileToBase64(basename($value['path']))) : base64_decode($value["file"]));
                    array_push($files, array("filename" => $value["filename"], "hash" => hash_file("sha512", stream_get_meta_data($temp)['uri'])));
                    fclose($temp);

                    break;
                case "ARCHIVO_MULTIPLE":

                    foreach ($value as $multifile) {
                        if (!isset($multifile["filename"]))
                            throw new CHttpException('008', "El parámetro filename no se encuentra definido para el atributo '" . $attr . "'");
                        if (!isset($multifile["file"]) && !$isDelete)
                            throw new CHttpException('009', "El parámetro file no se encuentra definido para el atributo '" . $attr . "'");

                        $filename_aux = (!$isDelete) ? date("YmdHis") . $multifile["filename"] : "00000000000000" . $multifile["filename"];

                        $temp = tmpfile();
                        fwrite($temp, !isset($multifile["file"]) ? base64_decode($this->convertFileToBase64(basename($multifile['path']))) : base64_decode($multifile["file"]));
                        array_push($files, array("filename" => $multifile["filename"], "hash" => hash_file("sha512", stream_get_meta_data($temp)['uri'])));
                        fclose($temp);
                    }

                    break;
                default:
                    break;
            }
        }
        return $files;
    }

    private function signProccess($certData, $data, $user, $isDelete = false)
    {
        Yii::import('application.controllers.FirmaElectronicaController');
        $signController = new FirmaElectronicaController;

        $files = $this->getHashFromFiles($data, $isDelete);

        $xmlData = CJSON::encode(Yii::app()->params['dummyXml']($certData, $data, $user->curp, $files));

        //AQUI PROCESO PARA SACAR LOS ARCHIVOS
        $resultXml = $signController->actionCreateXMLDocument($xmlData, $certData['pkey']);
        if (!empty($resultXml['xmlBase64'])) {
            if (file_put_contents(Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . "xml" . DIRECTORY_SEPARATOR . $resultXml['UUID'] . ".xml", base64_decode($resultXml['xmlBase64']))) {

                Yii::import('application.extensions.bootstrap.gii.*');
                require_once('bootstrap/tcpdf/tcpdf.php');
                require_once('bootstrap/tcpdf/config/lang/eng.php');
                $html = $this->renderPartial('_xmlRepresentation', array('model' => $resultXml['pdfDataFields'], "stringOriginal" => $resultXml['originalString'], 'nombreCompleto' => $user->apellido_p . " " . $user->apellido_m . " " . $user->nombre, 'email' => $user->email), true);

                $pdf = new TCPDF();
                $pdf->SetCreator(PDF_CREATOR);
                $pdf->SetAuthor(Yii::app()->name);
                $pdf->SetTitle('Representacion XML');
                $pdf->SetSubject('Representacion XML');
                $pdf->setPrintHeader(false);
                $pdf->setFooterFont(array('helvetica', '', 6));
                $pdf->SetMargins(5, 18, 15);
                $pdf->SetFooterMargin(10);
                $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
                $pdf->SetFont('dejavusans', '', 7);
                $pdf->AddPage();
                $pdf->writeHTML($html, true, false, true, false, '');
                $pdf->LastPage();
                $pdf->Output(Yii::app()->params['FILES_FOLDER_PATH'] . DIRECTORY_SEPARATOR . "pdf" . DIRECTORY_SEPARATOR . $resultXml['UUID'] . ".pdf", "F");

                return array("uuid" => $resultXml['UUID'], "stringOriginal" => $resultXml['originalString']);
            } else
                throw new CHttpException(500, "Error al intentar guardar el XML firmado");
        } else
            throw new CHttpException(500, "Error al intentar firmar el documento ");

        return array("uuid" => null, "stringOriginal" => null);
    }
}
