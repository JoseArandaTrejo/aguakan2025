<?php

class FirmaElectronicaController
{ 
  public function actionCreateXMLDocument($xmlDocumentData, $privateKey) {
    $documentArray = json_decode($xmlDocumentData, true);

    $xw = new XMLWriter();
    $xw->openUri("php://output");
    $xw->openMemory();
    $xw->startDocument("1.0", "UTF-8");
    $xw->setIndent(4);

    $this->createRootNode($xw, $documentArray);
    $xw->endDocument();

    $xmlString = trim(explode("?>", $xw->flush(true))[1]);
    $xmlStringBase64 = base64_encode($xmlString);

    return $this->createSign($xmlStringBase64, $privateKey);
    
  }

  private function createSign($xmlDataBase64, $certPrivKey) {
    $xmlData = base64_decode($xmlDataBase64);

    openssl_sign($xmlData, $signature, $certPrivKey, OPENSSL_ALGO_SHA512);
    
    $encodedSignature =  base64_encode($signature);

    return($this->createSignaturedNode($xmlDataBase64, "G/$encodedSignature"));
  }

  private function createSignaturedNode($xmlDataEncoded, $signature) {

    if(strlen($xmlDataEncoded) == 0 || strlen($signature)==0 ) throw new CHttpException('052', "La firma y/o el archivo XML son necesarios.");
    
    $xmlStringDecoded = base64_decode($xmlDataEncoded);
    $validSign = $signature;
    
    $dateSigned = new DateTime();
    $signedDate = explode("+", $dateSigned->format('c'))[0];
    $dateBEncode = $dateSigned->format('U');
    $uuidHash = hash_hmac("sha256", $dateBEncode, base64_encode($xmlStringDecoded), false);
    $xmlFileName = $uuidHash;  

    $documentToSign = new DOMDocument();
    $documentToSign->preserveWhiteSpace=false;
    
    $documentToSign->loadXML($xmlStringDecoded);
    $attributeData = $this->getOriginalString($documentToSign);

    $documentToSign->preserveWhiteSpace=true;
    $documentToSign->loadXML($xmlStringDecoded);

    $docChisTag = $documentToSign->getElementsByTagName('DocumentoChis')->item(0);

    /*
    $signNode = $documentToSign->createElement('SDCD:SelloDigitalClickdata');
    
    $signNodeAttr = $documentToSign->createAttribute("version");
    $signNodeAttr->value=Yii::app()->params['signAttributes']['version'];
    $signNode->appendChild($signNodeAttr);
    
    $signNodeAttr = $documentToSign->createAttribute("UUID");
    $signNodeAttr->value=$uuidHash;
    $signNode->appendChild($signNodeAttr);
    
    $signNodeAttr = $documentToSign->createAttribute("sello");
    $signNodeAttr->value=$validSign;
    $signNode->appendChild($signNodeAttr);

    $docChisTag->appendChild($signNode);
    */

    $generatedSignedXML = trim(explode("?>", $documentToSign->saveXML())[1]);
    
    $attributeData['pdfDataFields']['UUID'] = $uuidHash;
    $attributeData['pdfDataFields']['sello'] = $validSign;
    
    $responseArray = array(
                            'xmlBase64' => base64_encode($generatedSignedXML),
                            'originalString' => $attributeData['originalString'],
                            'UUID' => $uuidHash,
                            'pdfDataFields' => $attributeData['pdfDataFields']
                          );

    return $responseArray;
  }

  private function createRootNode(XMLWriter $xmlWriterObj, array $attrArray ){
    try{
      $xmlWriterObj->startElement("DocumentoChis");
      $this->addNodeAttributes($xmlWriterObj, $attrArray['DocumentoChis'], "");
      $this->createNodes($xmlWriterObj, $attrArray);

      $xmlWriterObj->endElement();
    } catch (Exception $e) {
        echo CJSON::encode(['success'=>false,'message'=>"Certificate Obtained",'data'=>$e]);
    }
    
  }

  private function createNodes(XMLWriter $xmlWriterObj, array $attrArray) {
    $ignoreNodes = array("pkey", "certificado", "DocumentoChis");
    try {
      foreach($attrArray as $key => $value){
        if(!in_array($key, $ignoreNodes, true) && !empty($value) && !$this->validateAttributesValue($value)){
          $xmlWriterObj->startElement($key);
          
          $this->addNodeAttributes($xmlWriterObj, $value, strval($key));
          
          $xmlWriterObj->endElement();
        }

      }
    } catch (Exception $e) {
      echo CJSON::encode(['success'=>false,'message'=>"Certificate Obtained",'data'=>$e]);

    }
  }

  private function validateAttributesValue($valuesToValidate) {
    $hasAllEmpty = true;

    try{
      foreach($valuesToValidate as $key => $value) {      
        if(is_array($value)) {
          foreach($value as $key => $values){
            $hasAllEmpty = empty($values);
            if(!$hasAllEmpty) return $hasAllEmpty;
          }
        } else {
          $hasAllEmpty = empty($value);
          if(!$hasAllEmpty) return $hasAllEmpty;
        }
      }

      return $hasAllEmpty;

      
    } catch (Exception $e) {
      echo CJSON::encode(['success'=>false,'message'=>"Error al validar los atributos",'data'=>$e]);
    }
  }

  private function addNodeAttributes(XMLWriter $xmlWriterObj, array $attrValues, $parentNode) {
    try{
      foreach($attrValues as $key => $value) {      
        if(is_array($value)) {
          $subNodeName = (substr(trim($parentNode),-3) <> "res") ? rtrim($parentNode, "s") : rtrim($parentNode, "es");
          if($parentNode !== "receptores")
            $xmlWriterObj->writeAttribute("num_$parentNode", count($attrValues));
          
          $this->createSubNode($xmlWriterObj, $value, strval($subNodeName));
        } else{
          if(!empty($value))
            $xmlWriterObj->writeAttribute($key, $value);
        }
      }
    } catch (Exception $e) {
      echo CJSON::encode(['success'=>false,'message'=>"Certificate Obtained",'data'=>$e]);
    }
  }

  private function createSubNode(XMLWriter $xmlWriterObj, array $attrArray, $subNodeName) {    
    try{
      $xmlWriterObj->startElement($subNodeName);
    
      foreach($attrArray as $key => $value){
        if(!empty($value))
          $xmlWriterObj->writeAttribute($key, $value);
      }
      
      $xmlWriterObj->endElement();

    } catch (Exception $e) {
      echo CJSON::encode(['success'=>false,'message'=>"Certificate Obtained",'data'=>$e]);
    }  
  }

  private function getOriginalString(DOMDocument $xmlDocument) {
    $attributesXML = [];
    $nodes = $xmlDocument->getElementsByTagName('DocumentoChis');
    $arrayNodesToRead = [];
    $pdfDataFields = [];
    $ignoredAttributes = array(
                                "fecha_creacion", "tipo_docto", "xmlns", "num_firmantes", "email_firmante"
                              );
    $originalString = "";

    foreach($nodes as $node) {        
      $this->getChildNodesNames($node, $arrayNodesToRead);
      $this->getNodesAttributes($node, $originalString, $ignoredAttributes, $pdfDataFields);
    }
    
    foreach($arrayNodesToRead as $tagName) {
      $this->getChildNodes($xmlDocument, $tagName, $originalString, $ignoredAttributes, $pdfDataFields);
    }
    
    $originalString .= "||";
    
    return array  (
                    'originalString' => $originalString,
                    'pdfDataFields' => $pdfDataFields
                  );
  }

  private function getChildNodesNames($xmlParentNode, &$childNodeArray) {
    if($xmlParentNode->hasChildNodes()){
      foreach($xmlParentNode->childNodes as $childNode) {
        $nodeName = @$childNode->tagName;
        if(strlen($nodeName) > 0 && !in_array($nodeName, $childNodeArray)) 
          array_push($childNodeArray, $nodeName);
      }      
    }
  }

  private function getChildNodes(DOMDocument $xmlDocument, $tagName, &$originalString, array $ignoredAttributes, array &$pdfDataFields) {
    $nodes = $xmlDocument->getElementsByTagName($tagName);
    foreach($nodes as $node) { 
      if ($node->hasChildNodes()) {
        $this->getNodesAttributes($node, $originalString, $ignoredAttributes, $pdfDataFields);
        
        foreach($node->childNodes as $childNode) {
          $this->getNodesAttributes($childNode, $originalString, $ignoredAttributes, $pdfDataFields);
        }
      } else{
        $this->getNodesAttributes($node, $originalString, $ignoredAttributes, $pdfDataFields);
      }
    }
  }

  private function getNodesAttributes($xmlNode, &$originalString, array $ignoredAttributes, array &$pdfDataFields) {
    foreach($xmlNode->attributes as $xmlNodeAttribute) {
      
      if($xmlNodeAttribute->name <> "xmlns" && $xmlNodeAttribute->name <> "num_firmantes") {
        if (array_key_exists($xmlNodeAttribute->name, $pdfDataFields)) {
          $pdfDataFields[$xmlNodeAttribute->name] .= ", $xmlNodeAttribute->value";
        } else 
          $pdfDataFields[$xmlNodeAttribute->name] = $xmlNodeAttribute->value;
      }

      if (!in_array($xmlNodeAttribute->name, $ignoredAttributes, true)){
        if($xmlNodeAttribute->name == "version") {
          $originalString = "||$xmlNodeAttribute->value|";
        } else if($xmlNodeAttribute->name == "asunto_docto") {
          $originalString .= "|$xmlNodeAttribute->value|";
        } else {
          $originalString .= "|$xmlNodeAttribute->value";
        }
      }
      
    } 
  }

  private function sendResponse($success, $message, $response=""){
    echo CJSON::encode(['success'=>$success,'message'=>$message,'data'=>$response]);
  }

}