<?php

class SignDocumentController extends Controller
{
	//Funcion que obtiene el contenido desencriptado del certificado P12.
	// public function actionGetCertFileContent($certPath, $pwdCert, $xmlDocumentData) {
  public function actionGetCertFileContent() {
    try {
      if(strlen($certPath = $this->getCertTempPath()) == 0){
        throw new CHttpException('051', "No se encuentra el certificado.");
      }
    
      if(strlen($pwdCert = $this->getCertPwd()) == 0){
        throw new CHttpException('052', "No se encuentra la contraseña.");
      }
      
      // Se obtiene la informacion del certificado.
      if(openssl_pkcs12_read($certPath, $infoCert, $pwdCert)) {
        // Se desencripta la informacion del certificado.
        if ($certDecoded = openssl_x509_parse($infoCert['cert'], 0)) {
          $certInfo = array(
            "cert" => $infoCert['cert'],
            "pkey" => $infoCert['pkey'],
            "emisor" => array (
              "emisor_name" => $certDecoded['subject']['commonName'],
              "emisor_email" => $certDecoded['subject']['emailAddress'],
              "emisor_rfc" => $certDecoded['subject']['x500UniqueIdentifier'],
              "emisor_hash" => $certDecoded['hash'],
              "serialNumber" => $certDecoded['serialNumber']
            )
          );

          $this->sendResponse(true, "Certificado obtenido", $certInfo);
        } else 
          $this->sendResponse(false, "El certificado es incorrecto.");
      }else 
        // echo CJSON::encode(['success'=>false, 'message'=>"El certificado o la contraseña son incorrectos."]);
        $this->sendResponse(false, "El certificado o la contraseña son incorrectos.");

    } catch (Exception $e) {
      throw new CHttpException('050', $e->getMessage());
    }
  }

  private function sendResponse($success, $message, $response=""){
    echo CJSON::encode(['success'=>$success,'message'=>$message,'data'=>$response]);
  }

	private function getCertPwd() {
    $pwdCert = "";
    
    if (isset($_POST)) {
      $pwdCert = $_POST['certPwd'];
      
      if (strlen($pwdCert) == 0)  $pwdCert = "";
    } 

    return $pwdCert;
  }

  private function getCertFileName() {
    $certFileName = "";

    if(isset($_FILES)) {
      $certFileName = $_FILES['certp12']['name'];
      if (strlen($certFileName) == 0) $certFileName = "";
    }

    return $certFileName;
  }

  private function getCertTempPath() {
    $certPath = "";
    
    if(isset($_FILES)) {      
      $certPath = base64_decode($_POST['pk12Content']);
      if (strlen($certPath) == 0) $certPath = "";
    }

    return $certPath;
  }
}

