<?php

class InstallController extends Controller
{

	public $layout = 'install';

	public function actionIndex()
	{
		$this->render("index", array());
	}

	public function actionConfig()
	{
		$this->createDb($_POST["host"], $_POST["dbUser"], $_POST["dbPassword"], $_POST["dbName"]);
		$this->configParams(
			$_POST["max_emp"],
			$_POST["max_areas"],
			$_POST["max_exp"],
			$_POST["max_users"],
			$_POST["max_char"],
			$_POST["first_name"],
			$_POST["second_name"],
			$_POST["third_name"],
			$_POST["fourth_name"],
			$_POST["files_path"],
			$_POST["http_files_path_protocol"] . $_POST["http_files_path"],
			$_POST["show_file_path"],
			$_POST["show_file_base64"],
			$_POST["useFEA"],
			$_POST["extraFields"],
			$_POST["showStatus"],
			$_POST["allowImportCSV"],
			$_POST["logoSideReport"],
			$_POST["sessionTimeoutSeconds"],
			$_POST["showWaterMark"],
			$_POST["showOnlyCenter"],
			$_POST["showEveryPx"],
			$_POST["isEncrypted"],
			$_POST["gmaps"],
			$_POST["usingHeaderCsv"],
			$_POST["waterMarkText"],
			$_POST["delimiterCsv"]
		);
	}

	private function createDb($servername, $username, $password, $db)
	{

		//AQUI CREAR EL ARCHIVO DATABASE
		$databaseConfig = file_get_contents(Yii::getPathOfAlias('webroot') . DIRECTORY_SEPARATOR . "protected" . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "database.php");
		$databaseConfig = str_replace("{{HOST}}", $servername, $databaseConfig);
		$databaseConfig = str_replace("{{DBNAME}}", $db, $databaseConfig);
		$databaseConfig = str_replace("{{USERNAME}}", $username, $databaseConfig);
		$databaseConfig = str_replace("{{PASSWORD}}", $password, $databaseConfig);
		file_put_contents(Yii::getPathOfAlias('webroot') . DIRECTORY_SEPARATOR . "protected" . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "database.php", $databaseConfig);

		$conn = new mysqli($servername, $username, $password);

		if ($conn->connect_error)
			die("Connection failed: " . $conn->connect_error);

		$sql = "CREATE DATABASE IF NOT EXISTS " . $db . " DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;";
		if ($conn->query($sql) === TRUE)
			echo CJSON::encode(array("success" => true, "message" => "Base de datos creada con éxito"));
		else
			echo CJSON::encode(array("success" => false, "message" => "Error al crear la base de datos: " . $conn->error));

		$conn->close();
	}

	private function configParams(
		$max_emp,
		$max_areas,
		$max_exp,
		$max_users,
		$max_char,
		$first_name,
		$second_name,
		$third_name,
		$fourth_name,
		$files_folder_path,
		$http_files_path,
		$show_file_path,
		$show_file_base64,
		$useFEA,
		$extraFields,
		$showStatus,
		$allowImportCSV,
		$logoSideReport,
		$session_timeout_seconds,
		$showWaterMark,
		$showOnlyCenter,
		$showEveryPx,
		$isEncrypted,
		$gmaps,
		$usingHeaderCsv,
		$waterMarkText,
		$delimiterCsv
	) {
		//AQUI CONFIGURAMOS LOS PARAMETROS DEL SISTEMA
		$systemConfig = file_get_contents(Yii::getPathOfAlias('webroot') . DIRECTORY_SEPARATOR . "protected" . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "params.php");
		$systemConfig = str_replace("{{MAX_EMP}}", $max_emp, $systemConfig);
		$systemConfig = str_replace("{{MAX_AREAS}}", $max_areas, $systemConfig);
		$systemConfig = str_replace("{{MAX_EXP}}", $max_exp, $systemConfig);
		$systemConfig = str_replace("{{MAX_USERS}}", $max_users, $systemConfig);
		$systemConfig = str_replace("{{MAX_CHAR}}", $max_char, $systemConfig);
		$systemConfig = str_replace("{{FIRST_NAME}}", $first_name, $systemConfig);
		$systemConfig = str_replace("{{SECOND_NAME}}", $second_name, $systemConfig);
		$systemConfig = str_replace("{{THIRD_NAME}}", $third_name, $systemConfig);
		$systemConfig = str_replace("{{FOURTH_NAME}}", $fourth_name, $systemConfig);
		$systemConfig = str_replace("{{FILES_PATH}}", $files_folder_path, $systemConfig);
		$systemConfig = str_replace("{{HTTP_FILES_PATH}}", $http_files_path, $systemConfig);
		$systemConfig = str_replace("{{SHOW_FILE_PATH}}", $show_file_path, $systemConfig);
		$systemConfig = str_replace("{{SHOW_FILE_BASE64}}", $show_file_base64, $systemConfig);
		$systemConfig = str_replace("{{USE_FEA}}", $useFEA, $systemConfig);
		$systemConfig = str_replace("{{EXTRA_FIELDS}}", $extraFields, $systemConfig);
		$systemConfig = str_replace("{{SHOW_STATUS}}", $showStatus, $systemConfig);
		$systemConfig = str_replace("{{IMPORT_CSV}}", $allowImportCSV, $systemConfig);
		$systemConfig = str_replace("{{LOGO_SIDE}}", $logoSideReport, $systemConfig);
		$systemConfig = str_replace("{{SESSION_TIMEOUT_SECONDS}}", $session_timeout_seconds, $systemConfig);
		$systemConfig = str_replace("{{SHOW_WATERMARK}}", $showWaterMark, $systemConfig);
		$systemConfig = str_replace("{{SHOW_ONLY_CENTER}}", $showOnlyCenter, $systemConfig);
		$systemConfig = str_replace("{{SHOW_EVERY_PX}}", $showEveryPx, $systemConfig);
		$systemConfig = str_replace("{{IS_ENCRYPTED}}", $isEncrypted, $systemConfig);
		$systemConfig = str_replace("{{GMAPS}}", $gmaps, $systemConfig);
		$systemConfig = str_replace("{{USING_HEADER_CSV}}", $usingHeaderCsv, $systemConfig);
		$systemConfig = str_replace("{{WATERMARK_TEXT}}", $waterMarkText, $systemConfig);
		$systemConfig = str_replace("{{DELIMITER_CSV}}", $delimiterCsv, $systemConfig);


		file_put_contents(Yii::getPathOfAlias('webroot') . DIRECTORY_SEPARATOR . "protected" . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR . "params.php", $systemConfig);
	}

	public function actionCreateTables()
	{
		Yii::app()->db->schema->refresh();
		//Yii::app()->db->setActive(true);
		Yii::import('application.migrations.ClickdataDatabase');
		$db = new ClickdataDatabase();
		$db->safeUp();
		$db->createUser($_POST["nombre"], $_POST["apellido_p"], $_POST["apellido_m"], strtoupper($_POST["curp"]), $_POST["email"], $_POST["password"]);
		if (Yii::app()->params['useFEA'])
			$db->createFeaLists();
	}
}
